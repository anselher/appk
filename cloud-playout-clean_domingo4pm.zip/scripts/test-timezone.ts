// Test timezone calculation
function applyTzOffset(d: Date, offsetHours: number): Date {
  return new Date(d.getTime() + offsetHours * 3600000);
}

function venezuelaMsSinceMidnight(d: Date, offset: number): number {
  const local = applyTzOffset(d, offset);
  return (
    local.getUTCHours() * 3600000 +
    local.getUTCMinutes() * 60000 +
    local.getUTCSeconds() * 1000 +
    local.getUTCMilliseconds()
  );
}

function venezuelaDateKey(d: Date, offset: number): string {
  const local = applyTzOffset(d, offset);
  const y = local.getUTCFullYear();
  const m = String(local.getUTCMonth() + 1).padStart(2, "0");
  const day = String(local.getUTCDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

// Simulate different server timezones
const now = new Date();
console.log("=== Timezone Test ===");
console.log(`UTC time: ${now.toISOString()}`);
console.log(`Local time: ${now.toString()}`);
console.log("");

// Test with -4 offset (Venezuela)
const offset = -4;
const dateKey = venezuelaDateKey(now, offset);
const msSinceMidnight = venezuelaMsSinceMidnight(now, offset);
const hours = Math.floor(msSinceMidnight / 3600000);
const mins = Math.floor((msSinceMidnight % 3600000) / 60000);
const secs = Math.floor((msSinceMidnight % 60000) / 1000);
console.log(`With offset ${offset} (Venezuela):`);
console.log(`  Date: ${dateKey}`);
console.log(`  Time: ${String(hours).padStart(2,"0")}:${String(mins).padStart(2,"0")}:${String(secs).padStart(2,"0")}`);
console.log("");

// Compare with actual Venezuela time
const caracasTime = new Date(now.getTime() - 4 * 3600000);
console.log(`Expected Venezuela time: ${caracasTime.getUTCHours()}:${String(caracasTime.getUTCMinutes()).padStart(2,"0")}:${String(caracasTime.getUTCSeconds()).padStart(2,"0")}`);
console.log("");

// Test with 0 offset (UTC)
const offsetUtc = 0;
const msUtc = venezuelaMsSinceMidnight(now, offsetUtc);
const hoursUtc = Math.floor(msUtc / 3600000);
console.log(`With offset 0 (UTC): ${String(hoursUtc).padStart(2,"0")}:${String(Math.floor((msUtc % 3600000) / 60000)).padStart(2,"0")}`);
