// Cleanup expired Avance renders.
// Run with: bun run scripts/cleanup-renders.ts
//
// This script:
//   1. Finds all RenderedAvance records where expiresAt < now.
//   2. Deletes the MP4 file from disk.
//   3. Deletes the DB record.
//
// It's safe to run multiple times — already-deleted files are skipped.
// Can be scheduled as a cron (every hour) or run manually.

import { cleanupExpiredRenders } from "../src/lib/render";

async function main() {
  console.log("Cleaning up expired Avance renders...");
  const result = await cleanupExpiredRenders();
  console.log(`✓ Done. Deleted ${result.deleted} renders, ${result.errors} errors.`);
}

main()
  .then(() => process.exit(0))
  .catch((e) => {
    console.error(e);
    process.exit(1);
  });
