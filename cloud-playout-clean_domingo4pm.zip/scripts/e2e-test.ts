// End-to-end upload + transcode test (bypass HTTP to avoid sandbox server crashes).
// Simulates exactly what the /api/assets/upload endpoint does.

import { db } from "../src/lib/db";
import { transcodeToHLS, probeVideo, getAdaptiveLadder } from "../src/lib/ffmpeg";
import { getAssetDir, getOriginalsDir, absoluteToRelative } from "../src/lib/media-storage";
import { promises as fs } from "fs";
import path from "path";
import crypto from "crypto";

async function main() {
  const inputVideo = "/tmp/test_720p.mp4";

  console.log("═══════════════════════════════════════════════");
  console.log("  PRUEBA END-TO-END: UPLOAD + TRANSCODE ABR");
  console.log("═══════════════════════════════════════════════\n");

  // 1. Probe the source video
  console.log("1️⃣  Probando video fuente...");
  const probe = await probeVideo(inputVideo);
  console.log(`   ✓ Resolución: ${probe.width}x${probe.height}`);
  console.log(`   ✓ Duración: ${probe.durationMs}ms`);
  console.log(`   ✓ Codec: ${probe.codec}`);
  console.log(`   ✓ Audio: ${probe.hasAudio ? "sí" : "no"}`);
  console.log(`   ✓ FPS: ${probe.fps}`);

  // 2. Determine adaptive ladder (NO upscaling)
  const ladder = getAdaptiveLadder(probe.height);
  console.log(`\n2️⃣  Ladder adaptativo (sin upscaling):`);
  for (const v of ladder) {
    console.log(`   • ${v.label} — ${v.width}x${v.height} @ ${v.videoBitrate} video + ${v.audioBitrate} audio`);
  }
  console.log(`   (Fuente es ${probe.height}p → NO se generan variantes > ${probe.height}p)`);

  // 3. Save original file to storage
  console.log(`\n3️⃣  Guardando original en almacenamiento...`);
  const originalsDir = await getOriginalsDir();
  const uniqueName = `${crypto.randomUUID()}_demo_720p.mp4`;
  const destPath = path.join(originalsDir, uniqueName);
  await fs.copyFile(inputVideo, destPath);
  console.log(`   ✓ Guardado: ${destPath}`);

  // 4. Create Asset record
  console.log(`\n4️⃣  Creando registro en base de datos...`);
  const asset = await db.asset.create({
    data: {
      title: "Demo 720p - Upload Test",
      originalFilename: "test_720p.mp4",
      category: "PROGRAM",
      durationMs: 0,
      hlsUrl: "",
      thumbnailUrl: null,
      description: "Video de demostración 720p generado para verificar el pipeline",
      resolutionVariants: "",
      transcodeStatus: "processing",
      transcodeProgress: 0,
      originalFilePath: uniqueName,
    },
  });
  console.log(`   ✓ Asset ID: ${asset.id}`);

  // 5. Transcode!
  console.log(`\n5️⃣  Iniciando transcodificación ABR HLS...`);
  const assetDir = await getAssetDir(asset.id);
  const result = await transcodeToHLS(destPath, assetDir, (pct) => {
    process.stdout.write(`\r   Progreso: ${pct}% ${pct < 100 ? "⏳" : "✓"}`);
  });
  console.log("");

  // 6. Compute URLs
  const masterRel = await absoluteToRelative(result.masterPlaylistPath);
  const thumbRel = await absoluteToRelative(result.thumbnailPath);
  const hlsUrl = `/api/media/${masterRel}`;
  const thumbnailUrl = `/api/media/${thumbRel}`;

  // 7. Update asset with results
  await db.asset.update({
    where: { id: asset.id },
    data: {
      durationMs: result.durationMs,
      hlsUrl,
      thumbnailUrl,
      resolutionVariants: result.variants.map((v) => v.label).join(","),
      transcodeStatus: "completed",
      transcodeProgress: 100,
      originalFilePath: uniqueName,
    },
  });

  console.log(`\n6️⃣  ✓ TRANSCODIFICACIÓN COMPLETADA`);
  console.log(`   • HLS URL: ${hlsUrl}`);
  console.log(`   • Thumbnail: ${thumbnailUrl}`);
  console.log(`   • Duración: ${result.durationMs}ms`);
  console.log(`   • Variantes: ${result.variants.map(v => v.label).join(", ")}`);

  // 8. Verify output files
  console.log(`\n7️⃣  Verificando archivos generados...`);
  const files = await fs.readdir(assetDir, { recursive: true });
  for (const f of files) {
    const fullPath = path.join(assetDir, f.toString());
    const stat = await fs.stat(fullPath);
    if (stat.isFile()) {
      console.log(`   • ${f} (${(stat.size / 1024).toFixed(1)} KB)`);
    }
  }

  console.log(`\n═══════════════════════════════════════════════`);
  console.log(`  ✓ PRUEBA EXITOSA - Asset listo para programar`);
  console.log(`═══════════════════════════════════════════════\n`);
}

main().then(() => process.exit(0)).catch(e => { console.error("ERROR:", e); process.exit(1); });
