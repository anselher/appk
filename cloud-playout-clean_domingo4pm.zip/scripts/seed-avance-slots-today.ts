// Insert the 3 demo Avances into today's schedule as new ScheduleSlots.
// Strategy: take the existing 120 slots for today and insert one Avance slot
// at orderIndex=0, one at orderIndex=60, one at orderIndex=120 (push everything).
// Actually simpler: insert at the END so they're guaranteed visible in the EPG tail.

import { db } from "../src/lib/db";
import { venezuelaDateKeyAsync } from "../src/lib/playout";

async function main() {
  const today = await venezuelaDateKeyAsync(new Date());
  console.log(`Seeding Avance slots for ${today}...`);

  const allAvances = await db.avance.findMany({ orderBy: { createdAt: "asc" } });
  if (allAvances.length === 0) {
    console.log("No Avances found. Run seed-avances.ts first.");
    return;
  }

  // Get the max orderIndex for today.
  const maxSlot = await db.scheduleSlot.findFirst({
    where: { date: today },
    orderBy: { orderIndex: "desc" },
  });
  let nextOrder = maxSlot ? maxSlot.orderIndex + 1 : 0;

  for (const avance of allAvances) {
    // For the legacy assetId field, use the first clip's asset (so the schedule-grid
    // and other legacy codepaths have something to display).
    const firstClip = await db.avanceClip.findFirst({
      where: { avanceId: avance.id },
      orderBy: { orderIndex: "asc" },
      include: { asset: true },
    });
    if (!firstClip) {
      console.log(`  ! Avance ${avance.title} has no clips — skipping.`);
      continue;
    }

    // Check if this Avance is already scheduled for today (idempotent).
    const existing = await db.scheduleSlot.findFirst({
      where: { date: today, avanceId: avance.id },
    });
    if (existing) {
      console.log(`  ~ ${avance.title} already scheduled (slot ${existing.id}) — skipping.`);
      continue;
    }

    const slot = await db.scheduleSlot.create({
      data: {
        date: today,
        orderIndex: nextOrder,
        slotType: "avance",
        assetId: firstClip.assetId,
        avanceId: avance.id,
        fillerLoop: false,
      },
    });
    nextOrder++;
    console.log(`  + Scheduled "${avance.title}" as slot orderIndex=${slot.orderIndex} (slot ${slot.id})`);
  }

  const total = await db.scheduleSlot.count({ where: { date: today } });
  console.log(`\n✓ Done. ${total} slots for ${today} (was 120, now ${total}).`);
}

main()
  .then(() => process.exit(0))
  .catch((e) => {
    console.error(e);
    process.exit(1);
  });
