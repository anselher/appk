#!/bin/bash
# Download ~15 short video clips (<4 min each), transcode to local HLS multi-bitrate,
# generate thumbnails, and register them in the database via the assets API.
#
# Sources used (all public-domain / royalty-free):
#   - test-streams.mux.dev (HLS test streams from Mux — we download them as MP4)
#   - test-videos.co.uk (Big Buck Bunny MP4 clips)
#   - ffmpeg-generated synthetic clips (countdown, color bars, gradient) for variety
#
# Output: 15 new assets in /home/z/my-project/uploads/assets/{cuid}/
# Each asset has: master.m3u8, thumb.jpg, v_240p/, v_360p/, v_480p/, v_720p/
# Registered in DB via direct Prisma insert (no HTTP round-trip).

set -e
cd /home/z/my-project

ORIG_DIR="/home/z/my-project/uploads/originals"
ASSETS_DIR="/home/z/my-project/uploads/assets"
mkdir -p "$ORIG_DIR" "$ASSETS_DIR"

# Helper: log with timestamp
log() {
  echo "[$(date +%H:%M:%S)] $*"
}

# Helper: probe duration (seconds) of a video file
probe_dur_s() {
  ffprobe -v error -show_entries format=duration -of default=noprint_wrappers=1:nokey=1 "$1"
}

# Helper: probe height of a video file
probe_height() {
  ffprobe -v error -select_streams v:0 -show_entries stream=height -of default=noprint_wrappers=1:nokey=1 "$1"
}

# Helper: transcode an MP4 to HLS multi-bitrate (matches src/lib/ffmpeg.ts logic).
# Usage: transcode_hls <input_mp4> <output_dir>
transcode_hls() {
  local input="$1"
  local outdir="$2"
  mkdir -p "$outdir"

  local src_height
  src_height=$(probe_height "$input")
  src_height=${src_height:-360}

  # ABR ladder — same as src/lib/ffmpeg.ts FULL_LADDER
  local variants=()
  if [ "$src_height" -ge 240 ]; then variants+=("240p:426:400k:64k"); fi
  if [ "$src_height" -ge 360 ]; then variants+=("360p:640:800k:96k"); fi
  if [ "$src_height" -ge 480 ]; then variants+=("480p:854:1200k:128k"); fi
  if [ "$src_height" -ge 720 ]; then variants+=("720p:1280:2500k:128k"); fi
  if [ "$src_height" -ge 1080 ]; then variants+=("1080p:1920:5000k:160k"); fi
  if [ "${#variants[@]}" -eq 0 ]; then variants+=("240p:426:400k:64k"); fi

  # Transcode each variant
  for v in "${variants[@]}"; do
    local label height vbit abit
    IFS=':' read -r label height vbit abit <<< "$v"
    local vdir="$outdir/v_${label}"
    mkdir -p "$vdir"
    log "  Transcoding ${label}..."
    ffmpeg -y -i "$input" \
      -vf "scale=${height%:*}:${label%p}:${height}:force_original_aspect_ratio=decrease,pad=${height%:*}:${height}:(ow-iw)/2:(oh-ih)/2" 2>/dev/null || true
    # Use simpler scale that works
    ffmpeg -y -i "$input" \
      -vf "scale=-2:${label%p}" \
      -c:v libx264 -b:v "$vbit" -preset veryfast -g 48 -keyint_min 48 -sc_threshold 0 \
      -profile:v high -level 4.0 -pix_fmt yuv420p \
      -c:a aac -b:a "$abit" -ac 2 -ar 48000 \
      -f hls -hls_time 6 -hls_playlist_type vod \
      -hls_segment_filename "$vdir/seg_%05d.ts" \
      -hls_flags independent_segments \
      "$vdir/index.m3u8" 2>/dev/null
  done

  # Generate master.m3u8
  local master="$outdir/master.m3u8"
  {
    echo "#EXTM3U"
    echo "#EXT-X-VERSION:6"
    # Sort variants highest to lowest (HLS convention)
    local sorted
    sorted=$(printf '%s\n' "${variants[@]}" | sort -t: -k2 -nr)
    for v in $sorted; do
      local label height vbit abit bandwidth
      IFS=':' read -r label height vbit abit <<< "$v"
      bandwidth=$((${vbit%k} * 1000 + ${abit%k} * 1000))
      echo "#EXT-X-STREAM-INF:BANDWIDTH=${bandwidth},RESOLUTION=${height}x${label%p},CODECS=\"avc1.4d4028,mp4a.40.2\""
      echo "v_${label}/index.m3u8"
    done
  } > "$master"

  # Generate thumbnail (frame at 10% of duration, scaled to 360px height)
  local dur_s
  dur_s=$(probe_dur_s "$input")
  dur_s=${dur_s:-10}
  local seek_s
  seek_s=$(awk "BEGIN { print int(($dur_s * 0.1) + 1) }")
  ffmpeg -y -ss "$seek_s" -i "$input" -frames 1 -vf "scale=-2:360" -q:v 4 -f image2 "$outdir/thumb.jpg" 2>/dev/null
}

# Helper: register an asset in the DB via the assets API (POST /api/assets)
# Usage: register_asset <title> <category> <original_filename> <hls_url> <thumb_url> <duration_ms> <original_path>
register_asset() {
  local title="$1"
  local category="$2"
  local filename="$3"
  local hls_url="$4"
  local thumb_url="$5"
  local duration_ms="$6"
  local original_path="$7"

  log "  Registering in DB: ${title} (${category}, ${duration_ms}ms)"
  curl -s -m 10 -X POST http://localhost:3000/api/assets \
    -H "Content-Type: application/json" \
    -d "{
      \"title\": $(printf '%s' "$title" | python3 -c 'import json,sys; print(json.dumps(sys.stdin.read()))'),
      \"category\": \"$category\",
      \"originalFilename\": \"$filename\",
      \"hlsUrl\": \"$hls_url\",
      \"thumbnailUrl\": \"$thumb_url\",
      \"durationMs\": $duration_ms,
      \"originalFilePath\": \"$original_path\"
    }" > /dev/null
}

# ============================================================================
# STEP 1: Download short clips from remote sources
# ============================================================================

log "=== STEP 1: Downloading short clips ==="

# Source A: test-streams.mux.dev (HLS) — download 4 clips of ~60s each
# These are the same streams the existing assets reference, but we'll serve them locally.

declare -a CLIPS=()

# Clip 1: Tears of Steel (mux.dev) — 60s excerpt
log "Downloading Tears of Steel excerpt (60s)..."
ffmpeg -y -i "https://test-streams.mux.dev/tos_ismc/main.m3u8" \
  -t 60 -c copy -bsf:a aac_adtstoasc "$ORIG_DIR/tears_of_steel_60s.mp4" 2>/dev/null
CLIPS+=("tears_of_steel_60s.mp4:Tears of Steel (Capítulo 1):PROGRAM")

# Clip 2: Tears of Steel — another 60s excerpt (different segment)
log "Downloading Tears of Steel excerpt 2 (60s)..."
ffmpeg -y -i "https://test-streams.mux.dev/tos_ismc/main.m3u8" \
  -ss 120 -t 60 -c copy -bsf:a aac_adtstoasc "$ORIG_DIR/tears_of_steel_60s_2.mp4" 2>/dev/null
CLIPS+=("tears_of_steel_60s_2.mp4:Tears of Steel (Capítulo 2):PROGRAM")

# Clip 3: Mux x36xhzz stream — 45s excerpt
log "Downloading Mux Demo (45s)..."
ffmpeg -y -i "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8" \
  -t 45 -c copy -bsf:a aac_adtstoasc "$ORIG_DIR/mux_demo_45s.mp4" 2>/dev/null
CLIPS+=("mux_demo_45s.mp4:Demo Mux 4K:PROGRAM")

# Clip 4: Mux test_001 stream — 30s excerpt
log "Downloading Mux Test 001 (30s)..."
ffmpeg -y -i "https://test-streams.mux.dev/test_001/stream.m3u8" \
  -t 30 -c copy -bsf:a aac_adtstoasc "$ORIG_DIR/mux_test_30s.mp4" 2>/dev/null
CLIPS+=("mux_test_30s.mp4:Stream Test Corto:PROGRAM")

# Clip 5: Mux pts_shift stream — 90s excerpt
log "Downloading Mux PTS Shift (90s)..."
ffmpeg -y -i "https://test-streams.mux.dev/pts_shift/master.m3u8" \
  -t 90 -c copy -bsf:a aac_adtstoasc "$ORIG_DIR/mux_pts_90s.mp4" 2>/dev/null
CLIPS+=("mux_pts_90s.mp4:Demo PTS Shift:PROGRAM")

# Source B: test-videos.co.uk (direct MP4s, smaller and faster)
log "Downloading Big Buck Bunny clips from test-videos.co.uk..."

# Clip 6: BBB 360p 10s 1MB
curl -s -m 30 -L -o "$ORIG_DIR/bbb_360_10s.mp4" \
  "https://test-videos.co.uk/vids/bigbuckbunny/mp4/h264/360/Big_Buck_Bunny_360_10s_1MB.mp4"
CLIPS+=("bbb_360_10s.mp4:Big Buck Bunny (10s):FILLER")

# Clip 7: BBB 360p 10s 2MB
curl -s -m 30 -L -o "$ORIG_DIR/bbb_360_10s_2.mp4" \
  "https://test-videos.co.uk/vids/bigbuckbunny/mp4/h264/360/Big_Buck_Bunny_360_10s_2MB.mp4"
CLIPS+=("bbb_360_10s_2.mp4:Big Buck Bunny (Intro):BUMPER")

# Clip 8: BBB 720p 10s 5MB
curl -s -m 60 -L -o "$ORIG_DIR/bbb_720_10s.mp4" \
  "https://test-videos.co.uk/vids/bigbuckbunny/mp4/h264/720/Big_Buck_Bunny_720_10s_5MB.mp4"
CLIPS+=("bbb_720_10s.mp4:Big Buck Bunny (HD):BUMPER")

# ============================================================================
# STEP 2: Generate synthetic clips with ffmpeg (for variety + guaranteed local)
# These are very fast to generate (a few seconds each) and 100% reliable.
# ============================================================================

log ""
log "=== STEP 2: Generating synthetic clips ==="

# Clip 9: Countdown 10 seconds (BUMPER) — black bg, white countdown number
log "Generating Countdown 10s..."
ffmpeg -y -f lavfi -i "color=c=black:s=1280x720:d=10:r=30" \
  -f lavfi -i "anullsrc=channel_layout=stereo:sample_rate=48000" \
  -vf "drawtext=text='%{eif\:10-t\:d}':fontsize=200:fontcolor=white:x=(w-text_w)/2:y=(h-text_h)/2" \
  -shortest -c:v libx264 -preset veryfast -c:a aac -t 10 \
  "$ORIG_DIR/countdown_10s.mp4" 2>/dev/null
CLIPS+=("countdown_10s.mp4:Cuenta Regresiva 10s:BUMPER")

# Clip 10: Color bars 15s (FILLER) — SMPTE-style color bars
log "Generating Color Bars 15s..."
ffmpeg -y -f lavfi -i "smptebars=s=1280x720:d=15:r=30" \
  -f lavfi -i "anullsrc=channel_layout=stereo:sample_rate=48000" \
  -shortest -c:v libx264 -preset veryfast -c:a aac -t 15 \
  "$ORIG_DIR/color_bars_15s.mp4" 2>/dev/null
CLIPS+=("color_bars_15s.mp4:Barras de Color SMPTE:FILLER")

# Clip 11: Gradient 20s (FILLER) — animated color gradient
log "Generating Gradient 20s..."
ffmpeg -y -f lavfi -i "gradients=s=1280x720:d=20:r=30" \
  -f lavfi -i "anullsrc=channel_layout=stereo:sample_rate=48000" \
  -shortest -c:v libx264 -preset veryfast -c:a aac -t 20 \
  "$ORIG_DIR/gradient_20s.mp4" 2>/dev/null
CLIPS+=("gradient_20s.mp4:Gradiente Animado:FILLER")

# Clip 12: Bumper "Canal Nova" 8s — text card
log "Generating Bumper Nova 8s..."
ffmpeg -y -f lavfi -i "color=c=#1a1a1a:s=1280x720:d=8:r=30" \
  -f lavfi -i "anullsrc=channel_layout=stereo:sample_rate=48000" \
  -vf "drawtext=text='CANAL NOVA':fontsize=120:fontcolor=#fbbf24:x=(w-text_w)/2:y=(h-text_h)/2:shadowcolor=black:shadowx=2:shadowy=2" \
  -vf "drawtext=text='Próximamente':fontsize=40:fontcolor=white:x=(w-text_w)/2:y=h-100" \
  -shortest -c:v libx264 -preset veryfast -c:a aac -t 8 \
  "$ORIG_DIR/bumper_nova_8s.mp4" 2>/dev/null
CLIPS+=("bumper_nova_8s.mp4:Bumper Canal Nova (Sintético):BUMPER")

# Clip 13: Spot "Promo Verano" 15s — text card with summer vibe
log "Generating Spot Verano 15s..."
ffmpeg -y -f lavfi -i "color=c=#fb923c:s=1280x720:d=15:r=30" \
  -f lavfi -i "anullsrc=channel_layout=stereo:sample_rate=48000" \
  -vf "drawtext=text='PROMO VERANO':fontsize=140:fontcolor=white:x=(w-text_w)/2:y=(h-text_h)/2:shadowcolor=black:shadowx=3:shadowy=3,drawtext=text='No te lo pierdas':fontsize=50:fontcolor=#7c2d12:x=(w-text_w)/2:y=h-120" \
  -shortest -c:v libx264 -preset veryfast -c:a aac -t 15 \
  "$ORIG_DIR/spot_verano_15s.mp4" 2>/dev/null
CLIPS+=("spot_verano_15s.mp4:Spot: Promo Verano:SPOT")

# Clip 14: Spot "Banco Andino" 20s
log "Generating Spot Banco 20s..."
ffmpeg -y -f lavfi -i "color=c=#0f766e:s=1280x720:d=20:r=30" \
  -f lavfi -i "anullsrc=channel_layout=stereo:sample_rate=48000" \
  -vf "drawtext=text='BANCO ANDINO':fontsize=130:fontcolor=white:x=(w-text_w)/2:y=(h-text_h)/2:shadowcolor=black:shadowx=2:shadowy=2,drawtext=text='Tu banco, tu futuro':fontsize=45:fontcolor=#ccfbf1:x=(w-text_w)/2:y=h-120" \
  -shortest -c:v libx264 -preset veryfast -c:a aac -t 20 \
  "$ORIG_DIR/spot_banco_20s.mp4" 2>/dev/null
CLIPS+=("spot_banco_20s.mp4:Spot: Banco Andino:SPOT")

# Clip 15: Spot "Aerolínea Caribe" 25s
log "Generating Spot Aerolínea 25s..."
ffmpeg -y -f lavfi -i "color=c=#7c3aed:s=1280x720:d=25:r=30" \
  -f lavfi -i "anullsrc=channel_layout=stereo:sample_rate=48000" \
  -vf "drawtext=text='AEROLÍNEA CARIBE':fontsize=120:fontcolor=white:x=(w-text_w)/2:y=(h-text_h)/2:shadowcolor=black:shadowx=3:shadowy=3,drawtext=text='Vuela lejos, vuela contigo':fontsize=42:fontcolor=#e9d5ff:x=(w-text_w)/2:y=h-120" \
  -shortest -c:v libx264 -preset veryfast -c:a aac -t 25 \
  "$ORIG_DIR/spot_aerolinea_25s.mp4" 2>/dev/null
CLIPS+=("spot_aerolinea_25s.mp4:Spot: Aerolínea Caribe:SPOT")

# Clip 16: Filler "Identificación" 12s
log "Generating Filler Ident 12s..."
ffmpeg -y -f lavfi -i "color=c=#0c4a6e:s=1280x720:d=12:r=30" \
  -f lavfi -i "anullsrc=channel_layout=stereo:sample_rate=48000" \
  -vf "drawtext=text='mitv':fontsize=200:fontcolor=#fbbf24:x=(w-text_w)/2:y=(h-text_h)/2:shadowcolor=black:shadowx=4:shadowy=4,drawtext=text='Te acompañamos siempre':fontsize=35:fontcolor=white:x=(w-text_w)/2:y=h-100" \
  -shortest -c:v libx264 -preset veryfast -c:a aac -t 12 \
  "$ORIG_DIR/filler_ident_12s.mp4" 2>/dev/null
CLIPS+=("filler_ident_12s.mp4:Identificación mitv (Sintético):FILLER")

# Clip 17: Programa "Noticiero Estelar" 30s — title card
log "Generating Noticiero 30s..."
ffmpeg -y -f lavfi -i "color=c=#1e293b:s=1280x720:d=30:r=30" \
  -f lavfi -i "anullsrc=channel_layout=stereo:sample_rate=48000" \
  -vf "drawtext=text='NOTICIERO ESTELAR':fontsize=100:fontcolor=white:x=(w-text_w)/2:y=(h-text_h)/2-60:shadowcolor=black:shadowx=2:shadowy=2,drawtext=text='Edición Central':fontsize=55:fontcolor=#fbbf24:x=(w-text_w)/2:y=(h-text_h)/2+40,drawtext=text='mitv · 22:00':fontsize=40:fontcolor=#94a3b8:x=(w-text_w)/2:y=h-100" \
  -shortest -c:v libx264 -preset veryfast -c:a aac -t 30 \
  "$ORIG_DIR/noticiero_30s.mp4" 2>/dev/null
CLIPS+=("noticiero_30s.mp4:Noticiero Estelar (Cortina):PROGRAM")

# Clip 18: Programa "Documental Naturaleza" 45s
log "Generating Documental 45s..."
ffmpeg -y -f lavfi -i "color=c=#14532d:s=1280x720:d=45:r=30" \
  -f lavfi -i "anullsrc=channel_layout=stereo:sample_rate=48000" \
  -vf "drawtext=text='DOCUMENTAL':fontsize=110:fontcolor=white:x=(w-text_w)/2:y=(h-text_h)/2-50:shadowcolor=black:shadowx=3:shadowy=3,drawtext=text='Naturaleza Salvaje':fontsize=70:fontcolor=#86efac:x=(w-text_w)/2:y=(h-text_h)/2+40,drawtext=text='Próximo en mitv':fontsize=35:fontcolor=#bbf7d0:x=(w-text_w)/2:y=h-100" \
  -shortest -c:v libx264 -preset veryfast -c:a aac -t 45 \
  "$ORIG_DIR/documental_45s.mp4" 2>/dev/null
CLIPS+=("documental_45s.mp4:Documental Naturaleza (Cortina):PROGRAM")

# Clip 19: Bumper "Ya volvemos" 5s
log "Generating Bumper Ya Volvemos 5s..."
ffmpeg -y -f lavfi -i "color=c=#7f1d1d:s=1280x720:d=5:r=30" \
  -f lavfi -i "anullsrc=channel_layout=stereo:sample_rate=48000" \
  -vf "drawtext=text='YA VOLVEMOS':fontsize=140:fontcolor=white:x=(w-text_w)/2:y=(h-text_h)/2:shadowcolor=black:shadowx=3:shadowy=3" \
  -shortest -c:v libx264 -preset veryfast -c:a aac -t 5 \
  "$ORIG_DIR/bumper_ya_volvemos_5s.mp4" 2>/dev/null
CLIPS+=("bumper_ya_volvemos_5s.mp4:Bumper Ya Volvemos:BUMPER")

# Clip 20: Bumper "Continuamos" 5s
log "Generating Bumper Continuamos 5s..."
ffmpeg -y -f lavfi -i "color=c=#166534:s=1280x720:d=5:r=30" \
  -f lavfi -i "anullsrc=channel_layout=stereo:sample_rate=48000" \
  -vf "drawtext=text='CONTINUAMOS':fontsize=140:fontcolor=white:x=(w-text_w)/2:y=(h-text_h)/2:shadowcolor=black:shadowx=3:shadowy=3" \
  -shortest -c:v libx264 -preset veryfast -c:a aac -t 5 \
  "$ORIG_DIR/bumper_continuamos_5s.mp4" 2>/dev/null
CLIPS+=("bumper_continuamos_5s.mp4:Bumper Continuamos:BUMPER")

# ============================================================================
# STEP 3: Transcode each clip to HLS + register in DB
# ============================================================================

log ""
log "=== STEP 3: Transcoding ${#CLIPS[@]} clips to HLS + registering in DB ==="

success=0
failed=0
for entry in "${CLIPS[@]}"; do
  IFS=':' read -r filename title category <<< "$entry"
  input_path="$ORIG_DIR/$filename"

  if [ ! -f "$input_path" ]; then
    log "✗ MISSING: $filename"
    failed=$((failed + 1))
    continue
  fi

  log ""
  log "Processing: $title"

  # Generate a cuid-like ID for the asset directory
  asset_id=$(python3 -c "import secrets; print('c' + secrets.token_hex(12))")
  asset_dir="$ASSETS_DIR/$asset_id"

  # Transcode to HLS
  if ! transcode_hls "$input_path" "$asset_dir" 2>&1; then
    log "✗ Transcode failed for $filename"
    failed=$((failed + 1))
    rm -rf "$asset_dir"
    continue
  fi

  # Probe duration
  dur_s=$(probe_dur_s "$input_path")
  dur_ms=$(awk "BEGIN { print int((${dur_s:-0}) * 1000) }")

  # Build URLs (relative to /api/media/)
  hls_url="/api/media/assets/$asset_id/master.m3u8"
  thumb_url="/api/media/assets/$asset_id/thumb.jpg"

  # Register in DB
  register_asset "$title" "$category" "$filename" "$hls_url" "$thumb_url" "$dur_ms" "originals/$filename"

  log "✓ $title — ${dur_ms}ms — $asset_id"
  success=$((success + 1))
done

log ""
log "=== DONE ==="
log "Successfully processed: $success / ${#CLIPS[@]}"
log "Failed: $failed"
log ""
log "Total assets in DB now:"
curl -s -m 10 http://localhost:3000/api/assets | python3 -c "
import json, sys
d = json.load(sys.stdin)
from collections import Counter
cats = Counter(a['category'] for a in d)
print(f'  Total: {len(d)}')
for cat, count in sorted(cats.items()):
    print(f'    {cat}: {count}')
"