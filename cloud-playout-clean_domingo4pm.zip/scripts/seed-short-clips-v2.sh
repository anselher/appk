#!/bin/bash
# Transcode + register short clips. Optimized version:
# - Only 2 ABR variants (240p + 480p) for speed
# - ultrafast preset
# - Process synthetic clips first (instant)
# - Skip already-processed clips


cd /home/z/my-project

ORIG_DIR="/home/z/my-project/uploads/originals"
ASSETS_DIR="/home/z/my-project/uploads/assets"
mkdir -p "$ORIG_DIR" "$ASSETS_DIR"

log() { echo "[$(date +%H:%M:%S)] $*"; }

probe_dur_s() { ffprobe -v error -show_entries format=duration -of default=noprint_wrappers=1:nokey=1 "$1" 2>/dev/null; }
probe_height() { ffprobe -v error -select_streams v:0 -show_entries stream=height -of default=noprint_wrappers=1:nokey=1 "$1" 2>/dev/null; }

transcode_hls_fast() {
  local input="$1" outdir="$2"
  mkdir -p "$outdir"
  local src_height
  src_height=$(probe_height "$input")
  src_height=${src_height:-360}

  # Only 2 variants for speed: 240p + 480p (or 240p only if source is < 480)
  local variants=()
  variants+=("240p:400k:64k")
  if [ "$src_height" -ge 480 ]; then variants+=("480p:1200k:128k"); fi

  for v in "${variants[@]}"; do
    local label vbit abit vdir
    IFS=':' read -r label vbit abit <<< "$v"
    vdir="$outdir/v_${label}"
    mkdir -p "$vdir"
    ffmpeg -y -loglevel error -i "$input" \
      -vf "scale=-2:${label%p}" \
      -c:v libx264 -b:v "$vbit" -preset ultrafast -g 48 -keyint_min 48 -sc_threshold 0 \
      -profile:v baseline -level 3.0 -pix_fmt yuv420p \
      -c:a aac -b:a "$abit" -ac 2 -ar 48000 \
      -f hls -hls_time 6 -hls_playlist_type vod \
      -hls_segment_filename "$vdir/seg_%05d.ts" \
      -hls_flags independent_segments \
      "$vdir/index.m3u8"
  done

  # master.m3u8
  {
    echo "#EXTM3U"
    echo "#EXT-X-VERSION:6"
    for v in $(printf '%s\n' "${variants[@]}" | sort -t: -k1 -r); do
      IFS=':' read -r label vbit abit <<< "$v"
      local bandwidth=$((${vbit%k} * 1000 + ${abit%k} * 1000))
      local res_height=${label%p}
      local res_width=$((res_height * 16 / 9))
      echo "#EXT-X-STREAM-INF:BANDWIDTH=${bandwidth},RESOLUTION=${res_width}x${res_height},CODECS=\"avc1.42c01e,mp4a.40.2\""
      echo "v_${label}/index.m3u8"
    done
  } > "$outdir/master.m3u8"

  # thumbnail
  local dur_s seek_s
  dur_s=$(probe_dur_s "$input")
  dur_s=${dur_s:-10}
  seek_s=$(awk "BEGIN { print int(($dur_s * 0.1) + 1) }")
  ffmpeg -y -loglevel error -ss "$seek_s" -i "$input" -frames 1 -vf "scale=-2:360" -q:v 4 -f image2 "$outdir/thumb.jpg"
}

register_asset() {
  local title="$1" category="$2" filename="$3" hls_url="$4" thumb_url="$5" duration_ms="$6" original_path="$7"
  local title_json
  title_json=$(printf '%s' "$title" | python3 -c 'import json,sys; print(json.dumps(sys.stdin.read()))')
  curl -s -m 10 -X POST http://localhost:3000/api/assets \
    -H "Content-Type: application/json" \
    -d "{\"title\": $title_json, \"category\": \"$category\", \"originalFilename\": \"$filename\", \"hlsUrl\": \"$hls_url\", \"thumbnailUrl\": \"$thumb_url\", \"durationMs\": $duration_ms, \"originalFilePath\": \"$original_path\"}" \
    > /dev/null
}

process_clip() {
  local filename="$1" title="$2" category="$3"
  local input_path="$ORIG_DIR/$filename"
  if [ ! -f "$input_path" ]; then
    log "✗ MISSING: $filename"
    return 1
  fi
  log "→ $title"
  local asset_id
  asset_id=$(python3 -c "import secrets; print('c' + secrets.token_hex(12))")
  local asset_dir="$ASSETS_DIR/$asset_id"
  if ! transcode_hls_fast "$input_path" "$asset_dir"; then
    log "  ✗ transcode failed"
    rm -rf "$asset_dir"
    return 1
  fi
  local dur_s dur_ms
  dur_s=$(probe_dur_s "$input_path")
  dur_ms=$(awk "BEGIN { print int((${dur_s:-0}) * 1000) }")
  register_asset "$title" "$category" "$filename" \
    "/api/media/assets/$asset_id/master.m3u8" \
    "/api/media/assets/$asset_id/thumb.jpg" \
    "$dur_ms" "originals/$filename"
  log "  ✓ ${dur_ms}ms · $asset_id"
}

# ============================================================================
# STEP A: Generate synthetic clips first (fast, no network)
# ============================================================================

log "=== STEP A: Generate synthetic clips ==="

# 1. Countdown 10s
log "Generating Countdown 10s..."
ffmpeg -nostdin -y -loglevel error -f lavfi -i "color=c=black:s=1280x720:d=10:r=30" \
  -f lavfi -i "anullsrc=channel_layout=stereo:sample_rate=48000" \
  -vf "drawtext=text='%{eif\:10-t\:d}':fontsize=200:fontcolor=white:x=(w-text_w)/2:y=(h-text_h)/2" \
  -shortest -c:v libx264 -preset ultrafast -c:a aac -t 10 \
  "$ORIG_DIR/countdown_10s.mp4"
process_clip "countdown_10s.mp4" "Cuenta Regresiva 10s" "BUMPER"

# 2. Color bars 15s
log "Generating Color Bars 15s..."
ffmpeg -nostdin -y -loglevel error -f lavfi -i "smptebars=s=1280x720:d=15:r=30" \
  -f lavfi -i "anullsrc=channel_layout=stereo:sample_rate=48000" \
  -shortest -c:v libx264 -preset ultrafast -c:a aac -t 15 \
  "$ORIG_DIR/color_bars_15s.mp4"
process_clip "color_bars_15s.mp4" "Barras de Color SMPTE" "FILLER"

# 3. Gradient 20s
log "Generating Gradient 20s..."
ffmpeg -nostdin -y -loglevel error -f lavfi -i "gradients=s=1280x720:d=20:r=30" \
  -f lavfi -i "anullsrc=channel_layout=stereo:sample_rate=48000" \
  -shortest -c:v libx264 -preset ultrafast -c:a aac -t 20 \
  "$ORIG_DIR/gradient_20s.mp4"
process_clip "gradient_20s.mp4" "Gradiente Animado" "FILLER"

# 4. Bumper "Ya volvemos" 5s
log "Generating Bumper Ya Volvemos 5s..."
ffmpeg -nostdin -y -loglevel error -f lavfi -i "color=c=#7f1d1d:s=1280x720:d=5:r=30" \
  -f lavfi -i "anullsrc=channel_layout=stereo:sample_rate=48000" \
  -vf "drawtext=text='YA VOLVEMOS':fontsize=140:fontcolor=white:x=(w-text_w)/2:y=(h-text_h)/2" \
  -shortest -c:v libx264 -preset ultrafast -c:a aac -t 5 \
  "$ORIG_DIR/bumper_ya_volvemos_5s.mp4"
process_clip "bumper_ya_volvemos_5s.mp4" "Bumper Ya Volvemos" "BUMPER"

# 5. Bumper "Continuamos" 5s
log "Generating Bumper Continuamos 5s..."
ffmpeg -nostdin -y -loglevel error -f lavfi -i "color=c=#166534:s=1280x720:d=5:r=30" \
  -f lavfi -i "anullsrc=channel_layout=stereo:sample_rate=48000" \
  -vf "drawtext=text='CONTINUAMOS':fontsize=140:fontcolor=white:x=(w-text_w)/2:y=(h-text_h)/2" \
  -shortest -c:v libx264 -preset ultrafast -c:a aac -t 5 \
  "$ORIG_DIR/bumper_continuamos_5s.mp4"
process_clip "bumper_continuamos_5s.mp4" "Bumper Continuamos" "BUMPER"

# 6. Bumper "Canal Nova" 8s
log "Generating Bumper mitv 8s..."
ffmpeg -nostdin -y -loglevel error -f lavfi -i "color=c=#1a1a1a:s=1280x720:d=8:r=30" \
  -f lavfi -i "anullsrc=channel_layout=stereo:sample_rate=48000" \
  -vf "drawtext=text='mitv':fontsize=200:fontcolor=#fbbf24:x=(w-text_w)/2:y=(h-text_h)/2:shadowcolor=black:shadowx=2:shadowy=2,drawtext=text='Próximamente':fontsize=40:fontcolor=white:x=(w-text_w)/2:y=h-100" \
  -shortest -c:v libx264 -preset ultrafast -c:a aac -t 8 \
  "$ORIG_DIR/bumper_mitv_8s.mp4"
process_clip "bumper_mitv_8s.mp4" "Bumper mitv (Sintético)" "BUMPER"

# 7. Spot "Promo Verano" 15s
log "Generating Spot Verano 15s..."
ffmpeg -nostdin -y -loglevel error -f lavfi -i "color=c=#fb923c:s=1280x720:d=15:r=30" \
  -f lavfi -i "anullsrc=channel_layout=stereo:sample_rate=48000" \
  -vf "drawtext=text='PROMO VERANO':fontsize=140:fontcolor=white:x=(w-text_w)/2:y=(h-text_h)/2:shadowcolor=black:shadowx=3:shadowy=3,drawtext=text='No te lo pierdas':fontsize=50:fontcolor=#7c2d12:x=(w-text_w)/2:y=h-120" \
  -shortest -c:v libx264 -preset ultrafast -c:a aac -t 15 \
  "$ORIG_DIR/spot_verano_15s.mp4"
process_clip "spot_verano_15s.mp4" "Spot: Promo Verano" "SPOT"

# 8. Spot "Banco Andino" 20s
log "Generating Spot Banco 20s..."
ffmpeg -nostdin -y -loglevel error -f lavfi -i "color=c=#0f766e:s=1280x720:d=20:r=30" \
  -f lavfi -i "anullsrc=channel_layout=stereo:sample_rate=48000" \
  -vf "drawtext=text='BANCO ANDINO':fontsize=130:fontcolor=white:x=(w-text_w)/2:y=(h-text_h)/2:shadowcolor=black:shadowx=2:shadowy=2,drawtext=text='Tu banco, tu futuro':fontsize=45:fontcolor=#ccfbf1:x=(w-text_w)/2:y=h-120" \
  -shortest -c:v libx264 -preset ultrafast -c:a aac -t 20 \
  "$ORIG_DIR/spot_banco_20s.mp4"
process_clip "spot_banco_20s.mp4" "Spot: Banco Andino" "SPOT"

# 9. Spot "Aerolínea Caribe" 25s
log "Generating Spot Aerolínea 25s..."
ffmpeg -nostdin -y -loglevel error -f lavfi -i "color=c=#7c3aed:s=1280x720:d=25:r=30" \
  -f lavfi -i "anullsrc=channel_layout=stereo:sample_rate=48000" \
  -vf "drawtext=text='AEROLÍNEA CARIBE':fontsize=120:fontcolor=white:x=(w-text_w)/2:y=(h-text_h)/2:shadowcolor=black:shadowx=3:shadowy=3,drawtext=text='Vuela lejos, vuela contigo':fontsize=42:fontcolor=#e9d5ff:x=(w-text_w)/2:y=h-120" \
  -shortest -c:v libx264 -preset ultrafast -c:a aac -t 25 \
  "$ORIG_DIR/spot_aerolinea_25s.mp4"
process_clip "spot_aerolinea_25s.mp4" "Spot: Aerolínea Caribe" "SPOT"

# 10. Spot "Supermercados Económicos" 30s
log "Generating Spot Supermercados 30s..."
ffmpeg -nostdin -y -loglevel error -f lavfi -i "color=c=#be185d:s=1280x720:d=30:r=30" \
  -f lavfi -i "anullsrc=channel_layout=stereo:sample_rate=48000" \
  -vf "drawtext=text='SUPERMERCADOS ECONÓMICOS':fontsize=90:fontcolor=white:x=(w-text_w)/2:y=(h-text_h)/2-30:shadowcolor=black:shadowx=2:shadowy=2,drawtext=text='Ofertas toda la semana':fontsize=45:fontcolor=#fce7f3:x=(w-text_w)/2:y=h-120" \
  -shortest -c:v libx264 -preset ultrafast -c:a aac -t 30 \
  "$ORIG_DIR/spot_super_30s.mp4"
process_clip "spot_super_30s.mp4" "Spot: Supermercados Económicos" "SPOT"

# 11. Filler "Identificación mitv" 12s
log "Generating Filler Ident 12s..."
ffmpeg -nostdin -y -loglevel error -f lavfi -i "color=c=#0c4a6e:s=1280x720:d=12:r=30" \
  -f lavfi -i "anullsrc=channel_layout=stereo:sample_rate=48000" \
  -vf "drawtext=text='mitv':fontsize=200:fontcolor=#fbbf24:x=(w-text_w)/2:y=(h-text_h)/2:shadowcolor=black:shadowx=4:shadowy=4,drawtext=text='Te acompañamos siempre':fontsize=35:fontcolor=white:x=(w-text_w)/2:y=h-100" \
  -shortest -c:v libx264 -preset ultrafast -c:a aac -t 12 \
  "$ORIG_DIR/filler_ident_12s.mp4"
process_clip "filler_ident_12s.mp4" "Identificación mitv (Sintético)" "FILLER"

# 12. Programa "Noticiero Estelar" 30s
log "Generating Noticiero 30s..."
ffmpeg -nostdin -y -loglevel error -f lavfi -i "color=c=#1e293b:s=1280x720:d=30:r=30" \
  -f lavfi -i "anullsrc=channel_layout=stereo:sample_rate=48000" \
  -vf "drawtext=text='NOTICIERO ESTELAR':fontsize=100:fontcolor=white:x=(w-text_w)/2:y=(h-text_h)/2-60:shadowcolor=black:shadowx=2:shadowy=2,drawtext=text='Edición Central':fontsize=55:fontcolor=#fbbf24:x=(w-text_w)/2:y=(h-text_h)/2+40,drawtext=text='mitv · 22h00':fontsize=40:fontcolor=#94a3b8:x=(w-text_w)/2:y=h-100" \
  -shortest -c:v libx264 -preset ultrafast -c:a aac -t 30 \
  "$ORIG_DIR/noticiero_30s.mp4"
process_clip "noticiero_30s.mp4" "Noticiero Estelar (Cortina)" "PROGRAM"

# 13. programa "Documental Naturaleza" 45s
log "Generating Documental 45s..."
ffmpeg -nostdin -y -loglevel error -f lavfi -i "color=c=#14532d:s=1280x720:d=45:r=30" \
  -f lavfi -i "anullsrc=channel_layout=stereo:sample_rate=48000" \
  -vf "drawtext=text='DOCUMENTAL':fontsize=110:fontcolor=white:x=(w-text_w)/2:y=(h-text_h)/2-50:shadowcolor=black:shadowx=3:shadowy=3,drawtext=text='Naturaleza Salvaje':fontsize=70:fontcolor=#86efac:x=(w-text_w)/2:y=(h-text_h)/2+40,drawtext=text='Próximo en mitv':fontsize=35:fontcolor=#bbf7d0:x=(w-text_w)/2:y=h-100" \
  -shortest -c:v libx264 -preset ultrafast -c:a aac -t 45 \
  "$ORIG_DIR/documental_45s.mp4"
process_clip "documental_45s.mp4" "Documental Naturaleza (Cortina)" "PROGRAM"

# 14. Programa "Concierto Sinfónico" 60s
log "Generating Concierto 60s..."
ffmpeg -nostdin -y -loglevel error -f lavfi -i "color=c=#4c1d95:s=1280x720:d=60:r=30" \
  -f lavfi -i "anullsrc=channel_layout=stereo:sample_rate=48000" \
  -vf "drawtext=text='CONCIERTO SINFÓNICO':fontsize=90:fontcolor=white:x=(w-text_w)/2:y=(h-text_h)/2-50:shadowcolor=black:shadowx=3:shadowy=3,drawtext=text='Orquesta Nacional':fontsize=55:fontcolor=#ddd6fe:x=(w-text_w)/2:y=(h-text_h)/2+30,drawtext=text='mitv Especial':fontsize=35:fontcolor=#c4b5fd:x=(w-text_w)/2:y=h-100" \
  -shortest -c:v libx264 -preset ultrafast -c:a aac -t 60 \
  "$ORIG_DIR/concierto_60s.mp4"
process_clip "concierto_60s.mp4" "Concierto Sinfónico (Cortina)" "PROGRAM"

# 15. Programa "Película Estelar" 90s
log "Generating Película Estelar 90s..."
ffmpeg -nostdin -y -loglevel error -f lavfi -i "color=c=#0c0a09:s=1280x720:d=90:r=30" \
  -f lavfi -i "anullsrc=channel_layout=stereo:sample_rate=48000" \
  -vf "drawtext=text='PELÍCULA ESTELAR':fontsize=100:fontcolor=#fbbf24:x=(w-text_w)/2:y=(h-text_h)/2-50:shadowcolor=black:shadowx=3:shadowy=3,drawtext=text='Esta noche en mitv':fontsize=50:fontcolor=white:x=(w-text_w)/2:y=(h-text_h)/2+30,drawtext=text='No te lo pierdas':fontsize=35:fontcolor=#94a3b8:x=(w-text_w)/2:y=h-100" \
  -shortest -c:v libx264 -preset ultrafast -c:a aac -t 90 \
  "$ORIG_DIR/pelicula_90s.mp4"
process_clip "pelicula_90s.mp4" "Película Estelar (Cortina)" "PROGRAM"

# ============================================================================
# STEP B: Transcode the already-downloaded MP4s (mux + BBB)
# ============================================================================

log ""
log "=== STEP B: Transcode downloaded MP4s ==="

process_clip "mux_test_30s.mp4" "Stream Test Corto" "PROGRAM"
process_clip "mux_demo_45s.mp4" "Demo Mux HD" "PROGRAM"
process_clip "tears_of_steel_60s.mp4" "Tears of Steel (Capítulo 1)" "PROGRAM"
process_clip "tears_of_steel_60s_2.mp4" "Tears of Steel (Capítulo 2)" "PROGRAM"
process_clip "mux_pts_90s.mp4" "Demo PTS Shift" "PROGRAM"
process_clip "bbb_360_10s.mp4" "Big Buck Bunny (10s)" "FILLER"
process_clip "bbb_360_10s_2.mp4" "Big Buck Bunny (Intro)" "BUMPER"
process_clip "bbb_720_10s.mp4" "Big Buck Bunny (HD)" "BUMPER"

# ============================================================================
# Done
# ============================================================================

log ""
log "=== DONE ==="
curl -s -m 10 http://localhost:3000/api/assets | python3 -c "
import json, sys
d = json.load(sys.stdin)
from collections import Counter
cats = Counter(a['category'] for a in d)
print(f'Total assets: {len(d)}')
for cat, count in sorted(cats.items()):
    print(f'  {cat}: {count}')
"