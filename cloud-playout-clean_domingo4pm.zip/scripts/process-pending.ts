// Manual transcode processor — processes any pending assets directly.
// Usage: bun run scripts/process-pending.ts

import { db } from "../src/lib/db";
import { transcodeToHLS } from "../src/lib/ffmpeg";
import { getAssetDir, getOriginalsDir, absoluteToRelative } from "../src/lib/media-storage";
import path from "path";

async function processAsset(assetId: string, originalFilePath: string) {
  console.log(`\n=== Processing asset: ${assetId} ===`);
  console.log(`  Original file: ${originalFilePath}`);

  // Mark as processing.
  await db.asset.update({
    where: { id: assetId },
    data: { transcodeStatus: "processing", transcodeProgress: 0 },
  });

  try {
    const originalsDir = await getOriginalsDir();
    const inputPath = path.join(originalsDir, originalFilePath);
    const assetDir = await getAssetDir(assetId);

    console.log(`  Input: ${inputPath}`);
    console.log(`  Output: ${assetDir}`);

    const result = await transcodeToHLS(inputPath, assetDir, (pct) => {
      console.log(`  Progress: ${pct}%`);
      if (pct % 10 === 0) {
        db.asset.update({
          where: { id: assetId },
          data: { transcodeProgress: pct },
        }).catch(() => {});
      }
    });

    const masterRel = await absoluteToRelative(result.masterPlaylistPath);
    const thumbRel = await absoluteToRelative(result.thumbnailPath);
    const hlsUrl = `/api/media/${masterRel}`;
    const thumbnailUrl = `/api/media/${thumbRel}`;

    await db.asset.update({
      where: { id: assetId },
      data: {
        durationMs: result.durationMs,
        hlsUrl,
        thumbnailUrl,
        resolutionVariants: result.variants.map((v) => v.label).join(","),
        transcodeStatus: "completed",
        transcodeProgress: 100,
        originalFilePath,
      },
    });

    console.log(`  ✓ Completed!`);
    console.log(`    HLS URL: ${hlsUrl}`);
    console.log(`    Thumbnail: ${thumbnailUrl}`);
    console.log(`    Duration: ${result.durationMs}ms`);
    console.log(`    Variants: ${result.variants.map(v => v.label).join(", ")}`);
  } catch (e) {
    const errorMsg = e instanceof Error ? e.message : "unknown error";
    console.error(`  ✗ Failed: ${errorMsg}`);
    await db.asset.update({
      where: { id: assetId },
      data: { transcodeStatus: "failed", transcodeError: errorMsg },
    });
  }
}

async function main() {
  const pending = await db.asset.findMany({
    where: {
      transcodeStatus: { in: ["pending", "processing", "failed"] },
      originalFilePath: { not: null },
    },
    orderBy: { createdAt: "asc" },
  });

  console.log(`Found ${pending.length} pending/failed asset(s) to process.`);

  for (const asset of pending) {
    if (asset.originalFilePath) {
      await processAsset(asset.id, asset.originalFilePath);
    }
  }

  console.log("\nAll done.");
}

main().then(() => process.exit(0)).catch(e => { console.error(e); process.exit(1); });
