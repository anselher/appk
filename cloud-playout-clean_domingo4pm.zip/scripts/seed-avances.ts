// Seed 3 demo Avances into the database (idempotent — keyed by title).
// Run with: bun run scripts/seed-avances.ts
//
// Cases covered (per PO spec):
//   (a) Avance oculto de 4 min — hidden, with 2 clips and explicit cuts.
//   (b) Avance visible — visible, 3 clips, full-length (no cuts).
//   (c) Avance multi-tipo — bumper + promo + programa fragment.

import { db } from "../src/lib/db";

async function upsertAvance(
  title: string,
  opts: { hideFromEpg: boolean; color: string; description?: string },
  clips: Array<{ assetTitle: string; inMs?: number; outMs?: number }>
) {
  // Find or create by title (idempotent).
  let avance = await db.avance.findFirst({ where: { title } });
  if (!avance) {
    avance = await db.avance.create({
      data: {
        title,
        description: opts.description ?? null,
        hideFromEpg: opts.hideFromEpg,
        color: opts.color,
        totalDurationMs: 0,
      },
    });
    console.log(`+ Created Avance: ${title} (${avance.id})`);
  } else {
    // Update metadata + wipe clips (will re-create).
    avance = await db.avance.update({
      where: { id: avance.id },
      data: {
        hideFromEpg: opts.hideFromEpg,
        color: opts.color,
        description: opts.description ?? null,
      },
    });
    await db.avanceClip.deleteMany({ where: { avanceId: avance.id } });
    console.log(`~ Reset existing Avance: ${title} (${avance.id})`);
  }

  for (let i = 0; i < clips.length; i++) {
    const c = clips[i];
    const asset = await db.asset.findFirst({ where: { title: c.assetTitle } });
    if (!asset) {
      console.warn(`  ! Asset not found: ${c.assetTitle} — skipping clip`);
      continue;
    }
    const assetDur = Math.max(asset.durationMs, 1);
    const inMs = Math.max(0, Math.min(c.inMs ?? 0, assetDur - 1));
    const outMs = Math.max(inMs + 1, Math.min(c.outMs && c.outMs > 0 ? c.outMs : assetDur, assetDur));
    await db.avanceClip.create({
      data: {
        avanceId: avance.id,
        assetId: asset.id,
        orderIndex: i,
        inMs,
        outMs,
      },
    });
    console.log(`  - Clip ${i + 1}: ${c.assetTitle} (in=${inMs}ms out=${outMs}ms dur=${outMs - inMs}ms)`);
  }

  // Recompute totalDurationMs.
  const allClips = await db.avanceClip.findMany({
    where: { avanceId: avance.id },
    include: { asset: { select: { durationMs: true } } },
  });
  let total = 0;
  for (const c of allClips) {
    const dur = Math.max(c.asset.durationMs, 1);
    const inMs = Math.max(0, Math.min(c.inMs, dur - 1));
    const outMs = Math.max(inMs + 1, Math.min(c.outMs > 0 ? c.outMs : dur, dur));
    total += outMs - inMs;
  }
  await db.avance.update({ where: { id: avance.id }, data: { totalDurationMs: total } });
  console.log(`  Total duration: ${total}ms (${(total / 60000).toFixed(2)} min)`);
}

async function main() {
  console.log("Seeding 3 demo Avances...\n");

  // (a) Hidden Avance, 4 min total, with cuts.
  // 2 clips: a Spot (15s) + a PROGRAM fragment (3:45 = 225s) → 4:00 total.
  // The PROGRAM clip has an explicit In/Out cut to demo the linear cut editor.
  await upsertAvance(
    "Avance Especial Nocturno (Oculto)",
    {
      hideFromEpg: true,
      color: "violet",
      description: "Bloque oculto de 4 min que se emite entre programas sin aparecer en la EPG.",
    },
    [
      { assetTitle: "Spot: Bebida Tropical", inMs: 0, outMs: 15000 }, // 15s full spot
      // PROGRAM "Misterios del Futuro" (510000ms = 8:30) — cut to 3:45 (225000ms)
      // Start cut at 2:00 (120000ms), end at 5:45 (345000ms) → 225000ms = 3:45
      { assetTitle: "Misterios del Futuro", inMs: 120000, outMs: 345000 },
    ]
  );

  console.log("");

  // (b) Visible Avance, 3 clips, no cuts (full-length).
  // Mix of FILLER (20s) + BUMPER (8s) + SPOT (25s) → 53s.
  await upsertAvance(
    "Cortinilla de Transición Diurna",
    {
      hideFromEpg: false,
      color: "amber",
      description: "Avance visible con 3 clips para transiciones entre bloques diurnos.",
    },
    [
      { assetTitle: "Identificación del Canal" }, // FILLER 15s, full
      { assetTitle: "Bumper Canal Nova" },         // BUMPER 8s, full
      { assetTitle: "Spot: Telecom" },             // SPOT 25s, full
    ]
  );

  console.log("");

  // (c) Multi-tipo Avance: bumper + promo (SPOT) + programa fragment.
  // Bumper (8s) + Spot (30s) + Program cut (90s) → 2:08.
  await upsertAvance(
    "Promo Estelar: Cine Nocturno",
    {
      hideFromEpg: false,
      color: "rose",
      description: "Avance multi-tipo: bumper + spot + fragmento de programa estelar.",
    },
    [
      { assetTitle: "Bumper Canal Nova", inMs: 0, outMs: 8000 },  // BUMPER 8s
      { assetTitle: "Spot: Aerolínea", inMs: 0, outMs: 30000 },   // SPOT 30s
      // PROGRAM "Cine Estelar Nocturno" (734169ms ≈ 12:14) — cut to 90s starting at 5:00
      { assetTitle: "Cine Estelar Nocturno", inMs: 300000, outMs: 390000 }, // 90s
    ]
  );

  console.log("\n✓ Done. 3 Avances seeded.");
  const count = await db.avance.count();
  console.log(`Total Avances in DB: ${count}`);
}

main()
  .then(() => process.exit(0))
  .catch((e) => {
    console.error(e);
    process.exit(1);
  });
