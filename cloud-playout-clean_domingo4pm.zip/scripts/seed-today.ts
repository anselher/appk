import { db } from "../src/lib/db";
import { venezuelaDateKeyAsync } from "../src/lib/playout";

async function main() {
  const today = await venezuelaDateKeyAsync(new Date());
  console.log(`Seeding schedule for ${today}...`);
  
  // Check if there are slots for today
  const existingCount = await db.scheduleSlot.count({ where: { date: today } });
  console.log(`Existing slots for ${today}: ${existingCount}`);
  
  if (existingCount > 0) {
    console.log("Today already has schedule. Skipping.");
    return;
  }
  
  // Find the most recent date with slots
  const recentSlots = await db.scheduleSlot.findMany({
    distinct: ['date'],
    orderBy: { date: 'desc' },
    take: 3,
    select: { date: true },
  });
  console.log("Recent dates with slots:", recentSlots);
  
  if (recentSlots.length === 0) {
    console.log("No slots in DB at all. Running full seed...");
    return;
  }
  
  const sourceDate = recentSlots[0].date;
  console.log(`Copying from ${sourceDate} to ${today}...`);
  
  const sourceSlots = await db.scheduleSlot.findMany({
    where: { date: sourceDate },
    orderBy: { orderIndex: 'asc' },
    include: { cuePoints: true },
  });
  
  for (let i = 0; i < sourceSlots.length; i++) {
    const src = sourceSlots[i];
    const newSlot = await db.scheduleSlot.create({
      data: {
        date: today,
        orderIndex: i,
        assetId: src.assetId,
        fillerLoop: src.fillerLoop,
      },
    });
    for (const cp of src.cuePoints) {
      await db.cuePoint.create({
        data: {
          scheduleSlotId: newSlot.id,
          offsetMs: cp.offsetMs,
          adBreakId: cp.adBreakId,
        },
      });
    }
  }
  
  const finalCount = await db.scheduleSlot.count({ where: { date: today } });
  console.log(`✓ Done. ${finalCount} slots created for ${today}`);
}

main().then(() => process.exit(0)).catch(e => { console.error(e); process.exit(1); });
