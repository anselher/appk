import { probeVideo, transcodeToHLS, getAdaptiveLadder } from "../src/lib/ffmpeg";

async function main() {
  const input = "/tmp/test_5sec.mp4";
  console.log("Probing video...");
  const probe = await probeVideo(input);
  console.log("Probe result:", probe);

  console.log("Adaptive ladder:", getAdaptiveLadder(probe.height));

  console.log("Transcoding to HLS...");
  const result = await transcodeToHLS(input, "/tmp/test_hls_output", (pct) => {
    console.log(`  Progress: ${pct}%`);
  });
  console.log("Transcode result:", {
    masterPlaylistPath: result.masterPlaylistPath,
    thumbnailPath: result.thumbnailPath,
    variants: result.variants.map(v => v.label),
    durationMs: result.durationMs,
    width: result.width,
    height: result.height,
  });
}
main().then(() => process.exit(0)).catch(e => { console.error(e); process.exit(1); });
