import { db } from "../src/lib/db";
async function main() {
  const count = await db.asset.count();
  console.log(`Assets in DB: ${count}`);
  const all = await db.asset.findMany({ select: { id: true, title: true, transcodeStatus: true, originalFilePath: true } });
  for (const a of all) {
    console.log(`  - ${a.title} [${a.transcodeStatus}] ${a.originalFilePath ? "(uploaded)" : ""}`);
  }
}
main().then(() => process.exit(0)).catch(e => { console.error(e); process.exit(1); });
