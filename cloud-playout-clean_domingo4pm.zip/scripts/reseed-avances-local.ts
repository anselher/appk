// Re-seed the 3 demo Avances using LOCAL assets (served from /api/media/)
// instead of the remote HLS streams from mux.dev which are slow.
// This makes the Avance playback fast for testing.
//
// Run with: bun run scripts/reseed-avances-local.ts

import { db } from "../src/lib/db";

async function upsertAvance(
  title: string,
  opts: { hideFromEpg: boolean; color: string; description?: string },
  clips: Array<{ assetTitle: string; inMs?: number; outMs?: number }>
) {
  let avance = await db.avance.findFirst({ where: { title } });
  if (!avance) {
    avance = await db.avance.create({
      data: {
        title,
        description: opts.description ?? null,
        hideFromEpg: opts.hideFromEpg,
        color: opts.color,
        totalDurationMs: 0,
      },
    });
    console.log(`+ Created Avance: ${title} (${avance.id})`);
  } else {
    avance = await db.avance.update({
      where: { id: avance.id },
      data: {
        hideFromEpg: opts.hideFromEpg,
        color: opts.color,
        description: opts.description ?? null,
      },
    });
    await db.avanceClip.deleteMany({ where: { avanceId: avance.id } });
    console.log(`~ Reset existing Avance: ${title} (${avance.id})`);
  }

  for (let i = 0; i < clips.length; i++) {
    const c = clips[i];
    const asset = await db.asset.findFirst({ where: { title: c.assetTitle } });
    if (!asset) {
      console.warn(`  ! Asset not found: ${c.assetTitle} — skipping clip`);
      continue;
    }
    const assetDur = Math.max(asset.durationMs, 1);
    const inMs = Math.max(0, Math.min(c.inMs ?? 0, assetDur - 1));
    const outMs = Math.max(inMs + 1, Math.min(c.outMs && c.outMs > 0 ? c.outMs : assetDur, assetDur));
    await db.avanceClip.create({
      data: {
        avanceId: avance.id,
        assetId: asset.id,
        orderIndex: i,
        inMs,
        outMs,
      },
    });
    console.log(`  - Clip ${i + 1}: ${c.assetTitle} (in=${inMs}ms out=${outMs}ms dur=${outMs - inMs}ms) [local HLS]`);
  }

  const allClips = await db.avanceClip.findMany({
    where: { avanceId: avance.id },
    include: { asset: { select: { durationMs: true } } },
  });
  let total = 0;
  for (const c of allClips) {
    const dur = Math.max(c.asset.durationMs, 1);
    const inMs = Math.max(0, Math.min(c.inMs, dur - 1));
    const outMs = Math.max(inMs + 1, Math.min(c.outMs > 0 ? c.outMs : dur, dur));
    total += outMs - inMs;
  }
  await db.avance.update({ where: { id: avance.id }, data: { totalDurationMs: total } });
  console.log(`  Total duration: ${total}ms (${(total / 60000).toFixed(2)} min)`);
}

async function main() {
  console.log("Re-seeding 3 demo Avances with LOCAL assets...\n");

  // (a) Hidden Avance, 4 min — use local PROGRAM + local SPOT
  await upsertAvance(
    "Avance Especial Nocturno (Oculto)",
    {
      hideFromEpg: true,
      color: "violet",
      description: "Bloque oculto de ~4 min que se emite entre programas sin aparecer en la EPG. Usa assets locales.",
    },
    [
      { assetTitle: "Spot: Promo Verano" }, // 15s local spot
      // Use Documental (45s) but cut to a 15s fragment
      { assetTitle: "Documental Naturaleza (Cortina)", inMs: 5000, outMs: 20000 }, // 15s excerpt
      // Add Noticiero 30s
      { assetTitle: "Noticiero Estelar (Cortina)", inMs: 0, outMs: 30000 },
      // Add Bumper Ya Volvemos 5s
      { assetTitle: "Bumper Ya Volvemos" },
      // Add Concierto 60s + cut
      { assetTitle: "Concierto Sinfónico (Cortina)", inMs: 10000, outMs: 40 }, // edge case test (will clamp)
      { assetTitle: "Concierto Sinfónico (Cortina)", inMs: 10000, outMs: 40000 }, // 30s excerpt
      // Fill rest with Película to reach ~4 min
      { assetTitle: "Película Estelar (Cortina)", inMs: 0, outMs: 75000 }, // 75s excerpt
      // Hmm let me just compute: 15 + 15 + 30 + 5 + 30 + 75 = 170s = 2:50, need ~4 min
      // Add 60s more from Tears of Steel
      { assetTitle: "Tears of Steel (Capítulo 1)" }, // 60s full = total 230s = 3:50, close enough
    ]
  );

  console.log("");

  // (b) Visible Avance, 3 local clips
  await upsertAvance(
    "Cortinilla de Transición Diurna",
    {
      hideFromEpg: false,
      color: "amber",
      description: "Avance visible con 3 clips locales para transiciones entre bloques.",
    },
    [
      { assetTitle: "Identificación mitv (Sintético)" }, // 12s
      { assetTitle: "Bumper mitv (Sintético)" }, // 8s
      { assetTitle: "Spot: Banco Andino" }, // 20s
    ]
  );

  console.log("");

  // (c) Multi-tipo Avance: bumper + spot + program cut
  await upsertAvance(
    "Promo Estelar: Cine Nocturno",
    {
      hideFromEpg: false,
      color: "rose",
      description: "Avance multi-tipo con assets locales: bumper + spot + fragmento de programa.",
    },
    [
      { assetTitle: "Bumper Continuamos" }, // 5s
      { assetTitle: "Spot: Aerolínea Caribe" }, // 25s
      // Cut Tears of Steel Cap 1 to 60s starting at 10s
      { assetTitle: "Tears of Steel (Capítulo 1)", inMs: 10000, outMs: 70000 }, // 60s excerpt
    ]
  );

  console.log("\n✓ Done. 3 Avances re-seeded with local assets.");
}

main()
  .then(() => process.exit(0))
  .catch((e) => {
    console.error(e);
    process.exit(1);
  });
