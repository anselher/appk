// Seed script — populates the database with sample assets, a 24h schedule,
// cue points, ad breaks, and channel settings for the Cloud Playout System.
// Run with: bun run seed

import { db } from "../src/lib/db";

// Reliable free HLS streams (Mux test CDN) — all verified with CORS * and real video content.
// Durations verified by fetching manifests:
//   bbb  = Big Buck Bunny (Blender) ~634s / 10.6min  🐰
//   tos  = Tears of Steel (Blender) ~510s / 8.5min
//   tos4k= Tears of Steel 4K           ~734s / 12.2min
//   pts  = pts_shift test pattern      ~165s / 2.75min (good for fillers/spots)
const STREAMS = {
  bbb: "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8",
  tos: "https://test-streams.mux.dev/test_001/stream.m3u8",
  tos4k: "https://test-streams.mux.dev/tos_ismc/main.m3u8",
  pts: "https://test-streams.mux.dev/pts_shift/master.m3u8",
};

async function main() {
  console.log("Seeding Cloud Playout System...");

  // Wipe all data (idempotent re-seed).
  await db.cuePoint.deleteMany({});
  await db.adBreakEntry.deleteMany({});
  await db.adBreak.deleteMany({});
  await db.scheduleSlot.deleteMany({});
  await db.asset.deleteMany({});

  // ---- Channel settings ----
  const settings: Record<string, string> = {
    channelName: "Canal Nova",
    channelLogo: "NV",
    playerSide: "left",
    liveSync: "true",
    previewDays: "2",
    slateMessage: "Su programación continuará en {s} segundos",
    timezone: "America/Caracas",
    fillFillerAssetId: "",
  };
  for (const [key, value] of Object.entries(settings)) {
    await db.channelSetting.upsert({
      where: { key },
      update: { value },
      create: { key, value },
    });
  }

  // ---- Assets: Programs ----
  // Durations match the real video sources so the schedule is accurate.
  // The player loops the source within each slot, so these are exact.
  const programs = [
    { title: "Big Buck Bunny", file: "big-buck-bunny.mp4", dur: 634584, url: STREAMS.bbb, thumb: "🐰", desc: "Cortometraje animado de Blender sobre un conejo en el bosque." },
    { title: "Tears of Steel", file: "tears-of-steel.mp4", dur: 510000, url: STREAMS.tos, thumb: "🤖", desc: "Cortometraje sci-fi de Blender: batalla por el futuro de Ámsterdam." },
    { title: "Tears of Steel (4K)", file: "tears-of-steel-4k.mp4", dur: 734169, url: STREAMS.tos4k, thumb: "🎬", desc: "La misma epopeya sci-fi en máxima resolución 4K cinematográfica." },
    { title: "Aventuras del Bosque", file: "aventuras-bosque.mp4", dur: 634584, url: STREAMS.bbb, thumb: "🌳", desc: "Naturaleza y vida silvestre en el corazón del bosque tropical." },
    { title: "Misterios del Futuro", file: "misterios-futuro.mp4", dur: 510000, url: STREAMS.tos, thumb: "🚀", desc: "Exploración de tecnologías que cambiarán el mañana." },
    { title: "Cine Estelar Nocturno", file: "cine-estelar.mp4", dur: 734169, url: STREAMS.tos4k, thumb: "🎞️", desc: "La mejor selección de cine independiente internacional." },
    { title: "El Conejito Aventurero", file: "conejito-aventurero.mp4", dur: 634584, url: STREAMS.bbb, thumb: "🐇", desc: "Las travesuras de un conejo valiente en la pradera." },
    { title: "Crónicas del Acero", file: "cronicas-acero.mp4", dur: 510000, url: STREAMS.tos, thumb: "⚙️", desc: "Documental sobre la ingeniería detrás de las grandes ciudades." },
  ];

  const programAssets = [];
  for (const p of programs) {
    const a = await db.asset.create({
      data: {
        title: p.title,
        originalFilename: p.file,
        category: "PROGRAM",
        durationMs: p.dur,
        hlsUrl: p.url,
        thumbnailUrl: p.thumb,
        description: p.desc,
        resolutionVariants: "240p,480p,720p,1080p",
      },
    });
    programAssets.push(a);
  }

  // ---- Assets: Fillers (station IDs / bumpers) ----
  // Short slot durations; the player loops the pts_shift source within each.
  const fillers = [
    { title: "Identificación del Canal", file: "station-id-01.mp4", dur: 15000, url: STREAMS.pts, thumb: "🆔" },
    { title: "Bumper Noche", file: "bumper-noche.mp4", dur: 12000, url: STREAMS.tos, thumb: "🌙" },
    { title: "Relleno Floral", file: "filler-floral.mp4", dur: 20000, url: STREAMS.bbb, thumb: "🌸" },
  ];
  const fillerAssets = [];
  for (const f of fillers) {
    const a = await db.asset.create({
      data: {
        title: f.title,
        originalFilename: f.file,
        category: "FILLER",
        durationMs: f.dur,
        hlsUrl: f.url,
        thumbnailUrl: f.thumb,
        description: "Contenido de planta del canal.",
        resolutionVariants: "240p,480p,720p",
      },
    });
    fillerAssets.push(a);
  }

  // ---- Assets: Spots (commercials) ----
  // Short commercial durations; the player loops within the source video.
  const spots = [
    { title: "Spot: Automotriz Andina", file: "spot-automotriz.mp4", dur: 30000, url: STREAMS.bbb, thumb: "🚗" },
    { title: "Spot: Banco Caracas", file: "spot-banco.mp4", dur: 20000, url: STREAMS.tos, thumb: "🏦" },
    { title: "Spot: Bebida Tropical", file: "spot-bebida.mp4", dur: 15000, url: STREAMS.tos4k, thumb: "🥤" },
    { title: "Spot: Telecom", file: "spot-telecom.mp4", dur: 25000, url: STREAMS.pts, thumb: "📱" },
    { title: "Spot: Supermercados", file: "spot-super.mp4", dur: 20000, url: STREAMS.bbb, thumb: "🛒" },
    { title: "Spot: Aerolínea", file: "spot-aerolinea.mp4", dur: 30000, url: STREAMS.tos, thumb: "✈️" },
  ];
  const spotAssets = [];
  for (const sp of spots) {
    const a = await db.asset.create({
      data: {
        title: sp.title,
        originalFilename: sp.file,
        category: "SPOT",
        durationMs: sp.dur,
        hlsUrl: sp.url,
        thumbnailUrl: sp.thumb,
        description: "Comercial publicitario.",
        resolutionVariants: "240p,480p,720p",
      },
    });
    spotAssets.push(a);
  }

  // ---- Ad breaks (pods) ----
  const adBreak1 = await db.adBreak.create({
    data: {
      name: "Bloque Publicitario A",
      slateMessage: "Su programación continuará en {s} segundos",
      showSlate: true,
    },
  });
  // entries
  const ab1Entries = [spotAssets[0], spotAssets[1], spotAssets[2]];
  for (let i = 0; i < ab1Entries.length; i++) {
    await db.adBreakEntry.create({
      data: { adBreakId: adBreak1.id, assetId: ab1Entries[i].id, orderIndex: i },
    });
  }

  const adBreak2 = await db.adBreak.create({
    data: {
      name: "Bloque Publicitario B",
      slateMessage: "Volvemos en {s} segundos",
      showSlate: true,
    },
  });
  const ab2Entries = [spotAssets[3], spotAssets[4]];
  for (let i = 0; i < ab2Entries.length; i++) {
    await db.adBreakEntry.create({
      data: { adBreakId: adBreak2.id, assetId: ab2Entries[i].id, orderIndex: i },
    });
  }

  const adBreak3 = await db.adBreak.create({
    data: {
      name: "Bloque Premium",
      slateMessage: "No se vaya, volvemos en {s} segundos",
      showSlate: true,
    },
  });
  const ab3Entries = [spotAssets[5], spotAssets[0], spotAssets[3]];
  for (let i = 0; i < ab3Entries.length; i++) {
    await db.adBreakEntry.create({
      data: { adBreakId: adBreak3.id, assetId: ab3Entries[i].id, orderIndex: i },
    });
  }

  // ---- Schedule for today (Venezuela) ----
  // Build a full 24h grid: cycle through the program catalog with cue points
  // until the cumulative wallclock duration fills the day. Snap-to-tail computes
  // the actual start times at read time.
  const today = getVenezuelaDateKey(new Date());

  // Each template: { assetIndex, cues: [{ offsetMs, break }] }
  // Offsets are within each program's real duration (8-12 min).
  const templates = [
    { ai: 0, cues: [{ offset: 180000, break: adBreak1 }, { offset: 420000, break: adBreak2 }] }, // BBB 10.6m: 3:00 + 7:00
    { ai: 1, cues: [{ offset: 240000, break: adBreak2 }] }, // ToS 8.5m: 4:00
    { ai: 2, cues: [{ offset: 300000, break: adBreak3 }, { offset: 540000, break: adBreak1 }] }, // ToS-4K 12.2m: 5:00 + 9:00
    { ai: 3, cues: [{ offset: 200000, break: adBreak2 }, { offset: 480000, break: adBreak3 }] }, // Bosque 10.6m: 3:20 + 8:00
    { ai: 4, cues: [{ offset: 260000, break: adBreak1 }] }, // Futuro 8.5m: 4:20
    { ai: 5, cues: [{ offset: 360000, break: adBreak3 }, { offset: 600000, break: adBreak2 }] }, // Cine 12.2m: 6:00 + 10:00
    { ai: 6, cues: [{ offset: 220000, break: adBreak2 }] }, // Conejito 10.6m: 3:40
    { ai: 7, cues: [{ offset: 180000, break: adBreak1 }, { offset: 380000, break: adBreak3 }] }, // Acero 8.5m: 3:00 + 6:20
  ];

  // Helper: wallclock duration of a template = program duration + sum of its ad break durations.
  const adBreakDuration = (b: { entries: { assetId: string }[] }) => {
    return abDurationMap.get((b as unknown as { id: string }).id) ?? 0;
  };
  const abDurationMap = new Map<string, number>();
  for (const ab of [adBreak1, adBreak2, adBreak3]) {
    const entries = await db.adBreakEntry.findMany({
      where: { adBreakId: ab.id },
      include: { asset: true },
    });
    abDurationMap.set(ab.id, entries.reduce((s, e) => s + e.asset.durationMs, 0));
  }

  const DAY_MS = 24 * 3600 * 1000;
  let cumulativeMs = 0;
  let orderIndex = 0;
  while (cumulativeMs < DAY_MS - 5 * 60 * 1000) {
    const tpl = templates[orderIndex % templates.length];
    const asset = programAssets[tpl.ai];
    let wall = asset.durationMs;
    for (const c of tpl.cues) wall += adBreakDuration(c.break);
    if (cumulativeMs + wall > DAY_MS && orderIndex > 0) {
      // Stop if the next program would overflow (leave a small filler tail).
      break;
    }
    const slot = await db.scheduleSlot.create({
      data: {
        date: today,
        orderIndex,
        assetId: asset.id,
        fillerLoop: false,
      },
    });
    for (const c of tpl.cues) {
      await db.cuePoint.create({
        data: {
          scheduleSlotId: slot.id,
          offsetMs: c.offset,
          adBreakId: c.break.id,
        },
      });
    }
    cumulativeMs += wall;
    orderIndex++;
  }

  // Set the default filler for gap-filling.
  await db.channelSetting.update({
    where: { key: "fillFillerAssetId" },
    data: { value: fillerAssets[0].id },
  });

  const scheduledCount = await db.scheduleSlot.count({ where: { date: today } });
  console.log("Seed complete ✓");
  console.log(`  - ${programAssets.length} programs`);
  console.log(`  - ${fillerAssets.length} fillers`);
  console.log(`  - ${spotAssets.length} spots`);
  console.log(`  - 3 ad breaks`);
  console.log(`  - ${scheduledCount} scheduled slots for ${today} (~${Math.round(cumulativeMs / 3600000)}h programmed)`);
}

// Mirror of venezuelaDateKey to avoid importing server-only code here.
function getVenezuelaDateKey(d: Date): string {
  const utcMs = d.getTime() + d.getTimezoneOffset() * 60000;
  const caracas = new Date(utcMs - 4 * 3600000);
  const y = caracas.getUTCFullYear();
  const m = String(caracas.getUTCMonth() + 1).padStart(2, "0");
  const day = String(caracas.getUTCDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await db.$disconnect();
  });
