import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getChannelSettings } from "@/lib/playout";

// GET /api/settings — channel settings + media config.
export async function GET() {
  const settings = await getChannelSettings();
  // Also fetch media storage path + ffmpeg path + timezone offset from DB.
  const mediaPathRow = await db.channelSetting.findUnique({ where: { key: "mediaStoragePath" } });
  const ffmpegPathRow = await db.channelSetting.findUnique({ where: { key: "ffmpegPath" } });
  const tzOffsetRow = await db.channelSetting.findUnique({ where: { key: "timezoneOffset" } });
  return NextResponse.json({
    ...settings,
    mediaStoragePath: mediaPathRow?.value || "./uploads",
    ffmpegPath: ffmpegPathRow?.value || "",
    timezoneOffset: tzOffsetRow?.value || "-4",
  });
}

// PATCH /api/settings — update channel settings.
export async function PATCH(req: NextRequest) {
  try {
    const body = await req.json();
    const keys: Record<string, string> = {
      channelName: "channelName",
      channelLogo: "channelLogo",
      playerSide: "playerSide",
      liveSync: "liveSync",
      previewDays: "previewDays",
      slateMessage: "slateMessage",
      timezone: "timezone",
      fillFillerAssetId: "fillFillerAssetId",
      mediaStoragePath: "mediaStoragePath",
      ffmpegPath: "ffmpegPath",
      timezoneOffset: "timezoneOffset",
      showBroadcastTicker: "showBroadcastTicker",
      disablePause: "disablePause",
    };
    for (const [bodyKey, dbKey] of Object.entries(keys)) {
      if (bodyKey in body) {
        const val = body[bodyKey];
        const strVal = typeof val === "boolean" ? String(val) : String(val ?? "");
        await db.channelSetting.upsert({
          where: { key: dbKey },
          update: { value: strVal },
          create: { key: dbKey, value: strVal },
        });
      }
    }
    const settings = await getChannelSettings();
    const mediaPathRow = await db.channelSetting.findUnique({ where: { key: "mediaStoragePath" } });
    const ffmpegPathRow = await db.channelSetting.findUnique({ where: { key: "ffmpegPath" } });
    const tzOffsetRow = await db.channelSetting.findUnique({ where: { key: "timezoneOffset" } });
    return NextResponse.json({
      ...settings,
      mediaStoragePath: mediaPathRow?.value || "./uploads",
      ffmpegPath: ffmpegPathRow?.value || "",
      timezoneOffset: tzOffsetRow?.value || "-4",
    });
  } catch (e) {
    return NextResponse.json(
      { error: e instanceof Error ? e.message : "internal error" },
      { status: 500 }
    );
  }
}
