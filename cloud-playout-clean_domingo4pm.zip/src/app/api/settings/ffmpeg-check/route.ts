import { NextResponse } from "next/server";
import { checkFfmpegAvailable } from "@/lib/ffmpeg";

// GET /api/settings/ffmpeg-check — verify FFmpeg is available and working.
export async function GET() {
  const result = await checkFfmpegAvailable();
  return NextResponse.json(result, { status: result.ok ? 200 : 503 });
}
