import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { startTranscodeJob } from "@/lib/transcode-jobs";

// POST /api/assets/process-pending
// Finds all assets with status "pending" or "processing" (stuck) and restarts their transcode jobs.
// Useful after a server restart to resume interrupted transcoding.
export async function POST() {
  try {
    const pending = await db.asset.findMany({
      where: {
        transcodeStatus: { in: ["pending", "processing"] },
        originalFilePath: { not: null },
      },
      select: { id: true, title: true, originalFilePath: true, transcodeStatus: true },
    });

    let restarted = 0;
    for (const asset of pending) {
      if (asset.originalFilePath) {
        startTranscodeJob(asset.id, asset.originalFilePath);
        restarted++;
      }
    }

    return NextResponse.json({
      found: pending.length,
      restarted,
      assets: pending.map((a) => ({ id: a.id, title: a.title, status: a.transcodeStatus })),
    });
  } catch (e) {
    return NextResponse.json(
      { error: e instanceof Error ? e.message : "internal error" },
      { status: 500 }
    );
  }
}
