import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

// GET /api/assets?category=PROGRAM|FILLER|SPOT
export async function GET(req: NextRequest) {
  const category = req.nextUrl.searchParams.get("category");
  const assets = await db.asset.findMany({
    where: category ? { category } : undefined,
    orderBy: { createdAt: "desc" },
  });
  return NextResponse.json(assets);
}

// POST /api/assets — create a new asset (simulated upload + transcoding).
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const {
      title,
      originalFilename,
      category,
      durationMs,
      hlsUrl,
      thumbnailUrl,
      description,
      resolutionVariants,
    } = body;
    if (!title || !originalFilename || !category || !durationMs || !hlsUrl) {
      return NextResponse.json(
        { error: "Faltan campos: title, originalFilename, category, durationMs, hlsUrl" },
        { status: 400 }
      );
    }
    const asset = await db.asset.create({
      data: {
        title,
        originalFilename,
        category,
        durationMs: Number(durationMs),
        hlsUrl,
        thumbnailUrl: thumbnailUrl || null,
        description: description || null,
        resolutionVariants: resolutionVariants || "240p,480p,720p,1080p",
      },
    });
    return NextResponse.json(asset, { status: 201 });
  } catch (e) {
    return NextResponse.json(
      { error: e instanceof Error ? e.message : "internal error" },
      { status: 500 }
    );
  }
}
