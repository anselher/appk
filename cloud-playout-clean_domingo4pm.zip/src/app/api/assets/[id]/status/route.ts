import { NextRequest, NextResponse } from "next/server";
import { getJobStatus } from "@/lib/transcode-jobs";
import { db } from "@/lib/db";

// GET /api/assets/[id]/status — returns the current transcoding status of an asset.
export async function GET(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const job = await getJobStatus(id);

    // Also fetch the asset to include the final HLS URL if completed.
    const asset = await db.asset.findUnique({
      where: { id },
      select: {
        id: true,
        title: true,
        hlsUrl: true,
        thumbnailUrl: true,
        durationMs: true,
        resolutionVariants: true,
        transcodeStatus: true,
        transcodeProgress: true,
        transcodeError: true,
      },
    });

    if (!asset) {
      return NextResponse.json({ error: "Asset not found" }, { status: 404 });
    }

    return NextResponse.json({
      assetId: id,
      status: job.status,
      progress: job.progress,
      error: job.error,
      hlsUrl: asset.hlsUrl || null,
      thumbnailUrl: asset.thumbnailUrl || null,
      durationMs: asset.durationMs,
      resolutionVariants: asset.resolutionVariants || null,
    });
  } catch (e) {
    return NextResponse.json(
      { error: e instanceof Error ? e.message : "internal error" },
      { status: 500 }
    );
  }
}

// POST /api/assets/[id]/status — retry a failed transcode job.
export async function POST(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const { retryTranscodeJob } = await import("@/lib/transcode-jobs");
    await retryTranscodeJob(id);
    return NextResponse.json({ ok: true, message: "Retry started" });
  } catch (e) {
    return NextResponse.json(
      { error: e instanceof Error ? e.message : "internal error" },
      { status: 500 }
    );
  }
}
