import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

// PATCH /api/assets/[id] — edit metadata (title preserved originalFilename).
export async function PATCH(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const body = await req.json();
    const allowed = [
      "title",
      "originalFilename",
      "category",
      "durationMs",
      "hlsUrl",
      "thumbnailUrl",
      "description",
      "resolutionVariants",
    ];
    const data: Record<string, unknown> = {};
    for (const k of allowed) {
      if (k in body) data[k] = body[k];
    }
    const asset = await db.asset.update({ where: { id }, data });
    return NextResponse.json(asset);
  } catch (e) {
    return NextResponse.json(
      { error: e instanceof Error ? e.message : "internal error" },
      { status: 500 }
    );
  }
}

export async function DELETE(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    await db.asset.delete({ where: { id } });
    return NextResponse.json({ ok: true });
  } catch (e) {
    return NextResponse.json(
      { error: e instanceof Error ? e.message : "internal error" },
      { status: 500 }
    );
  }
}
