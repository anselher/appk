import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getOriginalsDir } from "@/lib/media-storage";
import { startTranscodeJob } from "@/lib/transcode-jobs";
import { promises as fs } from "fs";
import path from "path";
import crypto from "crypto";

// POST /api/assets/import-url
// Body: { url, title, category, description? }
// Downloads the file from the URL, then starts the transcode pipeline.
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { url, title, category, description } = body;

    if (!url || typeof url !== "string") {
      return NextResponse.json({ error: "URL es obligatoria" }, { status: 400 });
    }
    if (!title || typeof title !== "string") {
      return NextResponse.json({ error: "El título es obligatorio" }, { status: 400 });
    }
    const cat = category || "PROGRAM";
    if (!["PROGRAM", "FILLER", "SPOT"].includes(cat)) {
      return NextResponse.json({ error: "Categoría inválida" }, { status: 400 });
    }

    // Parse URL to extract filename.
    let urlObj: URL;
    try {
      urlObj = new URL(url);
    } catch {
      return NextResponse.json({ error: "URL inválida" }, { status: 400 });
    }

    const urlPath = urlObj.pathname;
    const ext = path.extname(urlPath).toLowerCase() || ".mp4";
    const allowedExtensions = [".mp4", ".mov", ".avi", ".mkv", ".webm", ".mpeg", ".mpg", ".flv"];
    if (!allowedExtensions.includes(ext)) {
      return NextResponse.json(
        { error: `Extensión no soportada: ${ext}` },
        { status: 400 }
      );
    }

    // Download the file.
    const uniqueName = `${crypto.randomUUID()}_imported${ext}`;
    const originalsDir = await getOriginalsDir();
    const filePath = path.join(originalsDir, uniqueName);

    const response = await fetch(url, { redirect: "follow" });
    if (!response.ok) {
      return NextResponse.json(
        { error: `Error descargando URL: HTTP ${response.status}` },
        { status: 400 }
      );
    }
    if (!response.body) {
      return NextResponse.json({ error: "Respuesta sin body" }, { status: 400 });
    }

    // Stream the download to disk.
    const arrayBuffer = await response.arrayBuffer();
    await fs.writeFile(filePath, Buffer.from(arrayBuffer));

    const originalFilename = path.basename(urlPath) || `imported${ext}`;

    // Create the Asset record.
    const asset = await db.asset.create({
      data: {
        title,
        originalFilename,
        category: cat,
        durationMs: 0,
        hlsUrl: "",
        thumbnailUrl: null,
        description: description || null,
        resolutionVariants: "",
        transcodeStatus: "pending",
        transcodeProgress: 0,
        originalFilePath: uniqueName,
      },
    });

    // Start the transcode job.
    startTranscodeJob(asset.id, uniqueName);

    return NextResponse.json({
      id: asset.id,
      title: asset.title,
      transcodeStatus: "pending",
      message: "Archivo descargado. Transcodificación iniciada.",
    }, { status: 201 });
  } catch (e) {
    console.error("[import-url] Error:", e);
    return NextResponse.json(
      { error: e instanceof Error ? e.message : "internal error" },
      { status: 500 }
    );
  }
}
