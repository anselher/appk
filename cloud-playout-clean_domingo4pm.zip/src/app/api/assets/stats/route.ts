import { NextResponse } from "next/server";
import { db } from "@/lib/db";

// GET /api/assets/stats — returns a map of assetId → { scheduledCount, lastScheduledDate }
// across all dates in the schedule. Useful for MAM usage analytics.
export async function GET() {
  // Group schedule slots by assetId and count + last date.
  const rows = await db.scheduleSlot.groupBy({
    by: ["assetId"],
    _count: { _all: true },
    _max: { date: true },
  });

  const stats: Record<string, { scheduledCount: number; lastScheduledDate: string | null }> = {};
  for (const r of rows) {
    stats[r.assetId] = {
      scheduledCount: r._count._all,
      lastScheduledDate: r._max.date,
    };
  }

  return NextResponse.json(stats);
}
