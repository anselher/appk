import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

// GET /api/avances — list all Avance containers with their clips.
export async function GET() {
  const avances = await db.avance.findMany({
    orderBy: { createdAt: "asc" },
    include: {
      clips: {
        orderBy: { orderIndex: "asc" },
        include: { asset: true },
      },
    },
  });
  return NextResponse.json(avances);
}

// POST /api/avances — create a new Avance container.
// Body: { title, description?, hideFromEpg?, validFrom?, validUntil?, color?,
//         fadeEnabled?, fadeInMs?, fadeOutMs? }
// fade fields: fadeInMs/fadeOutMs are clamped to [0, 1000].
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { title, description, hideFromEpg, validFrom, validUntil, color,
            fadeEnabled, fadeInMs, fadeOutMs } = body;
    if (!title || typeof title !== "string" || !title.trim()) {
      return NextResponse.json({ error: "title es obligatorio" }, { status: 400 });
    }
    // Clamp fade durations to [0, 1000] ms.
    const clampFade = (v: unknown) => {
      const n = typeof v === "number" ? v : 500;
      return Math.max(0, Math.min(1000, Math.round(n)));
    };
    const avance = await db.avance.create({
      data: {
        title: title.trim(),
        description: description ?? null,
        hideFromEpg: hideFromEpg === true,
        validFrom: validFrom ? new Date(validFrom) : null,
        validUntil: validUntil ? new Date(validUntil) : null,
        color: color ?? "amber",
        totalDurationMs: 0,
        fadeEnabled: fadeEnabled === true,
        fadeInMs: clampFade(fadeInMs),
        fadeOutMs: clampFade(fadeOutMs),
      },
      include: { clips: { include: { asset: true } } },
    });
    return NextResponse.json(avance, { status: 201 });
  } catch (e) {
    return NextResponse.json(
      { error: e instanceof Error ? e.message : "internal error" },
      { status: 500 }
    );
  }
}
