import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

// Helper: recompute totalDurationMs = sum of (out - in) across all clips.
// Called after any clip mutation (add, delete, update cut).
async function recomputeTotalDuration(avanceId: string) {
  const clips = await db.avanceClip.findMany({
    where: { avanceId },
    include: { asset: { select: { durationMs: true } } },
  });
  let total = 0;
  for (const c of clips) {
    const assetDur = Math.max(c.asset.durationMs, 1);
    const inMs = Math.max(0, Math.min(c.inMs, assetDur - 1));
    const outMs = Math.max(inMs + 1, Math.min(c.outMs > 0 ? c.outMs : assetDur, assetDur));
    total += outMs - inMs;
  }
  await db.avance.update({ where: { id: avanceId }, data: { totalDurationMs: total } });
  return total;
}

// GET /api/avances/[id] — single Avance with full clip list.
export async function GET(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  const avance = await db.avance.findUnique({
    where: { id },
    include: {
      clips: {
        orderBy: { orderIndex: "asc" },
        include: { asset: true },
      },
    },
  });
  if (!avance) return NextResponse.json({ error: "not found" }, { status: 404 });
  return NextResponse.json(avance);
}

// PATCH /api/avances/[id] — update Avance metadata.
// Body: { title?, description?, hideFromEpg?, validFrom?, validUntil?, color?,
//         fadeEnabled?, fadeInMs?, fadeOutMs? }
// fade fields: fadeInMs/fadeOutMs are clamped to [0, 1000] ms.
//
// When ANY field changes, existing renders are marked as "stale" (the rendered
// MP4 no longer reflects the current Avance configuration). The user can then
// re-render manually from the UI, or the auto-render (Fase 4) will kick in if
// the Avance is scheduled.
export async function PATCH(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const body = await req.json();
    const { title, description, hideFromEpg, validFrom, validUntil, color,
            fadeEnabled, fadeInMs, fadeOutMs } = body;

    const existing = await db.avance.findUnique({ where: { id } });
    if (!existing) return NextResponse.json({ error: "not found" }, { status: 404 });

    // Clamp fade durations to [0, 1000] ms.
    const clampFade = (v: unknown) => {
      const n = typeof v === "number" ? v : 500;
      return Math.max(0, Math.min(1000, Math.round(n)));
    };

    const updated = await db.avance.update({
      where: { id },
      data: {
        ...(title !== undefined && typeof title === "string" ? { title: title.trim() } : {}),
        ...(description !== undefined ? { description: description ?? null } : {}),
        ...(hideFromEpg !== undefined ? { hideFromEpg: !!hideFromEpg } : {}),
        ...(validFrom !== undefined ? { validFrom: validFrom ? new Date(validFrom) : null } : {}),
        ...(validUntil !== undefined ? { validUntil: validUntil ? new Date(validUntil) : null } : {}),
        ...(color !== undefined ? { color } : {}),
        ...(fadeEnabled !== undefined ? { fadeEnabled: !!fadeEnabled } : {}),
        ...(fadeInMs !== undefined ? { fadeInMs: clampFade(fadeInMs) } : {}),
        ...(fadeOutMs !== undefined ? { fadeOutMs: clampFade(fadeOutMs) } : {}),
      },
      include: { clips: { orderBy: { orderIndex: "asc" }, include: { asset: true } } },
    });

    // Invalidate existing renders — mark as "stale" so the playout engine
    // falls back to individual clips until a new render is produced.
    try {
      await db.renderedAvance.updateMany({
        where: { avanceId: id, status: { in: ["completed", "pending", "rendering"] } },
        data: { status: "stale" },
      });
    } catch {
      // RenderedAvance table might not exist — ignore.
    }

    return NextResponse.json(updated);
  } catch (e) {
    return NextResponse.json(
      { error: e instanceof Error ? e.message : "internal error" },
      { status: 500 }
    );
  }
}

// DELETE /api/avances/[id] — cascade deletes all clips.
export async function DELETE(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    // Also null out any ScheduleSlot.avanceId references (don't delete the slot itself).
    await db.scheduleSlot.updateMany({
      where: { avanceId: id },
      data: { avanceId: null, slotType: "program" },
    });
    await db.avance.delete({ where: { id } });
    return NextResponse.json({ ok: true });
  } catch (e) {
    return NextResponse.json(
      { error: e instanceof Error ? e.message : "internal error" },
      { status: 500 }
    );
  }
}

// Exported helper for use by clips routes (avoids circular imports).
export { recomputeTotalDuration };
