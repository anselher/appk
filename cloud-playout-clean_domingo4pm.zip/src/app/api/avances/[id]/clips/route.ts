import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { recomputeTotalDuration } from "../route";

// Helper: mark all renders of an Avance as stale (clips changed → render is outdated).
async function invalidateRenders(avanceId: string) {
  try {
    await db.renderedAvance.updateMany({
      where: { avanceId, status: { in: ["completed", "pending", "rendering"] } },
      data: { status: "stale" },
    });
  } catch {
    // RenderedAvance table might not exist — ignore.
  }
}

// POST /api/avances/[id]/clips — append a clip to the Avance container.
// Body: { assetId, inMs?, outMs? }
// Validation: outMs > inMs, inMs >= 0, outMs auto-clamped to asset.durationMs.
export async function POST(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const body = await req.json();
    const { assetId, inMs, outMs } = body;
    if (!assetId || typeof assetId !== "string") {
      return NextResponse.json({ error: "assetId es obligatorio" }, { status: 400 });
    }

    const avance = await db.avance.findUnique({ where: { id } });
    if (!avance) return NextResponse.json({ error: "avance not found" }, { status: 404 });

    const asset = await db.asset.findUnique({ where: { id: assetId } });
    if (!asset) return NextResponse.json({ error: "asset not found" }, { status: 404 });

    const assetDur = Math.max(asset.durationMs, 1);
    // Resolve + auto-clamp cut values.
    const inMsClamped = Math.max(0, Math.min(Number(inMs) || 0, assetDur - 1));
    // outMs: if 0 or missing or > assetDur, use assetDur (full clip / clamp).
    const outMsRaw = Number(outMs) || 0;
    const outMsClamped = Math.max(inMsClamped + 1, Math.min(outMsRaw > 0 ? outMsRaw : assetDur, assetDur));

    // Compute next orderIndex.
    const existingCount = await db.avanceClip.count({ where: { avanceId: id } });

    const clip = await db.avanceClip.create({
      data: {
        avanceId: id,
        assetId,
        orderIndex: existingCount,
        inMs: inMsClamped,
        outMs: outMsClamped,
      },
      include: { asset: true },
    });

    await recomputeTotalDuration(id);
    // Invalidate renders — a clip was added, so the old render is outdated.
    await invalidateRenders(id);
    return NextResponse.json(clip, { status: 201 });
  } catch (e) {
    return NextResponse.json(
      { error: e instanceof Error ? e.message : "internal error" },
      { status: 500 }
    );
  }
}

// PATCH /api/avances/[id]/clips — reorder clips (provide array of clipIds in new order).
// Body: { order: string[] }
export async function PATCH(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const body = await req.json();
    const { order } = body;
    if (!Array.isArray(order)) {
      return NextResponse.json({ error: "order debe ser un array de clipIds" }, { status: 400 });
    }

    for (let i = 0; i < order.length; i++) {
      await db.avanceClip.update({
        where: { id: order[i] },
        data: { orderIndex: i },
      });
    }
    await recomputeTotalDuration(id);
    // Invalidate renders — clip order changed.
    await invalidateRenders(id);
    const updated = await db.avance.findUnique({
      where: { id },
      include: { clips: { orderBy: { orderIndex: "asc" }, include: { asset: true } } },
    });
    return NextResponse.json(updated);
  } catch (e) {
    return NextResponse.json(
      { error: e instanceof Error ? e.message : "internal error" },
      { status: 500 }
    );
  }
}
