import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { recomputeTotalDuration } from "../../route";

// Helper: mark all renders of an Avance as stale (clip cut changed → render is outdated).
async function invalidateRenders(avanceId: string) {
  try {
    await db.renderedAvance.updateMany({
      where: { avanceId, status: { in: ["completed", "pending", "rendering"] } },
      data: { status: "stale" },
    });
  } catch {
    // RenderedAvance table might not exist — ignore.
  }
}

// PATCH /api/avances/[id]/clips/[clipId] — update the In/Out cut of a single clip.
// Body: { inMs?, outMs? }
// Validation: auto-clamp outMs to asset.durationMs; ensure outMs > inMs; inMs >= 0.
export async function PATCH(
  req: NextRequest,
  { params }: { params: Promise<{ id: string; clipId: string }> }
) {
  try {
    const { id, clipId } = await params;
    const body = await req.json();
    const { inMs, outMs } = body;

    const clip = await db.avanceClip.findUnique({
      where: { id: clipId },
      include: { asset: { select: { durationMs: true, title: true } } },
    });
    if (!clip || clip.avanceId !== id) {
      return NextResponse.json({ error: "clip not found in this avance" }, { status: 404 });
    }

    const assetDur = Math.max(clip.asset.durationMs, 1);
    const wasClamped = { inMs: false, outMs: false };

    // Resolve new inMs (clamp to [0, assetDur-1]).
    let newInMs = clip.inMs;
    if (inMs !== undefined) {
      const requested = Number(inMs) || 0;
      newInMs = Math.max(0, Math.min(requested, assetDur - 1));
      if (requested !== newInMs) wasClamped.inMs = true;
    }

    // Resolve new outMs (clamp to [newInMs+1, assetDur]; 0 = full clip = assetDur).
    let newOutMs = clip.outMs;
    if (outMs !== undefined) {
      const requested = Number(outMs) || 0;
      const requestedOrFull = requested > 0 ? requested : assetDur;
      newOutMs = Math.max(newInMs + 1, Math.min(requestedOrFull, assetDur));
      if (requestedOrFull !== newOutMs) wasClamped.outMs = true;
    } else if (newInMs >= newOutMs) {
      // If inMs moved past outMs, push outMs to end.
      newOutMs = assetDur;
      wasClamped.outMs = true;
    }

    const updated = await db.avanceClip.update({
      where: { id: clipId },
      data: { inMs: newInMs, outMs: newOutMs },
      include: { asset: true },
    });

    await recomputeTotalDuration(id);
    // Invalidate renders — a clip cut changed.
    await invalidateRenders(id);

    // Return with clamping metadata so the UI can toast a warning.
    return NextResponse.json({
      ...updated,
      _clamped: wasClamped,
      _assetDurationMs: assetDur,
    });
  } catch (e) {
    return NextResponse.json(
      { error: e instanceof Error ? e.message : "internal error" },
      { status: 500 }
    );
  }
}

// DELETE /api/avances/[id]/clips/[clipId] — remove a clip and re-index siblings.
export async function DELETE(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string; clipId: string }> }
) {
  try {
    const { id, clipId } = await params;
    await db.avanceClip.delete({ where: { id: clipId } });

    // Re-index remaining clips to be contiguous (0, 1, 2, ...).
    const remaining = await db.avanceClip.findMany({
      where: { avanceId: id },
      orderBy: { orderIndex: "asc" },
    });
    for (let i = 0; i < remaining.length; i++) {
      if (remaining[i].orderIndex !== i) {
        await db.avanceClip.update({
          where: { id: remaining[i].id },
          data: { orderIndex: i },
        });
      }
    }

    await recomputeTotalDuration(id);
    // Invalidate renders — a clip was removed.
    await invalidateRenders(id);
    return NextResponse.json({ ok: true });
  } catch (e) {
    return NextResponse.json(
      { error: e instanceof Error ? e.message : "internal error" },
      { status: 500 }
    );
  }
}
