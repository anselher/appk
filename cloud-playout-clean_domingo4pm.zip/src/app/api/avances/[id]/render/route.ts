import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import {
  renderAvanceToMp4,
  computeExpiry,
  invalidateRendersForAvance,
} from "@/lib/render";

// POST /api/avances/[id]/render
// Triggers a render of the Avance to a single MP4 file.
//
// Body options:
//   { date?: "YYYY-MM-DD" }  — broadcast date for this render (default: today in Venezuela).
//   { force?: boolean }       — if true, re-renders even if a completed render exists.
//
// Returns the RenderedAvance record (status="pending" initially).
// The client should poll GET /api/avances/[id]/render/status?date=YYYY-MM-DD for progress.
export async function POST(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const body = await req.json().catch(() => ({}));
    const { date, force } = body as { date?: string; force?: boolean };

    // Verify the Avance exists and has clips.
    const avance = await db.avance.findUnique({
      where: { id },
      include: {
        clips: {
          orderBy: { orderIndex: "asc" },
          include: { asset: { select: { id: true, title: true, durationMs: true, originalFilename: true, originalFilePath: true } } },
        },
      },
    });

    if (!avance) {
      return NextResponse.json({ error: "Avance no encontrado" }, { status: 404 });
    }
    if (avance.clips.length === 0) {
      return NextResponse.json({ error: "El Avance no tiene clips. Agrégale clips primero." }, { status: 400 });
    }

    // Resolve the date (default: today in Venezuela, approximated as UTC-4).
    const renderDate = date || (() => {
      const now = new Date();
      const caracas = new Date(now.getTime() - 4 * 3600 * 1000);
      return caracas.toISOString().slice(0, 10);
    })();

    // Check if a completed render already exists for this date.
    if (!force) {
      const existing = await db.renderedAvance.findFirst({
        where: {
          avanceId: id,
          date: renderDate,
          status: "completed",
          expiresAt: { gt: new Date() },
        },
        orderBy: { createdAt: "desc" },
      });
      if (existing) {
        return NextResponse.json({
          ok: true,
          message: "Ya existe un render vigente para esta fecha",
          render: existing,
        });
      }
    }

    // If force=true, invalidate previous renders for this Avance+date.
    if (force) {
      await db.renderedAvance.updateMany({
        where: { avanceId: id, date: renderDate },
        data: { status: "stale" },
      });
    }

    // Create a new render record.
    const expiresAt = computeExpiry(renderDate);
    const render = await db.renderedAvance.create({
      data: {
        avanceId: id,
        date: renderDate,
        expiresAt,
        filePath: "",  // will be filled when render completes
        durationMs: avance.totalDurationMs,
        status: "pending",
        progress: 0,
      },
    });

    // Kick off the render in the background (don't await).
    // The render function updates the DB record as it progresses.
    renderAvanceToMp4(render.id).catch((err) => {
      console.error(`[render] Background render failed for avance ${id}:`, err);
    });

    return NextResponse.json({
      ok: true,
      message: "Render iniciado",
      render,
    }, { status: 202 });
  } catch (e) {
    console.error("[render] Error:", e);
    return NextResponse.json(
      { error: e instanceof Error ? e.message : "internal error" },
      { status: 500 }
    );
  }
}

// GET /api/avances/[id]/render?date=YYYY-MM-DD
// Returns the current render status for the Avance on the given date.
export async function GET(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const date = req.nextUrl.searchParams.get("date");
    if (!date) {
      return NextResponse.json({ error: "date es obligatorio" }, { status: 400 });
    }

    // Find the most recent render for this Avance+date.
    const render = await db.renderedAvance.findFirst({
      where: { avanceId: id, date },
      orderBy: { createdAt: "desc" },
    });

    if (!render) {
      return NextResponse.json({ exists: false });
    }

    return NextResponse.json({ exists: true, render });
  } catch (e) {
    return NextResponse.json(
      { error: e instanceof Error ? e.message : "internal error" },
      { status: 500 }
    );
  }
}
