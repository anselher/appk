import { NextRequest, NextResponse } from "next/server";
import { getMediaStoragePath, isInsideStorage } from "@/lib/media-storage";
import { promises as fs, createReadStream } from "fs";
import { stat } from "fs/promises";
import path from "path";
import { Readable } from "stream";

// GET /api/media/[...path]
// Serves files from the configurable media storage directory.
// Path is validated to prevent directory traversal attacks.
//
// Supports HTTP Range requests for video files (MP4), enabling:
//   - Streaming (browser can start playing before download completes).
//   - Seek (browser can jump to any position without re-downloading).
//   - PiP / fullscreen playback.
export async function GET(
  req: NextRequest,
  { params }: { params: Promise<{ path: string[] }> }
) {
  try {
    const { path: segments } = await params;
    const relativePath = segments.join("/");

    if (!relativePath) {
      return NextResponse.json({ error: "Path required" }, { status: 400 });
    }

    // Prevent directory traversal (no ".." in segments).
    if (segments.some((s) => s.includes(".."))) {
      return NextResponse.json({ error: "Invalid path" }, { status: 400 });
    }

    const storagePath = await getMediaStoragePath();
    const absPath = path.resolve(storagePath, relativePath);

    // Security: ensure the resolved path is inside the storage directory.
    const inside = await isInsideStorage(absPath);
    if (!inside) {
      return NextResponse.json({ error: "Access denied" }, { status: 403 });
    }

    // Check if file exists and get its stats.
    let fileStat;
    try {
      fileStat = await stat(absPath);
    } catch {
      return NextResponse.json({ error: "File not found" }, { status: 404 });
    }

    // Determine content type.
    const ext = path.extname(absPath).toLowerCase();
    const contentTypes: Record<string, string> = {
      ".m3u8": "application/vnd.apple.mpegurl",
      ".ts": "video/mp2t",
      ".mp4": "video/mp4",
      ".jpg": "image/jpeg",
      ".jpeg": "image/jpeg",
      ".png": "image/png",
      ".webp": "image/webp",
    };
    const contentType = contentTypes[ext] || "application/octet-stream";

    const fileSize = fileStat.size;

    // Parse Range header for video streaming.
    // Browsers send "Range: bytes=0-" or "Range: bytes=12345-67890" when seeking.
    const range = req.headers.get("range");

    // For small files (thumbnails, m3u8 playlists, .ts segments) or non-video
    // files, just read the whole file into memory.
    const isSmallFile = fileSize < 5 * 1024 * 1024; // < 5MB
    const isVideoFile = ext === ".mp4" || ext === ".ts";

    if (!range && (!isVideoFile || isSmallFile)) {
      // Read entire file into memory (fine for small files / images / playlists).
      const data = await fs.readFile(absPath);
      const headers = new Headers({
        "Content-Type": contentType,
        "Content-Length": String(fileSize),
        "Cache-Control": "public, max-age=3600",
        "Access-Control-Allow-Origin": "*",
      });
      if (ext === ".m3u8") {
        headers.set("Access-Control-Allow-Headers", "Range");
        headers.set("Access-Control-Allow-Methods", "GET, HEAD, OPTIONS");
      }
      return new NextResponse(data, { headers });
    }

    // Handle Range request (or large video file without Range).
    // Parse the range: "bytes=START-END" or "bytes=START-".
    let start = 0;
    let end = fileSize - 1;

    if (range) {
      const match = range.match(/bytes=(\d*)-(\d*)/);
      if (match) {
        if (match[1]) start = parseInt(match[1], 10);
        if (match[2]) end = parseInt(match[2], 10);
      }
      // Clamp to valid range.
      if (start >= fileSize) {
        return new NextResponse(null, {
          status: 416, // Range Not Satisfiable
          headers: { "Content-Range": `bytes */${fileSize}` },
        });
      }
      end = Math.min(end, fileSize - 1);
    }

    const chunkSize = end - start + 1;

    // Stream the file chunk.
    const stream = createReadStream(absPath, { start, end });
    const readable = Readable.toWeb(stream) as unknown as ReadableStream;

    const headers = new Headers({
      "Content-Type": contentType,
      "Content-Length": String(chunkSize),
      "Content-Range": `bytes ${start}-${end}/${fileSize}`,
      "Accept-Ranges": "bytes",
      "Cache-Control": "public, max-age=3600",
      "Access-Control-Allow-Origin": "*",
    });

    return new NextResponse(readable, {
      status: range ? 206 : 200, // 206 Partial Content if Range was requested
      headers,
    });
  } catch (e) {
    console.error("[media] Error:", e);
    return NextResponse.json(
      { error: e instanceof Error ? e.message : "internal error" },
      { status: 500 }
    );
  }
}
