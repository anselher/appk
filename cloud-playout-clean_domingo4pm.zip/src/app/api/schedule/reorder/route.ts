import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

// POST /api/schedule/reorder
// Body: { date: "YYYY-MM-DD", slotIds: ["id1", "id2", "id3", ...] }
// Reassigns orderIndex 0..N sequentially based on the slotIds array order.
//
// IMPORTANT: The ScheduleSlot table has a @@unique([date, orderIndex]) constraint.
// If we update orderIndex values directly, two slots may temporarily collide
// (e.g. slot A goes from 0 to 1 while slot B is still at 1 → unique violation).
//
// To avoid this, we do a TWO-PHASE update inside a transaction:
//   Phase 1: Move all slots to negative temporary indices (-1, -2, -3, ...).
//            Negative indices never collide with existing positive ones.
//   Phase 2: Assign the final indices (0, 1, 2, ...).
//
// This guarantees no two slots ever share the same orderIndex during the update.
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { date, slotIds } = body as { date: string; slotIds: string[] };

    if (!date || !Array.isArray(slotIds) || slotIds.length === 0) {
      return NextResponse.json(
        { error: "date y slotIds son obligatorios" },
        { status: 400 }
      );
    }

    await db.$transaction(async (tx) => {
      // Phase 1: Move all slots to negative temporary indices.
      // Use large negative numbers to avoid any collision with existing data.
      // Start at -1000000 to be safe even with very long schedules.
      const tempBase = -1000000;
      for (let i = 0; i < slotIds.length; i++) {
        await tx.scheduleSlot.update({
          where: { id: slotIds[i] },
          data: { orderIndex: tempBase - i },
        });
      }

      // Phase 2: Assign the final indices 0, 1, 2, ...
      for (let i = 0; i < slotIds.length; i++) {
        await tx.scheduleSlot.update({
          where: { id: slotIds[i] },
          data: { orderIndex: i },
        });
      }
    });

    return NextResponse.json({
      ok: true,
      updated: slotIds.length,
      date,
    });
  } catch (e) {
    console.error("[reorder] Error:", e);
    return NextResponse.json(
      { error: e instanceof Error ? e.message : "internal error" },
      { status: 500 }
    );
  }
}
