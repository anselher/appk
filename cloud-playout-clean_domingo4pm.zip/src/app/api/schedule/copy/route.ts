import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

// POST /api/schedule/copy — copy all slots from one date to another.
// Body: { sourceDate: "YYYY-MM-DD", targetDate: "YYYY-MM-DD", includeCuePoints?: boolean, replaceTarget?: boolean }
// Returns: { copied: number, cuePoints: number }
//
// - Slots are re-numbered (orderIndex 0..N) on the target date, preserving order.
// - If replaceTarget=true, existing slots on target date are deleted first.
// - Cue points + their ad break references are duplicated when includeCuePoints=true.
// - Uses a longer transaction timeout (60s) to handle large schedules (120+ slots).
// - Uses negative temporary orderIndex to avoid @@unique([date, orderIndex]) collisions.
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const {
      sourceDate,
      targetDate,
      includeCuePoints = true,
      replaceTarget = false,
    } = body;

    if (!sourceDate || !targetDate) {
      return NextResponse.json(
        { error: "sourceDate y targetDate son obligatorios (YYYY-MM-DD)" },
        { status: 400 }
      );
    }
    if (sourceDate === targetDate) {
      return NextResponse.json(
        { error: "Las fechas de origen y destino no pueden ser iguales" },
        { status: 400 }
      );
    }

    // Fetch source slots with cue points.
    const sourceSlots = await db.scheduleSlot.findMany({
      where: { date: sourceDate },
      orderBy: { orderIndex: "asc" },
      include: { cuePoints: true },
    });

    if (sourceSlots.length === 0) {
      return NextResponse.json(
        { error: `No hay programación en ${sourceDate} para copiar` },
        { status: 404 }
      );
    }

    // If replaceTarget, delete existing slots on target date first.
    if (replaceTarget) {
      // Delete cue points first (they reference schedule slots).
      const existingSlots = await db.scheduleSlot.findMany({
        where: { date: targetDate },
        select: { id: true },
      });
      if (existingSlots.length > 0) {
        await db.cuePoint.deleteMany({
          where: { scheduleSlotId: { in: existingSlots.map((s) => s.id) } },
        });
        await db.scheduleSlot.deleteMany({ where: { date: targetDate } });
      }
    }

    // Count existing slots on target date to continue orderIndex (append mode).
    const existingCount = await db.scheduleSlot.count({ where: { date: targetDate } });

    let copied = 0;
    let cuePointsCopied = 0;

    // Use a transaction with a longer timeout (60 seconds) to handle large schedules.
    // Two-phase approach: create with negative temp orderIndex, then update to final.
    await db.$transaction(
      async (tx) => {
        // Phase 1: Create all slots with negative temporary orderIndex.
        // This avoids @@unique([date, orderIndex]) collisions.
        const tempBase = -1000000 - existingCount;
        const createdSlots: { id: string; srcIndex: number }[] = [];

        for (let i = 0; i < sourceSlots.length; i++) {
          const src = sourceSlots[i];
          const newSlot = await tx.scheduleSlot.create({
            data: {
              date: targetDate,
              orderIndex: tempBase - i,
              assetId: src.assetId,
              fillerLoop: src.fillerLoop,
            },
          });
          createdSlots.push({ id: newSlot.id, srcIndex: i });
          copied++;
        }

        // Phase 2: Update orderIndex to final values (existingCount + 0, 1, 2, ...).
        for (let i = 0; i < createdSlots.length; i++) {
          await tx.scheduleSlot.update({
            where: { id: createdSlots[i].id },
            data: { orderIndex: existingCount + i },
          });
        }

        // Phase 3: Create cue points (after orderIndex is settled).
        if (includeCuePoints) {
          for (const cs of createdSlots) {
            const src = sourceSlots[cs.srcIndex];
            for (const cp of src.cuePoints) {
              await tx.cuePoint.create({
                data: {
                  scheduleSlotId: cs.id,
                  offsetMs: cp.offsetMs,
                  adBreakId: cp.adBreakId,
                },
              });
              cuePointsCopied++;
            }
          }
        }
      },
      {
        timeout: 60000, // 60 seconds (default is 5s, too short for 120+ slots)
        maxWait: 10000, // max time to wait for transaction to start
      }
    );

    return NextResponse.json({
      copied,
      cuePoints: cuePointsCopied,
      sourceDate,
      targetDate,
    });
  } catch (e) {
    console.error("[copy] Error:", e);
    return NextResponse.json(
      { error: e instanceof Error ? e.message : "internal error" },
      { status: 500 }
    );
  }
}
