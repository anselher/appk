import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

// PATCH /api/schedule/[id] — update orderIndex / fillerLoop / assetId.
export async function PATCH(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const body = await req.json();
    const data: Record<string, unknown> = {};
    for (const k of ["orderIndex", "fillerLoop", "assetId", "date"]) {
      if (k in body) data[k] = body[k];
    }
    const slot = await db.scheduleSlot.update({ where: { id }, data });
    return NextResponse.json(slot);
  } catch (e) {
    return NextResponse.json(
      { error: e instanceof Error ? e.message : "internal error" },
      { status: 500 }
    );
  }
}

export async function DELETE(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    await db.scheduleSlot.delete({ where: { id } });
    return NextResponse.json({ ok: true });
  } catch (e) {
    return NextResponse.json(
      { error: e instanceof Error ? e.message : "internal error" },
      { status: 500 }
    );
  }
}

// PUT /api/schedule/[id] — reorder: body { orderIndex } swaps.
export async function PUT(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const { orderIndex } = await req.json();
    const slot = await db.scheduleSlot.update({
      where: { id },
      data: { orderIndex: Number(orderIndex) },
    });
    return NextResponse.json(slot);
  } catch (e) {
    return NextResponse.json(
      { error: e instanceof Error ? e.message : "internal error" },
      { status: 500 }
    );
  }
}
