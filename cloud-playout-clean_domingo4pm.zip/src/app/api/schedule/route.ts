import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

// GET /api/schedule?date=YYYY-MM-DD — ordered schedule slots with cue points + ad breaks + Avance.
export async function GET(req: NextRequest) {
  const date = req.nextUrl.searchParams.get("date");
  const slots = await db.scheduleSlot.findMany({
    where: date ? { date } : undefined,
    orderBy: [{ date: "asc" }, { orderIndex: "asc" }],
    include: {
      asset: true,
      // Include the Avance container when slotType === "avance".
      avance: {
        include: {
          clips: {
            orderBy: { orderIndex: "asc" },
            include: { asset: true },
          },
        },
      },
      cuePoints: {
        orderBy: { offsetMs: "asc" },
        include: {
          adBreak: {
            include: {
              entries: {
                orderBy: { orderIndex: "asc" },
                include: { asset: true },
              },
            },
          },
        },
      },
    },
  });
  return NextResponse.json(slots);
}

// POST /api/schedule — insert a slot (snap-to-tail computed on read).
// Body for program/bumper/filler: { date, assetId, orderIndex?, fillerLoop? }
// Body for avance: { date, assetId, slotType: "avance", avanceId }
//   - assetId is required (use first clip's asset) for backward compat with cue-point UI.
//   - avanceId points to the Avance container.
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { date, assetId, orderIndex, fillerLoop, slotType, avanceId } = body;
    if (!date) {
      return NextResponse.json({ error: "date es obligatorio" }, { status: 400 });
    }

    // Helper: compute a safe orderIndex that won't collide with the @@unique([date, orderIndex]).
    // We use max(orderIndex)+1 instead of count() because count() can produce a value
    // that already exists if slots have been removed (gaps in the sequence).
    // If the chosen index still collides (race condition), retry with +1, +2, ... up to 5 times.
    const resolveSafeOrderIndex = async (date: string, requested?: number | null): Promise<number> => {
      if (requested !== undefined && requested !== null) {
        // Verify the requested index is free; if not, fall through to max+1.
        const clash = await db.scheduleSlot.findFirst({
          where: { date, orderIndex: Number(requested) },
          select: { id: true },
        });
        if (!clash) return Number(requested);
      }
      const maxRow = await db.scheduleSlot.findFirst({
        where: { date },
        orderBy: { orderIndex: "desc" },
        select: { orderIndex: true },
      });
      const maxOi = maxRow?.orderIndex ?? -1;
      // Try max+1, max+2, ... up to 5 attempts in case of concurrent inserts.
      for (let attempt = 0; attempt < 5; attempt++) {
        const candidate = maxOi + 1 + attempt;
        const clash = await db.scheduleSlot.findFirst({
          where: { date, orderIndex: candidate },
          select: { id: true },
        });
        if (!clash) return candidate;
      }
      // Give up — return max+10 as a last resort.
      return maxOi + 10;
    };

    // For Avance slots, accept avanceId and resolve assetId from the first clip.
    if (slotType === "avance") {
      if (!avanceId) {
        return NextResponse.json({ error: "avanceId es obligatorio para slotType=avance" }, { status: 400 });
      }
      const avance = await db.avance.findUnique({
        where: { id: avanceId },
        include: {
          clips: {
            orderBy: { orderIndex: "asc" },
            include: { asset: { select: { id: true } } },
          },
        },
      });
      if (!avance) {
        return NextResponse.json({ error: "Avance no encontrado" }, { status: 404 });
      }
      if (avance.clips.length === 0) {
        return NextResponse.json({ error: "El Avance no tiene clips. Agrégale clips primero." }, { status: 400 });
      }
      const resolvedAssetId = assetId || avance.clips[0].asset.id;
      const oi = await resolveSafeOrderIndex(date, orderIndex);

      // Wrap the create in a try/catch to translate Prisma's unique-constraint error
      // into a friendly Spanish message (instead of dumping raw Prisma internals).
      let slot;
      try {
        slot = await db.scheduleSlot.create({
          data: {
            date,
            assetId: resolvedAssetId,
            orderIndex: oi,
            fillerLoop: false,
            slotType: "avance",
            avanceId,
          },
        });
      } catch (createErr) {
        const msg = createErr instanceof Error ? createErr.message : "";
        if (msg.includes("Unique constraint")) {
          return NextResponse.json(
            {
              error:
                "No se pudo añadir el Avance: hubo una colisión de orden con otro slot. Recarga la parrilla e inténtalo de nuevo.",
            },
            { status: 409 }
          );
        }
        throw createErr;
      }

      // ---- Auto-render: kick off a render for this Avance+date if one doesn't exist ----
      // This ensures the Avance is pre-rendered to a single MP4 before it airs,
      // eliminating gaps/rebuffering during live playback.
      // The render runs asynchronously — the slot creation returns immediately.
      try {
        const { computeExpiry, renderAvanceToMp4 } = await import("@/lib/render");
        // Check if a completed render already exists for this date.
        const existingRender = await db.renderedAvance.findFirst({
          where: { avanceId, date, status: "completed", expiresAt: { gt: new Date() } },
        });
        if (!existingRender) {
          // Create a render record and kick off the render in the background.
          const expiresAt = computeExpiry(date);
          const render = await db.renderedAvance.create({
            data: {
              avanceId,
              date,
              expiresAt,
              filePath: "",
              durationMs: avance.totalDurationMs,
              status: "pending",
              progress: 0,
            },
          });
          // Fire and forget — don't block the response.
          renderAvanceToMp4(render.id).catch((err) => {
            console.error(`[auto-render] Failed for avance ${avanceId}:`, err);
          });
        }
      } catch (renderErr) {
        // Auto-render is best-effort — don't fail the slot creation if it fails.
        console.warn("[auto-render] Failed to kick off render:", renderErr);
      }

      return NextResponse.json(slot, { status: 201 });
    }

    // Default: program / bumper / filler slot.
    if (!assetId) {
      return NextResponse.json({ error: "date y assetId son obligatorios" }, { status: 400 });
    }
    const oi = await resolveSafeOrderIndex(date, orderIndex);

    let slot;
    try {
      slot = await db.scheduleSlot.create({
        data: { date, assetId, orderIndex: oi, fillerLoop: !!fillerLoop },
      });
    } catch (createErr) {
      const msg = createErr instanceof Error ? createErr.message : "";
      if (msg.includes("Unique constraint")) {
        return NextResponse.json(
          {
            error:
              "No se pudo añadir el slot: hubo una colisión de orden con otro slot. Recarga la parrilla e inténtalo de nuevo.",
          },
          { status: 409 }
        );
      }
      throw createErr;
    }
    return NextResponse.json(slot, { status: 201 });
  } catch (e) {
    return NextResponse.json(
      { error: e instanceof Error ? e.message : "internal error" },
      { status: 500 }
    );
  }
}
