import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

// GET /api/renders
// Lists all render records, optionally filtered by status or avanceId.
// Query params:
//   ?status=completed  — filter by status
//   ?avanceId=xxx      — filter by Avance
//   ?active=true       — only non-expired, non-stale renders
export async function GET(req: NextRequest) {
  const status = req.nextUrl.searchParams.get("status");
  const avanceId = req.nextUrl.searchParams.get("avanceId");
  const active = req.nextUrl.searchParams.get("active");

  const where: Record<string, unknown> = {};
  if (status) where.status = status;
  if (avanceId) where.avanceId = avanceId;
  if (active === "true") {
    where.expiresAt = { gt: new Date() };
    where.status = { notIn: ["stale"] };
  }

  const renders = await db.renderedAvance.findMany({
    where,
    orderBy: { createdAt: "desc" },
    include: {
      avance: {
        select: { id: true, title: true, totalDurationMs: true, fadeEnabled: true, fadeInMs: true, fadeOutMs: true },
      },
    },
    take: 100,  // limit to last 100 renders
  });

  return NextResponse.json(renders);
}

// DELETE /api/renders
// Cleanup endpoint — deletes all expired renders.
// Can be called manually or by a cron.
export async function DELETE() {
  try {
    // Import the cleanup function lazily to avoid circular deps.
    const { cleanupExpiredRenders } = await import("@/lib/render");
    const result = await cleanupExpiredRenders();
    return NextResponse.json({
      ok: true,
      deleted: result.deleted,
      errors: result.errors,
    });
  } catch (e) {
    return NextResponse.json(
      { error: e instanceof Error ? e.message : "internal error" },
      { status: 500 }
    );
  }
}
