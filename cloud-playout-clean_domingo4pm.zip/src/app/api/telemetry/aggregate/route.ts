import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { venezuelaDateKeyAsync } from "@/lib/playout";
import type { AdAnalytics } from "@/lib/types";

// Mock CPM (cost per mille) in USD for estimated revenue calculation.
// In a real system this would come from a per-spot rate card.
const MOCK_CPM_USD = 8.5;

// GET /api/telemetry/aggregate?date=YYYY-MM-DD
// Aggregates telemetry events into ad-investor KPIs:
//   - totalImpressions, totalCompletes, completionRate, totalSkips
//   - fillRate (scheduled ad slots that aired / total scheduled)
//   - estimatedRevenue (impressions * CPM / 1000)
//   - bySpot (per-spot impressions, completes, completion rate, revenue)
//   - byAdBreak (per-break impressions, completes, fill rate)
//   - byHour (24-bucket hourly impressions)
export async function GET(req: NextRequest) {
  try {
    const dateParam = req.nextUrl.searchParams.get("date");
    const date = dateParam ?? (await venezuelaDateKeyAsync(new Date()));

    // Fetch all ad-related events for the date.
    const events = await db.telemetryEvent.findMany({
      where: { date, eventType: { in: ["ad_impression", "ad_complete", "ad_skip"] } },
      include: { asset: true },
    });

    // Top-level counts.
    const impressions = events.filter((e) => e.eventType === "ad_impression").length;
    const completes = events.filter((e) => e.eventType === "ad_complete").length;
    const skips = events.filter((e) => e.eventType === "ad_skip").length;
    const completionRate = impressions > 0 ? (completes / impressions) * 100 : 0;

    // Fill rate: scheduled ad slots (from today's schedule) that actually aired.
    // We derive "aired" from ad_impression events grouped by adBreakId.
    const slots = await db.scheduleSlot.findMany({
      where: { date },
      include: {
        cuePoints: { select: { adBreakId: true } },
        preRollAdBreak: { select: { id: true } },
        postRollAdBreak: { select: { id: true } },
      },
    });
    const scheduledBreakIds = new Set<string>();
    for (const s of slots) {
      for (const cp of s.cuePoints) scheduledBreakIds.add(cp.adBreakId);
      if (s.preRollAdBreak) scheduledBreakIds.add(s.preRollAdBreak.id);
      if (s.postRollAdBreak) scheduledBreakIds.add(s.postRollAdBreak.id);
    }
    const airedBreakIds = new Set(
      events.filter((e) => e.eventType === "ad_impression" && e.adBreakId).map((e) => e.adBreakId as string)
    );
    const fillRate =
      scheduledBreakIds.size > 0
        ? (airedBreakIds.size / scheduledBreakIds.size) * 100
        : 0;

    const estimatedRevenue = (impressions * MOCK_CPM_USD) / 1000;

    // Per-spot breakdown.
    const spotMap = new Map<
      string,
      { assetId: string; title: string; impressions: number; completes: number }
    >();
    for (const e of events) {
      if (e.eventType === "ad_skip") continue;
      const key = e.assetId;
      const entry = spotMap.get(key) ?? {
        assetId: e.assetId,
        title: e.asset?.title ?? "Unknown",
        impressions: 0,
        completes: 0,
      };
      if (e.eventType === "ad_impression") entry.impressions++;
      if (e.eventType === "ad_complete") entry.completes++;
      spotMap.set(key, entry);
    }
    const bySpot = Array.from(spotMap.values())
      .map((s) => ({
        ...s,
        completionRate: s.impressions > 0 ? (s.completes / s.impressions) * 100 : 0,
        estimatedRevenue: (s.impressions * MOCK_CPM_USD) / 1000,
      }))
      .sort((a, b) => b.impressions - a.impressions);

    // Per-ad-break breakdown.
    const breakMap = new Map<
      string,
      { adBreakId: string; name: string; impressions: number; completes: number }
    >();
    for (const e of events) {
      if (!e.adBreakId) continue;
      const key = e.adBreakId;
      const entry = breakMap.get(key) ?? {
        adBreakId: key,
        name: "Bloque " + key.slice(-4),
        impressions: 0,
        completes: 0,
      };
      if (e.eventType === "ad_impression") entry.impressions++;
      if (e.eventType === "ad_complete") entry.completes++;
      breakMap.set(key, entry);
    }
    // Hydrate break names from DB.
    const breakIds = Array.from(breakMap.keys());
    const breaks = breakIds.length
      ? await db.adBreak.findMany({ where: { id: { in: breakIds } }, select: { id: true, name: true } })
      : [];
    const breakNameMap = new Map(breaks.map((b) => [b.id, b.name]));
    const byAdBreak = Array.from(breakMap.values())
      .map((b) => ({
        ...b,
        name: breakNameMap.get(b.adBreakId) ?? b.name,
        fillRate: b.impressions > 0 ? 100 : 0,
      }))
      .sort((a, b) => b.impressions - a.impressions);

    // Hourly impressions (24 buckets).
    const byHour = new Array(24).fill(0);
    for (const e of events) {
      if (e.eventType !== "ad_impression") continue;
      const hour = new Date(e.timestamp).getUTCHours();
      byHour[hour]++;
    }

    const analytics: AdAnalytics = {
      date,
      totalImpressions: impressions,
      totalCompletes: completes,
      completionRate,
      totalSkips: skips,
      fillRate,
      estimatedRevenue,
      bySpot,
      byAdBreak,
      byHour,
    };

    return NextResponse.json(analytics);
  } catch (e) {
    return NextResponse.json(
      { error: e instanceof Error ? e.message : "internal error" },
      { status: 500 }
    );
  }
}
