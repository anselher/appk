import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { venezuelaDateKeyAsync } from "@/lib/playout";
import type { TelemetryEvent, TelemetryEventType } from "@/lib/types";

// POST /api/telemetry — ingest a single telemetry event (anonymous audience measurement).
// Body: { eventType, sessionId, assetId, adBreakId?, slotId?, positionMs, durationMs }
// This is the ingest endpoint a player-side telemetry client would POST to.
// It stores the event for later aggregation by /api/telemetry/aggregate.
export async function POST(req: NextRequest) {
  try {
    const body = (await req.json()) as Partial<TelemetryEvent> & {
      eventType?: string;
      sessionId?: string;
      assetId?: string;
    };

    // Validate required fields.
    const eventType = body.eventType as TelemetryEventType | undefined;
    const sessionId = body.sessionId;
    const assetId = body.assetId;
    if (!eventType || !sessionId || !assetId) {
      return NextResponse.json(
        { error: "Missing required fields: eventType, sessionId, assetId" },
        { status: 400 }
      );
    }

    // Use the broadcast date (Venezuela) for the event — falls back to today.
    const date = body.date ?? (await venezuelaDateKeyAsync(new Date()));

    const created = await db.telemetryEvent.create({
      data: {
        eventType,
        sessionId,
        assetId,
        adBreakId: body.adBreakId ?? null,
        slotId: body.slotId ?? null,
        date,
        positionMs: body.positionMs ?? 0,
        durationMs: body.durationMs ?? 0,
      },
    });

    return NextResponse.json({ ok: true, id: created.id });
  } catch (e) {
    return NextResponse.json(
      { error: e instanceof Error ? e.message : "internal error" },
      { status: 500 }
    );
  }
}

// GET /api/telemetry — recent event count (lightweight health check).
export async function GET() {
  const count = await db.telemetryEvent.count();
  return NextResponse.json({ totalEvents: count });
}
