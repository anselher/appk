import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { venezuelaDateKeyAsync } from "@/lib/playout";

// POST /api/telemetry/seed-demo?date=YYYY-MM-DD
// Generates realistic mock telemetry events for the given date (default: today)
// so the dashboard analytics has data to display. This simulates viewers
// watching ads with realistic completion/skip rates.
//
// This is a DEMO helper — in production, real events come from the player via
// POST /api/telemetry.
export async function POST(req: NextRequest) {
  try {
    const dateParam = req.nextUrl.searchParams.get("date");
    const date = dateParam ?? (await venezuelaDateKeyAsync(new Date()));

    // Clear existing demo events for this date first (idempotent).
    await db.telemetryEvent.deleteMany({ where: { date } });

    // Fetch today's schedule to know which ads aired and when.
    const slots = await db.scheduleSlot.findMany({
      where: { date },
      include: {
        cuePoints: {
          include: {
            adBreak: {
              include: { entries: { include: { asset: true } } },
            },
          },
        },
        preRollAdBreak: { include: { entries: { include: { asset: true } } } },
        postRollAdBreak: { include: { entries: { include: { asset: true } } } },
      },
    });

    // Collect all ad instances from the schedule.
    type AdInstance = {
      assetId: string;
      adBreakId: string;
      slotId: string;
      durationMs: number;
      hour: number;
    };
    const instances: AdInstance[] = [];
    for (const slot of slots) {
      const collect = (
        brk: { id: string; entries: Array<{ asset: { id: string; durationMs: number } | null }> } | null,
        hour: number
      ) => {
        if (!brk) return;
        for (const entry of brk.entries) {
          // Skip entries with no asset (shouldn't happen, but be safe).
          if (!entry.asset) continue;
          instances.push({
            assetId: entry.asset.id,
            adBreakId: brk.id,
            slotId: slot.id,
            durationMs: Math.max(entry.asset.durationMs, 5000),
            hour,
          });
        }
      };
      // Rough proxy: 5 slots/hour → orderIndex/5 = hour.
      const approxHour = Math.min(23, Math.floor(slot.orderIndex / 5));
      for (const cp of slot.cuePoints) {
        collect(cp.adBreak, approxHour);
      }
      // Pre/post-roll breaks (currently null for all seeded slots, but handle gracefully).
      if (slot.preRollAdBreak) collect(slot.preRollAdBreak as unknown as { id: string; entries: Array<{ asset: { id: string; durationMs: number } | null }> }, approxHour);
      if (slot.postRollAdBreak) collect(slot.postRollAdBreak as unknown as { id: string; entries: Array<{ asset: { id: string; durationMs: number } | null }> }, approxHour);
    }

    if (instances.length === 0) {
      return NextResponse.json({ ok: false, message: "No scheduled ads found for this date." });
    }

    const now = new Date();
    const events: Array<{
      eventType: string;
      sessionId: string;
      assetId: string;
      adBreakId: string;
      slotId: string;
      date: string;
      positionMs: number;
      durationMs: number;
      timestamp: Date;
    }> = [];

    for (const inst of instances) {
      // Prime-time multiplier: peaks at 20h.
      const viewersMultiplier = 0.5 + 1.5 * Math.sin(((inst.hour - 4) / 24) * Math.PI * 2 - Math.PI / 2);
      const baseViewers = Math.max(3, Math.round(40 * Math.max(0.1, viewersMultiplier)));
      for (let v = 0; v < baseViewers; v++) {
        const sessionId = `demo-${inst.assetId.slice(-6)}-${v}`;
        const ts = new Date(now);
        ts.setUTCHours(inst.hour, Math.floor(Math.random() * 60), Math.floor(Math.random() * 60));
        events.push({
          eventType: "ad_impression",
          sessionId,
          assetId: inst.assetId,
          adBreakId: inst.adBreakId,
          slotId: inst.slotId,
          date,
          positionMs: 0,
          durationMs: inst.durationMs,
          timestamp: ts,
        });
        // 85% complete, 15% skip.
        if (Math.random() < 0.85) {
          events.push({
            eventType: "ad_complete",
            sessionId,
            assetId: inst.assetId,
            adBreakId: inst.adBreakId,
            slotId: inst.slotId,
            date,
            positionMs: inst.durationMs,
            durationMs: inst.durationMs,
            timestamp: new Date(ts.getTime() + inst.durationMs),
          });
        } else {
          events.push({
            eventType: "ad_skip",
            sessionId,
            assetId: inst.assetId,
            adBreakId: inst.adBreakId,
            slotId: inst.slotId,
            date,
            positionMs: Math.floor(inst.durationMs * Math.random() * 0.5),
            durationMs: inst.durationMs,
            timestamp: new Date(ts.getTime() + Math.floor(inst.durationMs * Math.random() * 0.5)),
          });
        }
      }
    }

    // Bulk insert in chunks (SQLite param limit).
    const CHUNK = 100;
    let inserted = 0;
    let lastErr: unknown = null;
    for (let i = 0; i < events.length; i += CHUNK) {
      const chunk = events.slice(i, i + CHUNK);
      try {
        await db.telemetryEvent.createMany({ data: chunk, skipDuplicates: true });
        inserted += chunk.length;
      } catch (err) {
        lastErr = err;
        // If createMany fails (e.g. FK constraint), fall back to individual inserts.
        for (const ev of chunk) {
          try {
            await db.telemetryEvent.create({ data: ev });
            inserted++;
          } catch {
            /* skip individual failures */
          }
        }
      }
    }

    return NextResponse.json({ ok: true, inserted, date, lastErr: lastErr instanceof Error ? lastErr.message : null });
  } catch (e) {
    return NextResponse.json(
      { error: e instanceof Error ? e.message : "internal error" },
      { status: 500 }
    );
  }
}
