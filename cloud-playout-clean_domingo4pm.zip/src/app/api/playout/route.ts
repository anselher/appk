import { NextRequest, NextResponse } from "next/server";
import { computePlayoutState, type RenderInfo } from "@/lib/playout";
import { findUsableRender } from "@/lib/render";
import { db } from "@/lib/db";

// GET /api/playout — current live-sync playout state (Venezuela time).
// GET /api/playout?date=YYYY-MM-DD — playout state for a specific date (preview).
//
// This route is server-side only, so it can safely import render.ts (which
// uses child_process for ffmpeg). It pre-fetches completed renders for all
// Avance slots and passes them to computePlayoutState.
export async function GET(req: NextRequest) {
  try {
    const dateParam = req.nextUrl.searchParams.get("date");

    // Determine the broadcast date and "now" for the playout computation.
    let broadcastDate: string;
    let now: Date;
    if (dateParam) {
      const [y, m, d] = dateParam.split("-").map(Number);
      const utcMidnight = Date.UTC(y, m - 1, d, 4, 0, 0); // 00:00 Caracas = 04:00 UTC
      now = new Date(utcMidnight + 1000);
      broadcastDate = dateParam;
    } else {
      now = new Date();
      // Compute broadcast date in Venezuela timezone (UTC-4).
      const caracas = new Date(now.getTime() - 4 * 3600 * 1000);
      broadcastDate = caracas.toISOString().slice(0, 10);
    }

    // Pre-fetch completed renders for all Avance slots on this date.
    // This allows the playout engine to use single-segment MP4 renders
    // instead of N individual HLS clips — eliminates gaps/rebuffering.
    const rendersByAvanceId = new Map<string, RenderInfo>();
    try {
      const avanceSlots = await db.scheduleSlot.findMany({
        where: { date: broadcastDate, slotType: "avance", avanceId: { not: null } },
        select: { avanceId: true },
        distinct: ["avanceId"],
      });
      for (const slot of avanceSlots) {
        if (!slot.avanceId) continue;
        const render = await findUsableRender(slot.avanceId, broadcastDate);
        if (render) {
          rendersByAvanceId.set(slot.avanceId, {
            filePath: render.filePath,
            durationMs: render.durationMs,
          });
        }
      }
    } catch (renderErr) {
      // If render lookup fails (e.g. table doesn't exist yet), continue without renders.
      console.warn("[/api/playout] Render lookup failed, falling back to clips:", renderErr);
    }

    const state = await computePlayoutState(now, rendersByAvanceId);
    return NextResponse.json(state);
  } catch (e) {
    console.error("[/api/playout] error", e);
    return NextResponse.json(
      { error: e instanceof Error ? e.message : "internal error" },
      { status: 500 }
    );
  }
}
