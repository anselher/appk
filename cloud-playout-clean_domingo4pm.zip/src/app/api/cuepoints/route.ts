import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

// POST /api/cuepoints — create a cue point (ad insertion) on a schedule slot.
// body: { scheduleSlotId, offsetMs, adBreakId }
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { scheduleSlotId, offsetMs, adBreakId } = body;
    if (!scheduleSlotId || offsetMs === undefined || !adBreakId) {
      return NextResponse.json(
        { error: "scheduleSlotId, offsetMs, adBreakId son obligatorios" },
        { status: 400 }
      );
    }
    const cue = await db.cuePoint.create({
      data: {
        scheduleSlotId,
        offsetMs: Number(offsetMs),
        adBreakId,
      },
      include: {
        adBreak: { include: { entries: { include: { asset: true } } } },
      },
    });
    return NextResponse.json(cue, { status: 201 });
  } catch (e) {
    return NextResponse.json(
      { error: e instanceof Error ? e.message : "internal error" },
      { status: 500 }
    );
  }
}
