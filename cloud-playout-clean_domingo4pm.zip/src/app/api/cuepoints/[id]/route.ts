import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

// PATCH /api/cuepoints/[id] — update offsetMs or adBreakId.
export async function PATCH(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const body = await req.json();
    const data: Record<string, unknown> = {};
    if ("offsetMs" in body) data.offsetMs = Number(body.offsetMs);
    if ("adBreakId" in body) data.adBreakId = body.adBreakId;
    const cue = await db.cuePoint.update({ where: { id }, data });
    return NextResponse.json(cue);
  } catch (e) {
    return NextResponse.json(
      { error: e instanceof Error ? e.message : "internal error" },
      { status: 500 }
    );
  }
}

export async function DELETE(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    await db.cuePoint.delete({ where: { id } });
    return NextResponse.json({ ok: true });
  } catch (e) {
    return NextResponse.json(
      { error: e instanceof Error ? e.message : "internal error" },
      { status: 500 }
    );
  }
}
