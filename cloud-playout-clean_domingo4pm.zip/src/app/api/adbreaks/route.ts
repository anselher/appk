import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

// GET /api/adbreaks — all ad breaks with entries.
export async function GET() {
  const breaks = await db.adBreak.findMany({
    orderBy: { createdAt: "asc" },
    include: {
      entries: {
        orderBy: { orderIndex: "asc" },
        include: { asset: true },
      },
    },
  });
  return NextResponse.json(breaks);
}

// POST /api/adbreaks — create an ad break (pod).
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { name, slateMessage, showSlate } = body;
    if (!name) {
      return NextResponse.json({ error: "name es obligatorio" }, { status: 400 });
    }
    const adBreak = await db.adBreak.create({
      data: {
        name,
        slateMessage: slateMessage || null,
        showSlate: showSlate !== false,
      },
    });
    return NextResponse.json(adBreak, { status: 201 });
  } catch (e) {
    return NextResponse.json(
      { error: e instanceof Error ? e.message : "internal error" },
      { status: 500 }
    );
  }
}
