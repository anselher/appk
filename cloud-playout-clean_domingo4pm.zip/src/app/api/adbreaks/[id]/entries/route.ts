import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

// POST /api/adbreaks/[id]/entries — add a commercial (spot) to the pod.
export async function POST(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const { assetId } = await req.json();
    if (!assetId) {
      return NextResponse.json({ error: "assetId obligatorio" }, { status: 400 });
    }
    const count = await db.adBreakEntry.count({ where: { adBreakId: id } });
    const entry = await db.adBreakEntry.create({
      data: { adBreakId: id, assetId, orderIndex: count },
      include: { asset: true },
    });
    return NextResponse.json(entry, { status: 201 });
  } catch (e) {
    return NextResponse.json(
      { error: e instanceof Error ? e.message : "internal error" },
      { status: 500 }
    );
  }
}

// PATCH /api/adbreaks/[id]/entries — reorder all entries.
// body: { order: [entryId, entryId, ...] }
export async function PATCH(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const { order } = (await req.json()) as { order: string[] };
    await db.$transaction(
      order.map((entryId, i) =>
        db.adBreakEntry.update({
          where: { id: entryId, adBreakId: id },
          data: { orderIndex: i },
        })
      )
    );
    return NextResponse.json({ ok: true });
  } catch (e) {
    return NextResponse.json(
      { error: e instanceof Error ? e.message : "internal error" },
      { status: 500 }
    );
  }
}
