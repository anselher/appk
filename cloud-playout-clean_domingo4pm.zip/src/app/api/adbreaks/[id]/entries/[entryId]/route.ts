import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

// DELETE /api/adbreaks/[id]/entries/[entryId] — remove a commercial from the pod.
export async function DELETE(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string; entryId: string }> }
) {
  try {
    const { entryId } = await params;
    await db.adBreakEntry.delete({ where: { id: entryId } });
    return NextResponse.json({ ok: true });
  } catch (e) {
    return NextResponse.json(
      { error: e instanceof Error ? e.message : "internal error" },
      { status: 500 }
    );
  }
}
