import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

// PATCH /api/adbreaks/[id] — update name/slate.
export async function PATCH(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const body = await req.json();
    const data: Record<string, unknown> = {};
    for (const k of ["name", "slateMessage", "showSlate"]) {
      if (k in body) data[k] = body[k];
    }
    const adBreak = await db.adBreak.update({ where: { id }, data });
    return NextResponse.json(adBreak);
  } catch (e) {
    return NextResponse.json(
      { error: e instanceof Error ? e.message : "internal error" },
      { status: 500 }
    );
  }
}

export async function DELETE(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    await db.adBreak.delete({ where: { id } });
    return NextResponse.json({ ok: true });
  } catch (e) {
    return NextResponse.json(
      { error: e instanceof Error ? e.message : "internal error" },
      { status: 500 }
    );
  }
}
