import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

// GET /api/fillers — filler assets for gap-filling selection.
export async function GET() {
  const fillers = await db.asset.findMany({
    where: { category: "FILLER" },
    orderBy: { title: "asc" },
  });
  return NextResponse.json(fillers);
}
