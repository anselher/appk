import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "Canal Nova · Cloud Playout",
  description: "Televisión Lineal por Internet — Cloud Playout System. Transmisión en vivo 24/7 con programación sincronizada en tiempo real.",
  keywords: ["Cloud Playout", "TV Lineal", "Internet TV", "HLS", "Streaming", "Canal Nova"],
  authors: [{ name: "Canal Nova" }],
  icons: {
    icon: "/logo.svg",
  },
  openGraph: {
    title: "Canal Nova · Televisión Lineal",
    description: "Transmisión en vivo 24/7 con programación sincronizada en tiempo real.",
    siteName: "Canal Nova",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "Canal Nova · Televisión Lineal",
    description: "Transmisión en vivo 24/7 con programación sincronizada en tiempo real.",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  // The entire app (viewer + admin) uses a dark broadcast theme. Apply `dark`
  // + `colorScheme: dark` server-side on <html> so there is no client/server
  // mismatch (avoids the hydration warning that occurred when AdminShell set
  // the class via useEffect).
  return (
    <html lang="en" className="dark" style={{ colorScheme: "dark" }} suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
