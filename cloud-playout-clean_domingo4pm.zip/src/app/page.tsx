"use client";

import { useEffect, useState, useCallback, useMemo } from "react";
import Link from "next/link";
import { PanelGroup, Panel, PanelResizeHandle } from "react-resizable-panels";
import { VideoPlayer } from "@/components/viewer/video-player";
import { Epg } from "@/components/viewer/epg";
import { BroadcastTicker } from "@/components/viewer/broadcast-ticker";
import { ProgramChangeToast } from "@/components/viewer/program-change-toast";
import { ShortcutsOverlay, useShortcutsOverlay } from "@/components/viewer/shortcuts-overlay";
import type { PlayoutState, ChannelSettings, EpgEntry } from "@/lib/types";
import { venezuelaDateKey } from "@/lib/playout";

export default function Home() {
  const [state, setState] = useState<PlayoutState | null>(null);
  const [settings, setSettings] = useState<ChannelSettings | null>(null);
  const [previewDate, setPreviewDate] = useState<string | null>(null);
  const [previewState, setPreviewState] = useState<PlayoutState | null>(null);
  const [error, setError] = useState<string | null>(null);
  // Keyboard shortcuts overlay (toggled with "?").
  const shortcuts = useShortcutsOverlay();

  // Fetch channel settings once.
  useEffect(() => {
    fetch("/api/settings")
      .then((r) => r.json())
      .then((s) => setSettings(s))
      .catch((e) => setError(e.message));
  }, []);

  // Poll playout state for live-sync (every 1s for smooth clock + segment tracking).
  useEffect(() => {
    let active = true;
    const tick = () => {
      fetch("/api/playout")
        .then((r) => r.json())
        .then((s) => {
          if (active) {
            setState(s);
            setError(null);
          }
        })
        .catch((e) => active && setError(e.message));
    };
    tick();
    const interval = setInterval(tick, 1000);
    return () => {
      active = false;
      clearInterval(interval);
    };
  }, []);

  // Fetch preview state when a preview date is selected.
  useEffect(() => {
    if (!previewDate) return;
    let active = true;
    fetch(`/api/playout?date=${previewDate}`)
      .then((r) => r.json())
      .then((s) => {
        if (active) setPreviewState(s);
      })
      .catch(() => {
        if (active) setPreviewState(null);
      });
    return () => {
      active = false;
    };
  }, [previewDate]);

  const handleLoadTomorrow = useCallback(() => {
    const base = state?.date ?? venezuelaDateKey();
    const [y, m, d] = base.split("-").map(Number);
    const next = new Date(Date.UTC(y, m - 1, d + 1));
    const key = `${next.getUTCFullYear()}-${String(next.getUTCMonth() + 1).padStart(2, "0")}-${String(next.getUTCDate()).padStart(2, "0")}`;
    setPreviewDate(key);
  }, [state?.date]);

  const displayState = previewDate ? previewState : state;
  const playerSide = settings?.playerSide ?? "left";
  const liveSync = settings?.liveSync ?? true;

  // Compute current + next EPG entries for the broadcast ticker.
  // Special case: if the current segment is a hidden Avance (ghost-with-weight),
  // there's no EPG entry for it — we synthesize one from the segment so the
  // "Viéndolo Ahora" overlay can still show the individual clip title.
  const { tickerNow, tickerNext } = useMemo(() => {
    const epg = displayState?.epg ?? [];
    const now = displayState?.elapsedMs ?? 0;
    let cur: EpgEntry | null = null;
    let nxt: EpgEntry | null = null;
    for (const e of epg) {
      if (now >= e.startMs && now < e.endMs) {
        if (!cur) cur = e;
      } else if (e.startMs > now) {
        if (!nxt && !e.isFiller) nxt = e;
      }
    }

    // Ghost-with-weight: hidden Avance is on-air but has no EPG entry.
    // Synthesize a fake EPG entry from the current segment so the ticker
    // shows the individual clip title (per PO spec).
    const seg = displayState?.currentSegment;
    if (!cur && seg?.kind === "avance" && seg.avanceHidden) {
      cur = {
        slotId: seg.slotId ?? "avance-ghost",
        assetId: seg.assetId,
        // PO suggestion: show the individual clip title, not the container title.
        title: seg.displayTitle ?? seg.avanceTitle ?? "Avance",
        thumbnailUrl: seg.asset.thumbnailUrl,
        category: seg.asset.category,
        startMs: seg.startMs,
        endMs: seg.endMs,
        description: null,
        isFiller: false,
        isAvance: true,
        avanceId: seg.avanceId,
      };
    }

    return { tickerNow: cur, tickerNext: nxt };
  }, [displayState]);

  if (error && !state) {
    return (
      <div className="flex h-screen w-screen items-center justify-center bg-zinc-950 text-zinc-300">
        <div className="text-center">
          <p className="text-lg font-semibold text-red-400">Error de transmisión</p>
          <p className="mt-2 text-sm text-zinc-500">{error}</p>
        </div>
      </div>
    );
  }

  const player = (
    <div className="relative h-full w-full">
      <VideoPlayer
        segment={displayState?.currentSegment ?? null}
        elapsedMs={displayState?.elapsedMs ?? 0}
        liveSync={liveSync}
        slate={displayState?.slate ?? null}
        disablePause={settings?.disablePause}
      />
      {/* Broadcast-style lower-third ticker (only in live mode, not preview).
          Can be toggled off from Admin → Ajustes. */}
      {!previewDate && settings?.showBroadcastTicker !== false && (
        <BroadcastTicker
          current={tickerNow}
          next={tickerNext}
          elapsedMs={displayState?.elapsedMs ?? 0}
          channelLogo={settings?.channelLogo ?? "NV"}
          channelName={settings?.channelName ?? "Canal Nova"}
        />
      )}
    </div>
  );

  const epg = (
    <Epg
      state={displayState}
      previewDate={previewDate}
      onLoadTomorrow={handleLoadTomorrow}
      previewDays={settings?.previewDays ?? 2}
      channelName={settings?.channelName ?? "Canal Nova"}
      channelLogo={settings?.channelLogo ?? "NV"}
    />
  );

  const left = playerSide === "left" ? player : epg;
  const right = playerSide === "left" ? epg : player;
  const leftSize = playerSide === "left" ? 70 : 30;
  const rightSize = playerSide === "left" ? 30 : 70;

  return (
    <div className="flex h-screen w-screen overflow-hidden bg-black">
      {/* Mobile: stacked */}
      <div className="flex h-full w-full flex-col md:hidden">
        <div className="h-[45vh] w-full shrink-0">{player}</div>
        <div className="min-h-0 flex-1">{epg}</div>
      </div>

      {/* Desktop: resizable panels */}
      <div className="hidden md:block h-full w-full">
        <PanelGroup direction="horizontal">
          <Panel defaultSize={leftSize} minSize={25}>
            {left}
          </Panel>
          <PanelResizeHandle className="w-1.5 bg-zinc-900 transition-colors hover:bg-amber-700/60 data-[resize-handle-active]:bg-amber-500" />
          <Panel defaultSize={rightSize} minSize={22}>
            {right}
          </Panel>
        </PanelGroup>
      </div>

      {/* Admin link (bottom-right floating) */}
      <Link
        href="/admin"
        className="group fixed bottom-3 right-3 z-50 flex items-center gap-1.5 rounded-lg border border-zinc-700 bg-zinc-900/90 px-3 py-1.5 text-xs font-medium text-zinc-300 shadow-lg backdrop-blur transition-all hover:border-amber-600/60 hover:bg-zinc-800 hover:text-amber-300"
      >
        <svg className="size-3.5 text-zinc-400 transition-colors group-hover:text-amber-400" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <rect width="18" height="11" x="3" y="3" rx="2" />
          <path d="M7 16h10M9 20h6M12 14v6" />
        </svg>
        Admin
      </Link>

      {/* Preview banner */}
      {previewDate && (
        <button
          onClick={() => setPreviewDate(null)}
          className="fixed left-1/2 top-3 z-50 flex -translate-x-1/2 items-center gap-1.5 rounded-full border border-amber-700/50 bg-amber-950/80 px-4 py-1.5 text-xs font-medium text-amber-200 shadow-lg backdrop-blur transition-colors hover:bg-amber-900/80"
        >
          <span className="relative flex size-2">
            <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-amber-400 opacity-75" />
            <span className="relative inline-flex size-2 rounded-full bg-amber-400" />
          </span>
          Viendo previsualización · Volver a EN VIVO
        </button>
      )}

      {/* Program-change "Now Playing" toast (live mode only).
          Remounts via key on each program change so it re-shows + auto-hides. */}
      {!previewDate && tickerNow && (
        <ProgramChangeToast key={tickerNow.slotId} entry={tickerNow} />
      )}

      {/* Keyboard shortcuts overlay (toggled with "?") */}
      <ShortcutsOverlay open={shortcuts.open} onClose={shortcuts.close} />
    </div>
  );
}
