import { AdminShell } from "@/components/admin/admin-shell";

// Thin wrapper. The AdminShell is a full-viewport SPA (no scrolling on <body>).
export default function AdminPage() {
  return <AdminShell />;
}
