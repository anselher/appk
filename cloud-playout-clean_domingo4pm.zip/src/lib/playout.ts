// Playout Engine — the heart of the Cloud Playout System.
// Computes the 24h timeline for a given date with snap-to-tail, cue points (mid-rolls),
// filler loops, and live-sync offset based on server time (Venezuela GMT-4, America/Caracas).

import { db } from "@/lib/db";
import type {
  PlayoutSegment,
  PlayoutState,
  EpgEntry,
  ChannelSettings,
  Asset,
  ScheduleSlot,
  Avance,
  AvanceClip,
} from "@/lib/types";

// ---- Time helpers (Venezuela = America/Caracas, GMT-4 fixed) ----

export const VENEZUELA_TZ = "America/Caracas";

// Cache the timezone offset from settings (avoid DB hit on every call).
let cachedTzOffsetHours = -4; // default: Venezuela GMT-4
let tzCacheTime = 0;

// Read the configurable timezone offset from DB (cached for 10s).
async function getTzOffsetHours(): Promise<number> {
  if (Date.now() - tzCacheTime < 10000) return cachedTzOffsetHours;
  tzCacheTime = Date.now();
  try {
    const row = await db.channelSetting.findUnique({ where: { key: "timezoneOffset" } });
    if (row?.value) {
      const n = parseFloat(row.value);
      if (isFinite(n) && n >= -12 && n <= 14) cachedTzOffsetHours = n;
    }
  } catch {
    // use default
  }
  return cachedTzOffsetHours;
}

// Sync version for when we already have the offset (used by computePlayoutState).
function applyTzOffset(d: Date, offsetHours: number): Date {
  return new Date(d.getTime() + offsetHours * 3600000);
}

// Format a Date as YYYY-MM-DD in the configured timezone.
// Uses the cached/server offset — call the async version for accuracy.
export function venezuelaDateKey(d: Date = new Date()): string {
  const local = applyTzOffset(d, cachedTzOffsetHours);
  const y = local.getUTCFullYear();
  const m = String(local.getUTCMonth() + 1).padStart(2, "0");
  const day = String(local.getUTCDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

// Async version — reads the offset from DB (use this in server-side code).
export async function venezuelaDateKeyAsync(d: Date = new Date()): Promise<string> {
  const offset = await getTzOffsetHours();
  const local = applyTzOffset(d, offset);
  const y = local.getUTCFullYear();
  const m = String(local.getUTCMonth() + 1).padStart(2, "0");
  const day = String(local.getUTCDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

// Milliseconds elapsed since 00:00:00 in the configured timezone.
export function venezuelaMsSinceMidnight(d: Date = new Date()): number {
  const local = applyTzOffset(d, cachedTzOffsetHours);
  return (
    local.getUTCHours() * 3600000 +
    local.getUTCMinutes() * 60000 +
    local.getUTCSeconds() * 1000 +
    local.getUTCMilliseconds()
  );
}

// Async version — reads the offset from DB.
export async function venezuelaMsSinceMidnightAsync(d: Date = new Date()): Promise<number> {
  const offset = await getTzOffsetHours();
  const local = applyTzOffset(d, offset);
  return (
    local.getUTCHours() * 3600000 +
    local.getUTCMinutes() * 60000 +
    local.getUTCSeconds() * 1000 +
    local.getUTCMilliseconds()
  );
}

const DAY_MS = 24 * 3600 * 1000;

export async function getChannelSettings(): Promise<ChannelSettings> {
  const rows = await db.channelSetting.findMany();
  const map: Record<string, string> = {};
  for (const r of rows) map[r.key] = r.value;
  return {
    channelName: map["channelName"] ?? "Canal Nova",
    channelLogo: map["channelLogo"] ?? "",
    playerSide: (map["playerSide"] as "left" | "right") ?? "left",
    liveSync: map["liveSync"] !== "false",
    previewDays: Number(map["previewDays"] ?? 2),
    slateMessage: map["slateMessage"] ?? "Su programación continuará en {s} segundos",
    timezone: map["timezone"] ?? VENEZUELA_TZ,
    fillFillerAssetId: map["fillFillerAssetId"] || null,
    showBroadcastTicker: map["showBroadcastTicker"] !== "false",
    disablePause: map["disablePause"] === "true",
  };
}

// Fetch the full ordered schedule for a date, including cue points + ad break
// entries + bumper assets + pre/post-roll ad breaks + Avance container (with clips).
export async function getScheduleForDate(date: string): Promise<ScheduleSlot[]> {
  const slots = await db.scheduleSlot.findMany({
    where: { date },
    orderBy: { orderIndex: "asc" },
    include: {
      asset: true,
      // Avance container (only present when slotType === "avance").
      avance: {
        include: {
          clips: {
            orderBy: { orderIndex: "asc" },
            include: { asset: true },
          },
        },
      },
      cuePoints: {
        orderBy: { offsetMs: "asc" },
        include: {
          adBreak: {
            include: {
              entries: {
                orderBy: { orderIndex: "asc" },
                include: { asset: true },
              },
              bumperBefore: true,
              bumperAfter: true,
            },
          },
        },
      },
      // Pre-roll / post-roll ad breaks (with their entries + bumpers).
      preRollAdBreak: {
        include: {
          entries: { orderBy: { orderIndex: "asc" }, include: { asset: true } },
          bumperBefore: true,
          bumperAfter: true,
        },
      },
      postRollAdBreak: {
        include: {
          entries: { orderBy: { orderIndex: "asc" }, include: { asset: true } },
          bumperBefore: true,
          bumperAfter: true,
        },
      },
    },
  });
  return slots as unknown as ScheduleSlot[];
}

export async function getDefaultFiller(): Promise<Asset | null> {
  const settings = await getChannelSettings();
  if (settings.fillFillerAssetId) {
    const a = await db.asset.findUnique({ where: { id: settings.fillFillerAssetId } });
    if (a) return a as unknown as Asset;
  }
  const f = await db.asset.findFirst({ where: { category: "FILLER" } });
  return (f as unknown as Asset) ?? null;
}

// Map of avanceId → render info (for pre-fetched renders).
// When a render exists, the Avance is emitted as a SINGLE segment (the MP4)
// instead of N individual clip segments — eliminates gaps/rebuffering.
export interface RenderInfo {
  filePath: string;     // e.g. "renders/avance_xxx.mp4"
  durationMs: number;
}

// Build the full playout timeline (atomic segments) for a date.
// Timeline starts at 00:00:00 (ms=0) and runs until 23:59:59.999 (ms=DAY_MS-1).
// Snap-to-tail: each segment starts where the previous ended.
// Fillers: empty gaps are filled by looping the default filler asset.
//
// rendersByAvanceId: optional map of avanceId → RenderInfo. When present and
// an Avance has a completed render, the Avance is emitted as a SINGLE segment
// (the rendered MP4) instead of N individual clip segments. This eliminates
// gaps, rebuffering, and black flashes between clips during live playback.
export function buildTimeline(
  slots: ScheduleSlot[],
  fallbackFiller: Asset | null,
  settings: ChannelSettings,
  rendersByAvanceId?: Map<string, RenderInfo>
): PlayoutSegment[] {
  const segments: PlayoutSegment[] = [];
  let cursor = 0; // ms from midnight

  const placeFiller = (untilMs: number) => {
    if (!fallbackFiller || fallbackFiller.durationMs <= 0) return;
    while (cursor < untilMs && cursor < DAY_MS) {
      const remaining = Math.min(untilMs, DAY_MS) - cursor;
      const dur = Math.min(fallbackFiller.durationMs, remaining);
      if (dur <= 0) break;
      segments.push({
        kind: "filler",
        assetId: fallbackFiller.id,
        asset: fallbackFiller,
        startMs: cursor,
        endMs: cursor + dur,
        seekOffsetMs: (cursor % fallbackFiller.durationMs),
      });
      cursor += dur;
    }
  };

  // Helper: place an ad break block (bumper-before + entries + bumper-after).
  // adBreakId is the parent break; slateMessage/showSlate come from the break.
  const placeAdBreakBlock = (
    adBreak: { id: string; slateMessage: string | null; showSlate: boolean; entries: Array<{ asset: Asset; orderIndex: number }>; bumperBefore?: Asset | null; bumperAfter?: Asset | null },
    slotId: string,
    settings: ChannelSettings
  ) => {
    // Bumper before (program→ads transition): "Ya volvemos" / station ident.
    if (adBreak.bumperBefore && adBreak.bumperBefore.durationMs > 0) {
      const bDur = Math.min(adBreak.bumperBefore.durationMs, 15_000);
      segments.push({
        kind: "bumper",
        assetId: adBreak.bumperBefore.id,
        asset: adBreak.bumperBefore,
        startMs: cursor,
        endMs: cursor + bDur,
        seekOffsetMs: 0,
        bumperRole: "pre",
        adBreakId: adBreak.id,
        slotId,
      });
      cursor += bDur;
    }
    // Ad entries.
    const entries = [...adBreak.entries].sort((a, b) => a.orderIndex - b.orderIndex);
    for (const entry of entries) {
      const adAsset = entry.asset;
      const adDur = Math.max(adAsset.durationMs, 1000);
      segments.push({
        kind: "ad",
        assetId: adAsset.id,
        asset: adAsset,
        startMs: cursor,
        endMs: cursor + adDur,
        seekOffsetMs: 0,
        adBreakId: adBreak.id,
        slateMessage: adBreak.slateMessage ?? settings.slateMessage,
        showSlate: adBreak.showSlate,
        slotId,
      });
      cursor += adDur;
    }
    // Bumper after (ads→program transition): "Continuamos" / station ident.
    if (adBreak.bumperAfter && adBreak.bumperAfter.durationMs > 0) {
      const bDur = Math.min(adBreak.bumperAfter.durationMs, 15_000);
      segments.push({
        kind: "bumper",
        assetId: adBreak.bumperAfter.id,
        asset: adBreak.bumperAfter,
        startMs: cursor,
        endMs: cursor + bDur,
        seekOffsetMs: 0,
        bumperRole: "post",
        adBreakId: adBreak.id,
        slotId,
      });
      cursor += bDur;
    }
  };

  // Helper: place an Avance block.
  // If a completed render exists (rendersByAvanceId map), emit a SINGLE segment
  // using the rendered MP4 — this eliminates gaps/rebuffering between clips.
  // Otherwise, fall back to individual clip segments (one per clip with In/Out cut).
  //
  // Ghost-with-weight: the cursor advances regardless of hideFromEpg, but the
  // EPG builder will skip entries marked as hidden.
  //
  // Fade in/out: when using the RENDER, fades are already baked into the MP4
  // (ffmpeg applied them during rendering), so we do NOT set avanceFadeIn/Out
  // markers (the viewer overlay would double-apply them).
  // When using INDIVIDUAL CLIPS (fallback), the fade markers are set on the
  // first/last clip and the viewer applies them via the overlay.
  const placeAvanceBlock = (
    avance: Avance,
    slotId: string
  ) => {
    // ---- Check for a completed render ----
    const render = rendersByAvanceId?.get(avance.id);
    if (render && render.durationMs > 0) {
      // Use the render — a single segment with the MP4 URL.
      // The fades are already baked into the MP4, so no fade markers.
      const renderUrl = `/api/media/${render.filePath}`;
      const renderAsset: Asset = {
        ...avance.clips[0]?.asset,  // reuse the first clip's asset as a template
        id: `render-${avance.id}`,
        title: avance.title,
        hlsUrl: renderUrl,          // override with the render MP4 URL
        durationMs: render.durationMs,
        thumbnailUrl: avance.clips[0]?.asset.thumbnailUrl ?? null,
      };
      segments.push({
        kind: "avance",
        assetId: renderAsset.id,
        asset: renderAsset,
        startMs: cursor,
        endMs: cursor + render.durationMs,
        seekOffsetMs: 0,
        slotId,
        avanceId: avance.id,
        avanceTitle: avance.title,
        avanceHidden: avance.hideFromEpg,
        // No avanceClipId — it's a single render, not a specific clip.
        displayTitle: avance.title,
        // No avanceFadeIn/Out — fades are baked into the MP4.
      });
      cursor += render.durationMs;
      return;
    }

    // ---- Fallback: individual clip segments (original behavior) ----
    const clips = [...avance.clips].sort((a, b) => a.orderIndex - b.orderIndex);
    const lastIndex = clips.length - 1;
    clips.forEach((clip, i) => {
      const clipAsset = clip.asset;
      const assetDur = Math.max(clipAsset.durationMs, 1000);
      // Resolve cut: inMs defaults to 0; outMs=0 means "use asset duration".
      const inMs = Math.max(0, Math.min(clip.inMs || 0, assetDur - 1));
      const outMs = Math.max(inMs + 1, Math.min(clip.outMs && clip.outMs > 0 ? clip.outMs : assetDur, assetDur));
      const clipDur = outMs - inMs;
      if (clipDur <= 0) return;
      segments.push({
        kind: "avance",
        assetId: clipAsset.id,
        asset: clipAsset,
        startMs: cursor,
        endMs: cursor + clipDur,
        seekOffsetMs: inMs,
        slotId,
        avanceId: avance.id,
        avanceTitle: avance.title,
        avanceHidden: avance.hideFromEpg,
        avanceClipId: clip.id,
        // Per PO: when hidden, "Viéndolo Ahora" shows the individual clip title.
        displayTitle: clipAsset.title,
        // Fade markers — only on first/last clip when fadeEnabled is true.
        ...(avance.fadeEnabled && i === 0 && avance.fadeInMs > 0
          ? { avanceFadeIn: { ms: Math.min(avance.fadeInMs, clipDur) } }
          : {}),
        ...(avance.fadeEnabled && i === lastIndex && avance.fadeOutMs > 0
          ? { avanceFadeOut: { ms: Math.min(avance.fadeOutMs, clipDur) } }
          : {}),
      });
      cursor += clipDur;
    });
  };

  for (const slot of slots) {
    // Fill any gap before this slot with filler loops.
    if (cursor < 0) cursor = 0;
    if (cursor < DAY_MS) placeFiller(cursor); // no-op unless gap

    if (slot.fillerLoop) {
      // This slot is itself a filler loop block.
      const asset = slot.asset;
      if (asset.durationMs > 0) {
        const windowEnd = Math.min(cursor + asset.durationMs, DAY_MS);
        segments.push({
          kind: "filler",
          assetId: asset.id,
          asset,
          startMs: cursor,
          endMs: windowEnd,
          seekOffsetMs: 0,
          slotId: slot.id,
        });
        cursor = windowEnd;
      }
      continue;
    }

    // ---- AVANCE slot: multiprogram container with per-clip In/Out cuts ----
    // Cursor advances regardless of hideFromEpg (ghost-with-weight).
    // The EPG builder reads avance.hideFromEpg to decide visibility.
    if (slot.slotType === "avance" && slot.avance) {
      placeAvanceBlock(slot.avance, slot.id);
      continue;
    }

    // Pre-roll ad break (plays before the program).
    if (slot.preRollAdBreak && slot.preRollAdBreak.entries.length > 0) {
      placeAdBreakBlock(slot.preRollAdBreak, slot.id, settings);
    }

    // Program slot: split into program chunks around cue points (mid-roll ad breaks).
    const program = slot.asset;
    const programDuration = Math.max(program.durationMs, 1000);
    const cues = [...slot.cuePoints].sort((a, b) => a.offsetMs - b.offsetMs);

    let programCursor = 0; // ms within the program asset
    for (const cue of cues) {
      const cpOffset = Math.max(0, Math.min(cue.offsetMs, programDuration));
      if (cpOffset > programCursor) {
        const chunkDur = cpOffset - programCursor;
        segments.push({
          kind: "program",
          assetId: program.id,
          asset: program,
          startMs: cursor,
          endMs: cursor + chunkDur,
          seekOffsetMs: programCursor,
          slotId: slot.id,
        });
        cursor += chunkDur;
        programCursor = cpOffset;
      }
      // Mid-roll ad break block (with bumpers + entries).
      placeAdBreakBlock(cue.adBreak, slot.id, settings);
    }
    // Remaining program chunk after the last cue (or the whole program if no cues).
    if (programCursor < programDuration) {
      const chunkDur = programDuration - programCursor;
      segments.push({
        kind: "program",
        assetId: program.id,
        asset: program,
        startMs: cursor,
        endMs: cursor + chunkDur,
        seekOffsetMs: programCursor,
        slotId: slot.id,
      });
      cursor += chunkDur;
    }

    // Post-roll ad break (plays after the program).
    if (slot.postRollAdBreak && slot.postRollAdBreak.entries.length > 0) {
      placeAdBreakBlock(slot.postRollAdBreak, slot.id, settings);
    }
  }

  // Fill the tail of the day with filler loops until 23:59:59.999.
  placeFiller(DAY_MS);

  return segments;
}

// Build the viewer-visible EPG (ad breaks are folded into their parent program window).
// AVANCE rule: if slot.slotType === "avance" and avance.hideFromEpg === true,
// the slot is EXCLUDED from the EPG entirely — but its duration already pushed
// the cursor in buildTimeline, so the next visible program's startMs reflects
// the hidden Avance's weight. ("Ghost with weight".)
export function buildEpg(slots: ScheduleSlot[], segments: PlayoutSegment[]): EpgEntry[] {
  const epg: EpgEntry[] = [];

  // For each slot, collect its segments (tagged with slotId) and compute the wallclock window.
  for (const slot of slots) {
    const slotSegs = segments.filter((s) => s.slotId === slot.id);
    if (slotSegs.length === 0) continue;
    const startMs = slotSegs[0].startMs;
    const endMs = slotSegs[slotSegs.length - 1].endMs;

    // ---- AVANCE ghost-with-weight ----
    // Skip hidden Avances from the viewer EPG. Their duration already moved
    // the cursor in buildTimeline, so the next entry's startMs is correct.
    if (slot.slotType === "avance" && slot.avance?.hideFromEpg) {
      continue;
    }

    // For Avance (visible), use the Avance title (not the legacy slot.asset.title,
    // which is just the first clip's asset for backward compat).
    if (slot.slotType === "avance" && slot.avance) {
      epg.push({
        slotId: slot.id,
        assetId: slot.assetId,
        title: slot.avance.title,
        thumbnailUrl: slot.asset.thumbnailUrl,
        category: slot.asset.category,
        startMs,
        endMs,
        description: slot.avance.description ?? slot.asset.description,
        isFiller: false,
        isAvance: true,
        avanceId: slot.avance.id,
        avanceColor: slot.avance.color,
      });
      continue;
    }

    epg.push({
      slotId: slot.id,
      assetId: slot.assetId,
      title: slot.asset.title,
      thumbnailUrl: slot.asset.thumbnailUrl,
      category: slot.asset.category,
      startMs,
      endMs,
      description: slot.asset.description,
      isFiller: slot.fillerLoop,
    });
  }

  // Add filler EPG entries for gap-fillers that aren't tied to any slot.
  for (const seg of segments) {
    if (seg.kind !== "filler") continue;
    if (seg.slotId) continue; // belongs to a slot, already handled
    const last = epg[epg.length - 1];
    if (last && last.isFiller && last.assetId === seg.assetId && last.endMs === seg.startMs) {
      last.endMs = seg.endMs;
    } else {
      epg.push({
        slotId: "gap-" + seg.startMs,
        assetId: seg.assetId,
        title: seg.asset.title + " (Planta)",
        thumbnailUrl: seg.asset.thumbnailUrl,
        category: seg.asset.category,
        startMs: seg.startMs,
        endMs: seg.endMs,
        description: seg.asset.description,
        isFiller: true,
      });
    }
  }
  return epg.sort((a, b) => a.startMs - b.startMs);
}

// Find the segment playing at a given elapsed-ms-from-midnight.
export function findSegmentAt(
  segments: PlayoutSegment[],
  elapsedMs: number
): PlayoutSegment | null {
  for (const s of segments) {
    if (elapsedMs >= s.startMs && elapsedMs < s.endMs) return s;
  }
  // end of day
  if (segments.length) return segments[segments.length - 1];
  return null;
}

// Compute the full playout state for "now" (live-sync).
//
// rendersByAvanceId: optional pre-fetched map of avanceId → RenderInfo.
// The caller (typically the /api/playout route) should look up completed renders
// and pass them here. This separation is needed because render.ts imports
// `child_process` (Node.js only) and can't be bundled for the browser —
// playout.ts is imported by client components, so it must stay browser-safe.
export async function computePlayoutState(
  now: Date = new Date(),
  rendersByAvanceId?: Map<string, RenderInfo>
): Promise<PlayoutState> {
  // Use async versions to read the correct timezone offset from DB.
  const date = await venezuelaDateKeyAsync(now);
  const elapsedMs = await venezuelaMsSinceMidnightAsync(now);
  const settings = await getChannelSettings();
  const slots = await getScheduleForDate(date);
  const filler = await getDefaultFiller();

  const segments = buildTimeline(slots, filler, settings, rendersByAvanceId);
  const epg = buildEpg(slots, segments);

  const currentSegment = findSegmentAt(segments, elapsedMs);
  const currentEpgEntry =
    epg.find((e) => elapsedMs >= e.startMs && elapsedMs < e.endMs) ?? null;
  const nextEpgEntry =
    epg.find((e) => e.startMs > elapsedMs && !e.isFiller) ?? null;

  // Slate overlay during ad breaks or filler.
  // The slate countdown shows the TOTAL remaining time of the entire ad break block
  // (not per-spot). This means if you're 10s into a 60s ad break with 3 spots,
  // the slate shows "50 seconds" (time until the program resumes), not the
  // remaining time of the current individual spot.
  let slate: { message: string; secondsLeft: number } | null = null;
  if (currentSegment && (currentSegment.kind === "ad" || currentSegment.kind === "filler")) {
    if (currentSegment.showSlate !== false) {
      const msg =
        currentSegment.slateMessage ?? settings.slateMessage ?? "Continuará en {s} segundos";

      // Find the end of the current ad break block.
      // For ad segments: find the last consecutive ad segment with the same adBreakId.
      // For filler segments: find the last consecutive filler segment.
      let blockEndMs = currentSegment.endMs;
      const currentIdx = segments.indexOf(currentSegment);
      if (currentIdx >= 0) {
        for (let i = currentIdx + 1; i < segments.length; i++) {
          const nextSeg = segments[i];
          if (nextSeg.kind !== currentSegment.kind) break;
          if (currentSegment.kind === "ad" && nextSeg.adBreakId !== currentSegment.adBreakId) break;
          if (nextSeg.startMs !== blockEndMs) break; // not contiguous
          blockEndMs = nextSeg.endMs;
        }
      }

      const secsLeft = Math.max(0, Math.ceil((blockEndMs - elapsedMs) / 1000));
      slate = { message: msg.replace("{s}", String(secsLeft)), secondsLeft: secsLeft };
    }
  }

  return {
    now: now.toISOString(),
    date,
    elapsedMs,
    currentSegment,
    currentEpgEntry,
    nextEpgEntry,
    segments,
    epg,
    slate,
  };
}

// Format ms-from-midnight as HH:MM:SS (Venezuela wallclock, 24h).
// Used internally for the admin clock and playout logs.
export function msToWallclock(ms: number): string {
  const total = Math.max(0, Math.floor(ms / 1000));
  const h = Math.floor(total / 3600) % 24;
  const m = Math.floor((total % 3600) / 60);
  const s = total % 60;
  return [h, m, s].map((n) => String(n).padStart(2, "0")).join(":");
}

// Format ms-from-midnight as "HH:MM AM/PM" (12-hour, no seconds).
// Used in the viewer EPG so end users see friendly times like "07:15 AM"
// instead of the broadcast-style "07:15:00".
//
// Special cases:
//  - 00:00 (midnight) → "12:00 AM"
//  - 12:00 (noon)     → "12:00 PM"
//  - 13:00 (1 PM)     → "01:00 PM"
export function msToWallclock12h(ms: number): string {
  const total = Math.max(0, Math.floor(ms / 1000));
  let h = Math.floor(total / 3600) % 24;
  const m = Math.floor((total % 3600) / 60);
  const ampm = h < 12 ? "AM" : "PM";
  // Convert 0→12 (12 AM), 13→1, 23→11, 12→12 (12 PM)
  if (h === 0) h = 12;
  else if (h > 12) h -= 12;
  return `${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")} ${ampm}`;
}

export function msToHMMSS(ms: number): string {
  const total = Math.floor(ms / 1000);
  const h = Math.floor(total / 3600);
  const m = Math.floor((total % 3600) / 60);
  const s = total % 60;
  if (h > 0) return `${h}h ${String(m).padStart(2, "0")}m`;
  return `${m}m ${String(s).padStart(2, "0")}s`;
}
