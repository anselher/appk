// FFmpeg helper — probe, adaptive ABR HLS transcode (no upscaling), thumbnail generation.
// Uses system ffmpeg (or a custom path from ChannelSetting "ffmpegPath").

import ffmpeg from "fluent-ffmpeg";
import { promises as fs } from "fs";
import path from "path";
import { getChannelSettings } from "@/lib/playout";

// ---- FFmpeg binary path resolution ----
// Priority: ChannelSetting "ffmpegPath" > system PATH (null = let ffmpeg use PATH).
let resolvedFfmpegPath: string | null = null;
let lastResolveTime = 0;

async function resolveFfmpegPath(): Promise<string | null> {
  // Cache for 30s to avoid hitting the DB on every call.
  if (Date.now() - lastResolveTime < 30000) return resolvedFfmpegPath;
  lastResolveTime = Date.now();
  try {
    const settings = await getChannelSettings();
    const custom = (settings as unknown as Record<string, string>).ffmpegPath;
    resolvedFfmpegPath = custom && custom.trim() ? custom.trim() : null;
  } catch {
    resolvedFfmpegPath = null;
  }
  return resolvedFfmpegPath;
}

async function getCommand(input: string): Promise<ffmpeg.FfmpegCommand> {
  const cmd = ffmpeg(input);
  const fpath = await resolveFfmpegPath();
  if (fpath) {
    cmd.setFfmpegPath(fpath);
  }
  return cmd;
}

// ---- Video probe ----

export interface VideoProbe {
  durationMs: number;
  width: number;
  height: number;
  codec: string;
  bitrate: number; // bits per second (0 if unknown)
  hasAudio: boolean;
  fps: number;
}

export async function probeVideo(filePath: string): Promise<VideoProbe> {
  return new Promise(async (resolve, reject) => {
    const cmd = await getCommand(filePath);
    cmd.ffprobe((err, data) => {
      if (err) {
        reject(new Error(`ffprobe failed: ${err.message}`));
        return;
      }
      const vStream = data.streams.find((s) => s.codec_type === "video");
      const aStream = data.streams.find((s) => s.codec_type === "audio");
      const durationSec = data.format.duration ? parseFloat(data.format.duration) : 0;
      const bitrate = data.format.bit_rate ? parseInt(data.format.bit_rate) : 0;
      const fps = vStream?.avg_frame_rate
        ? eval(vStream.avg_frame_rate) // e.g. "30000/1001" → 29.97
        : 0;

      resolve({
        durationMs: Math.round(durationSec * 1000),
        width: vStream?.width ?? 0,
        height: vStream?.height ?? 0,
        codec: vStream?.codec_name ?? "unknown",
        bitrate,
        hasAudio: !!aStream,
        fps: isFinite(fps) ? Math.round(fps * 100) / 100 : 0,
      });
    });
  });
}

// ---- Adaptive ABR ladder (no upscaling) ----
// Given the source height, return the list of variants to generate.
// Each variant: { label, height, width, bitrate (video kbps), audio kbps }
// Variants are sorted from lowest to highest quality.
export interface ABRVariant {
  label: string; // e.g. "720p"
  height: number;
  width: number; // 0 = auto-scale (keep aspect ratio)
  videoBitrate: string; // e.g. "2500k"
  audioBitrate: string; // e.g. "128k"
}

// Standard ABR ladder (HLS reference).
const FULL_LADDER: ABRVariant[] = [
  { label: "240p", height: 240, width: 426, videoBitrate: "400k", audioBitrate: "64k" },
  { label: "360p", height: 360, width: 640, videoBitrate: "800k", audioBitrate: "96k" },
  { label: "480p", height: 480, width: 854, videoBitrate: "1200k", audioBitrate: "128k" },
  { label: "720p", height: 720, width: 1280, videoBitrate: "2500k", audioBitrate: "128k" },
  { label: "1080p", height: 1080, width: 1920, videoBitrate: "5000k", audioBitrate: "160k" },
];

export function getAdaptiveLadder(sourceHeight: number): ABRVariant[] {
  if (sourceHeight <= 0) return FULL_LADDER; // unknown → generate all
  // Only include variants at or below the source resolution.
  // Always include at least one variant (the source resolution or closest below).
  const variants = FULL_LADDER.filter((v) => v.height <= sourceHeight);
  if (variants.length === 0) {
    // Source is very low res — create a single variant at the source height.
    return [
      {
        label: `${sourceHeight}p`,
        height: sourceHeight,
        width: 0, // auto-scale
        videoBitrate: "500k",
        audioBitrate: "64k",
      },
    ];
  }
  return variants;
}

// ---- Thumbnail generation ----
// Extracts a single frame at ~10% of the video duration (or 1s if too short).
export async function generateThumbnail(
  inputPath: string,
  outputPath: string,
  durationMs: number
): Promise<void> {
  // Use 10% of duration, but at least 1s and at most 60s.
  const seekSec = Math.max(1, Math.min(60, (durationMs / 1000) * 0.1));

  return new Promise(async (resolve, reject) => {
    const cmd = await getCommand(inputPath);
    cmd
      .seekInput(seekSec)
      .frames(1)
      .size("?x360") // scale to 360px height, auto width
      .outputOptions(["-q:v 4", "-f image2", "-y"])
      .output(outputPath)
      .on("end", () => resolve())
      .on("error", (err) => reject(new Error(`thumbnail failed: ${err.message}`)))
      .run();
  });
}

// ---- HLS ABR Transcode ----
// Transcodes the input into multiple HLS variant playlists + a master.m3u8.
// No upscaling: only variants at or below the source resolution are generated.
//
// Output structure:
//   {outputDir}/
//     master.m3u8
//     thumb.jpg
//     v_240p/
//       index.m3u8
//       seg_00000.ts
//       seg_00001.ts
//       ...
//     v_480p/
//       ...
//
// Progress callback receives 0-100.
export interface TranscodeResult {
  masterPlaylistPath: string;
  thumbnailPath: string;
  variants: ABRVariant[];
  durationMs: number;
  width: number;
  height: number;
}

export async function transcodeToHLS(
  inputPath: string,
  outputDir: string,
  onProgress?: (pct: number) => void
): Promise<TranscodeResult> {
  // Ensure output dir exists.
  await fs.mkdir(outputDir, { recursive: true });

  // Probe the source.
  const probe = await probeVideo(inputPath);
  if (probe.durationMs <= 0) {
    throw new Error("Could not determine video duration");
  }

  const variants = getAdaptiveLadder(probe.height);
  const thumbPath = path.join(outputDir, "thumb.jpg");

  // Generate thumbnail first (quick, gives immediate visual feedback).
  try {
    await generateThumbnail(inputPath, thumbPath, probe.durationMs);
  } catch (e) {
    console.error("[ffmpeg] Thumbnail generation failed:", e);
    // Non-fatal — continue without thumbnail.
  }

  // Transcode each variant sequentially.
  // (Parallel transcoding would compete for CPU; sequential is more stable.)
  const totalVariants = variants.length;
  for (let i = 0; i < totalVariants; i++) {
    const v = variants[i];
    const variantDir = path.join(outputDir, `v_${v.label}`);
    await fs.mkdir(variantDir, { recursive: true });
    const variantPlaylist = path.join(variantDir, "index.m3u8");
    const segPattern = path.join(variantDir, "seg_%05d.ts");

    await new Promise<void>(async (resolve, reject) => {
      const cmd = await getCommand(inputPath);
      const scaleFilter = v.width > 0
        ? `scale=${v.width}:${v.height}:force_original_aspect_ratio=decrease,pad=${v.width}:${v.height}:(ow-iw)/2:(oh-ih)/2`
        : `scale=-2:${v.height}`;

      cmd
        .videoCodec("libx264")
        .videoBitrate(v.videoBitrate)
        .outputOptions([
          `-vf ${scaleFilter}`,
          "-preset veryfast",
          "-g 48", // GOP = 2x framerate for HLS
          "-keyint_min 48",
          "-sc_threshold 0",
          "-profile:v high",
          "-level 4.0",
          "-pix_fmt yuv420p",
        ])
        .audioCodec("aac")
        .audioBitrate(v.audioBitrate)
        .outputOptions([
          "-ac 2",
          "-ar 48000",
          "-f hls",
          "-hls_time 6",
          "-hls_playlist_type vod",
          `-hls_segment_filename ${segPattern}`,
          "-hls_flags independent_segments",
        ])
        .output(variantPlaylist)
        .on("progress", (info) => {
          if (onProgress && info.percent) {
            // Progress within this variant: 0-100.
            // Overall progress: (completedVariants + thisVariantProgress) / totalVariants.
            const overallPct = Math.round(
              ((i + info.percent / 100) / totalVariants) * 100
            );
            onProgress(Math.min(99, overallPct));
          }
        })
        .on("end", () => resolve())
        .on("error", (err) => reject(new Error(`transcode ${v.label} failed: ${err.message}`)))
        .run();
    });
  }

  // Generate master.m3u8 manually.
  const masterContent = generateMasterPlaylist(variants, probe);
  const masterPath = path.join(outputDir, "master.m3u8");
  await fs.writeFile(masterPath, masterContent, "utf-8");

  onProgress?.(100);

  return {
    masterPlaylistPath: masterPath,
    thumbnailPath: thumbPath,
    variants,
    durationMs: probe.durationMs,
    width: probe.width,
    height: probe.height,
  };
}

// Generate the HLS master playlist content.
function generateMasterPlaylist(variants: ABRVariant[], probe: VideoProbe): string {
  const lines: string[] = [
    "#EXTM3U",
    "#EXT-X-VERSION:6",
  ];

  // Sort variants highest to lowest in the master (HLS convention).
  const sorted = [...variants].sort((a, b) => b.height - a.height);

  for (const v of sorted) {
    const bandwidth = parseInt(v.videoBitrate) * 1000 + parseInt(v.audioBitrate) * 1000;
    const resolution = `${v.width}x${v.height}`;
    // Add #EXT-X-STREAM-INF with bandwidth, resolution, and codecs.
    lines.push(
      `#EXT-X-STREAM-INF:BANDWIDTH=${bandwidth},RESOLUTION=${resolution},CODECS="avc1.4d4028,mp4a.40.2"`
    );
    lines.push(`v_${v.label}/index.m3u8`);
  }

  return lines.join("\n") + "\n";
}

// ---- Check if ffmpeg is available ----
export async function checkFfmpegAvailable(): Promise<{ ok: boolean; version?: string; error?: string }> {
  return new Promise(async (resolve) => {
    try {
      const cmd = await getCommand("");
      // fluent-ffmpeg doesn't have a direct "version" method, but we can
      // run a simple ffprobe on an empty input to see if the binary exists.
      // Instead, let's try to run ffmpeg -version via a temporary command.
      const { execFile } = await import("child_process");
      const fpath = await resolveFfmpegPath();
      const bin = fpath || "ffmpeg";
      execFile(bin, ["-version"], (err, stdout) => {
        if (err) {
          resolve({ ok: false, error: err.message });
        } else {
          const versionLine = stdout.split("\n")[0];
          resolve({ ok: true, version: versionLine });
        }
      });
    } catch (e) {
      resolve({ ok: false, error: e instanceof Error ? e.message : "unknown" });
    }
  });
}
