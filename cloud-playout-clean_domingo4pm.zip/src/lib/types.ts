// Shared types for the Cloud Playout System

export type AssetCategory = "PROGRAM" | "FILLER" | "SPOT" | "BUMPER";

export interface Asset {
  id: string;
  title: string;
  originalFilename: string;
  category: AssetCategory;
  durationMs: number;
  hlsUrl: string;
  thumbnailUrl: string | null;
  description: string | null;
  resolutionVariants: string;
  createdAt: string;
  updatedAt: string;
}

export interface ScheduleSlot {
  id: string;
  date: string; // YYYY-MM-DD (Venezuela)
  orderIndex: number;
  slotType: "program" | "avance"; // default: "program"
  assetId: string;
  asset: Asset;
  fillerLoop: boolean;
  // When slotType === "avance", this references the Avance container.
  avanceId?: string | null;
  avance?: Avance | null;
  cuePoints: CuePoint[];
  // Pre-roll / post-roll ad breaks (play before/after the program). Optional.
  preRollAdBreakId?: string | null;
  postRollAdBreakId?: string | null;
  preRollAdBreak?: AdBreak | null;
  postRollAdBreak?: AdBreak | null;
}

// ---- "BLOQUE AVANCE" (Avance Programático) ----
// A multiprogram container — independent from AdBreak (spots).
// Each Avance holds N ordered clips (any category), each with its own In/Out cut.
export interface Avance {
  id: string;
  title: string;
  description: string | null;
  // "Ghost with weight": when true, hidden from viewer EPG but still consumes time.
  hideFromEpg: boolean;
  // Container-level validity window (null = no restriction).
  validFrom: string | null; // ISO
  validUntil: string | null; // ISO
  // Auto-calculated sum of (outMs - inMs) across all clips.
  totalDurationMs: number;
  color: string; // visual color hint for the schedule grid
  // ---- Audio/Video fades ----
  // Master toggle — when false, fades are disabled.
  fadeEnabled: boolean;
  // Fade-in duration in ms (0-1000). Applied at the start of the first clip.
  fadeInMs: number;
  // Fade-out duration in ms (0-1000). Applied at the end of the last clip.
  fadeOutMs: number;
  createdAt: string;
  updatedAt: string;
  clips: AvanceClip[];
}

export interface AvanceClip {
  id: string;
  avanceId: string;
  assetId: string;
  asset: Asset;
  orderIndex: number;
  // Per-clip linear cut (config-only).
  inMs: number;
  outMs: number; // 0 sentinel = use asset.durationMs (resolved at runtime)
  createdAt: string;
}

// ---- Rendered Avance (cached MP4 render) ----
// A single MP4 file produced by ffmpeg that contains all the Avance's clips
// concatenated with their In/Out cuts applied + fade in/out.
// The viewer plays this single MP4 instead of switching between N HLS clips.
export interface RenderedAvance {
  id: string;
  avanceId: string;
  scheduleSlotId: string | null;
  date: string;          // YYYY-MM-DD broadcast date
  expiresAt: string;     // ISO datetime
  filePath: string;      // relative path inside /uploads/renders/
  durationMs: number;
  fileSizeBytes: number;
  status: "pending" | "rendering" | "completed" | "failed" | "stale";
  progress: number;      // 0-100
  error: string | null;
  createdAt: string;
  updatedAt: string;
}

export interface CuePoint {
  id: string;
  scheduleSlotId: string;
  offsetMs: number;
  adBreak: AdBreak;
}

export interface AdBreak {
  id: string;
  name: string;
  slateMessage: string | null;
  showSlate: boolean;
  entries: AdBreakEntry[];
  // Bumpers: short (2-15s) station-ident clips played before/after the break.
  bumperBeforeId?: string | null;
  bumperAfterId?: string | null;
  bumperBefore?: Asset | null;
  bumperAfter?: Asset | null;
}

export interface AdBreakEntry {
  id: string;
  adBreakId: string;
  assetId: string;
  asset: Asset;
  orderIndex: number;
}

export interface ChannelSettings {
  channelName: string;
  channelLogo: string;
  playerSide: "left" | "right";
  liveSync: boolean;
  previewDays: number;
  slateMessage: string;
  timezone: string; // America/Caracas
  fillFillerAssetId: string | null;
  // Media storage config (added in v2)
  mediaStoragePath?: string; // absolute or relative to project root (default: ./uploads)
  ffmpegPath?: string; // custom FFmpeg binary path (empty = use system PATH)
  timezoneOffset?: string; // hours offset from UTC (default: -4 for Venezuela)
  // Viewer overlay toggles
  showBroadcastTicker?: boolean; // show the lower-third "Ahora/Siguiente" ticker on the viewer
  disablePause?: boolean; // when true, the viewer video can't be paused (click does nothing, double-click = fullscreen)
}

// ---- Playout Engine output types ----

// A single atomic segment of playback (program chunk, ad, filler, bumper, or avance-clip).
export interface PlayoutSegment {
  kind: "program" | "ad" | "filler" | "bumper" | "avance";
  assetId: string;
  asset: Asset;
  // wallclock window
  startMs: number; // ms from midnight (Venezuela)
  endMs: number;
  // within-asset seek offset
  seekOffsetMs: number;
  // for ad segments, the parent ad break context
  adBreakId?: string;
  slateMessage?: string;
  showSlate?: boolean;
  // bumper role: "pre" (program→ads), "post" (ads→program), or undefined (not a bumper)
  bumperRole?: "pre" | "post";
  // slot this segment belongs to (null for gap fillers)
  slotId?: string;
  // ---- Avance context (kind === "avance" only) ----
  // ID of the parent Avance container.
  avanceId?: string;
  // Title of the parent Avance container (for the "Viéndolo Ahora" overlay when hidden).
  avanceTitle?: string;
  // Whether the parent Avance is hidden from EPG (ghost-with-weight mode).
  avanceHidden?: boolean;
  // ID of the specific AvanceClip currently being played (for per-clip "now playing").
  avanceClipId?: string;
  // Display title for this segment in "Viéndolo Ahora" — when avanceHidden, this
  // is the individual clip title (per PO's suggestion).
  displayTitle?: string;
  // ---- Avance fade in/out ----
  // True only on the FIRST clip of an Avance with fadeEnabled=true.
  // The viewer applies a video/audio fade-in for fadeInMs starting at startMs.
  avanceFadeIn?: { ms: number };
  // True only on the LAST clip of an Avance with fadeEnabled=true.
  // The viewer applies a video/audio fade-out for fadeOutMs ending at endMs.
  avanceFadeOut?: { ms: number };
}

// A program as shown in the EPG (ad breaks are hidden/folded into the program window).
export interface EpgEntry {
  slotId: string;
  assetId: string;
  title: string;
  thumbnailUrl: string | null;
  category: AssetCategory;
  startMs: number; // ms from midnight
  endMs: number;   // ms from midnight (includes ad break durations = wallclock)
  description: string | null;
  isFiller: boolean;
  // ---- Avance flags (visible Avance shows up like a normal program) ----
  isAvance?: boolean;
  avanceId?: string;
  avanceColor?: string;
}

export interface PlayoutState {
  now: string; // ISO server time
  date: string; // YYYY-MM-DD Venezuela
  elapsedMs: number; // ms since midnight Venezuela
  currentSegment: PlayoutSegment | null;
  currentEpgEntry: EpgEntry | null;
  nextEpgEntry: EpgEntry | null;
  segments: PlayoutSegment[]; // full day timeline
  epg: EpgEntry[]; // viewer-visible EPG (no ad breaks)
  slate: { message: string; secondsLeft: number } | null;
}

// ---- Telemetry types (ad-investor analytics) ----

export type TelemetryEventType =
  | "ad_view_start" // first frame of an ad played
  | "ad_impression" // ad reached the 2s viewable threshold (IAB)
  | "ad_complete" // ad watched to the end
  | "ad_skip" // viewer left before the ad finished
  | "program_view"; // program heartbeat

export interface TelemetryEvent {
  eventType: TelemetryEventType;
  sessionId: string;
  assetId: string;
  adBreakId?: string | null;
  slotId?: string | null;
  date: string;
  positionMs: number;
  durationMs: number;
}

// Aggregated analytics for the dashboard (ad-investor KPIs).
export interface AdAnalytics {
  date: string;
  // Top-level KPIs
  totalImpressions: number;
  totalCompletes: number;
  completionRate: number; // completes / impressions * 100
  totalSkips: number;
  fillRate: number; // scheduled ad slots that actually aired * 100
  estimatedRevenue: number; // mock CPM-based
  // Per-spot breakdown
  bySpot: Array<{
    assetId: string;
    title: string;
    impressions: number;
    completes: number;
    completionRate: number;
    estimatedRevenue: number;
  }>;
  // Per-ad-break breakdown
  byAdBreak: Array<{
    adBreakId: string;
    name: string;
    impressions: number;
    completes: number;
    fillRate: number;
  }>;
  // Hourly impressions (24 buckets)
  byHour: number[];
}
