// In-memory transcode job queue.
// Tracks the progress of each asset transcoding job.
// Jobs are also persisted in the Asset table (transcodeStatus, transcodeProgress) so they
// survive server restarts. This in-memory map is just for faster polling.

import { db } from "@/lib/db";
import { transcodeToHLS } from "@/lib/ffmpeg";
import { getAssetDir, getOriginalsDir, absoluteToRelative } from "@/lib/media-storage";
import path from "path";

export interface TranscodeJob {
  assetId: string;
  status: "pending" | "processing" | "completed" | "failed";
  progress: number; // 0-100
  error?: string;
  startedAt: number;
  completedAt?: number;
}

// In-memory job registry.
const jobs = new Map<string, TranscodeJob>();

// Get the current status of a job (from memory, falling back to DB).
export async function getJobStatus(assetId: string): Promise<TranscodeJob> {
  const memJob = jobs.get(assetId);
  if (memJob) return memJob;

  // Fall back to DB.
  const asset = await db.asset.findUnique({ where: { id: assetId } });
  if (!asset) {
    return {
      assetId,
      status: "failed",
      progress: 0,
      error: "Asset not found",
      startedAt: Date.now(),
    };
  }
  return {
    assetId,
    status: asset.transcodeStatus as TranscodeJob["status"],
    progress: asset.transcodeProgress,
    error: asset.transcodeError ?? undefined,
    startedAt: Date.now(),
    completedAt: asset.transcodeStatus === "completed" ? Date.now() : undefined,
  };
}

// Start a transcoding job for an asset.
// The job runs in the background and updates the DB + in-memory map as it progresses.
export function startTranscodeJob(
  assetId: string,
  originalFilePath: string
): void {
  // Don't start if already running.
  const existing = jobs.get(assetId);
  if (existing && existing.status === "processing") return;

  const job: TranscodeJob = {
    assetId,
    status: "processing",
    progress: 0,
    startedAt: Date.now(),
  };
  jobs.set(assetId, job);

  // Run the job asynchronously.
  (async () => {
    try {
      // Resolve the original file path.
      // originalFilePath is relative to the storage directory.
      const originalsDir = await getOriginalsDir();
      const inputPath = path.isAbsolute(originalFilePath)
        ? originalFilePath
        : path.join(originalsDir, originalFilePath);

      const assetDir = await getAssetDir(assetId);

      // Update DB: processing, 0%.
      await db.asset.update({
        where: { id: assetId },
        data: {
          transcodeStatus: "processing",
          transcodeProgress: 0,
          transcodeError: null,
        },
      });

      // Run the transcode.
      const result = await transcodeToHLS(inputPath, assetDir, async (pct) => {
        job.progress = pct;
        jobs.set(assetId, job);
        // Update DB progress (throttled — every 5%).
        if (pct % 5 === 0 || pct >= 100) {
          try {
            await db.asset.update({
              where: { id: assetId },
              data: { transcodeProgress: pct },
            });
          } catch {
            // ignore DB errors during progress updates
          }
        }
      });

      // Compute URLs for the HLS master + thumbnail.
      const masterRel = await absoluteToRelative(result.masterPlaylistPath);
      const thumbRel = await absoluteToRelative(result.thumbnailPath);
      const hlsUrl = `/api/media/${masterRel}`;
      const thumbnailUrl = `/api/media/${thumbRel}`;

      // Update the asset with final results.
      await db.asset.update({
        where: { id: assetId },
        data: {
          durationMs: result.durationMs,
          hlsUrl,
          thumbnailUrl,
          resolutionVariants: result.variants.map((v) => v.label).join(","),
          transcodeStatus: "completed",
          transcodeProgress: 100,
          transcodeError: null,
          originalFilePath,
        },
      });

      job.status = "completed";
      job.progress = 100;
      job.completedAt = Date.now();
      jobs.set(assetId, job);
    } catch (e) {
      const errorMsg = e instanceof Error ? e.message : "unknown error";
      job.status = "failed";
      job.error = errorMsg;
      job.completedAt = Date.now();
      jobs.set(assetId, job);

      try {
        await db.asset.update({
          where: { id: assetId },
          data: {
            transcodeStatus: "failed",
            transcodeError: errorMsg,
          },
        });
      } catch {
        // ignore
      }
    }
  })();
}

// Retry a failed job.
export async function retryTranscodeJob(assetId: string): Promise<void> {
  const asset = await db.asset.findUnique({ where: { id: assetId } });
  if (!asset) throw new Error("Asset not found");
  if (!asset.originalFilePath) throw new Error("No original file path for this asset");
  if (asset.transcodeStatus === "processing") throw new Error("Job already running");

  startTranscodeJob(assetId, asset.originalFilePath);
}
