// Avance rendering — produces a single MP4 from an Avance's clips using ffmpeg.
//
// Pipeline:
//   1. Load the Avance with all its clips (ordered by orderIndex).
//   2. For each clip, resolve the source MP4 file path from the asset's originalFilename.
//   3. Build an ffmpeg command that:
//      - Trims each clip to its [inMs, outMs] range (-ss/-to per input).
//      - Concatenates all trimmed clips into one stream (filter_complex concat).
//      - Applies video fade-in to the first clip + fade-out to the last clip.
//      - Applies audio afade-in/out similarly.
//   4. Output a single MP4 (H.264 + AAC) to /uploads/renders/avance_{id}_{date}.mp4.
//   5. Update the RenderedAvance record with status/progress/fileSize/duration.
//
// The render runs as a child process; progress is reported via ffmpeg's stderr
// parsing (frame=X / time=YY:YY). The caller can poll the DB for status.

import { db } from "@/lib/db";
import { promises as fs } from "fs";
import path from "path";
import { spawn } from "child_process";
import { getMediaStoragePath } from "@/lib/media-storage";
import type { Avance, AvanceClip } from "@/lib/types";

// Default video encoding settings for renders.
// We use CRF 23 (good quality, reasonable size) with the "fast" preset
// for a good balance of speed vs. compression.
const VIDEO_CODEC = "libx264";
const VIDEO_PRESET = "fast";
const VIDEO_CRF = "23";
const AUDIO_CODEC = "aac";
const AUDIO_BITRATE = "128k";

// Grace period: renders expire 6 hours after the broadcast day ends.
// This gives a buffer for replays or late-night viewing.
const EXPIRY_GRACE_HOURS = 6;

export interface RenderResult {
  ok: boolean;
  filePath?: string;
  durationMs?: number;
  fileSizeBytes?: number;
  error?: string;
}

// Resolve the absolute path of an asset's source MP4 file.
// Priority:
//   1. asset.originalFilePath (if set, relative to /uploads/)
//   2. asset.originalFilename (in /uploads/originals/)
//   3. Fallback: derive from hlsUrl (the assetId dir contains the HLS, but
//      we need the original MP4 — if not found, return null).
async function resolveSourcePath(
  asset: { originalFilePath: string | null; originalFilename: string }
): Promise<string | null> {
  const base = await getMediaStoragePath();

  // 1. Try originalFilePath (relative to /uploads/).
  if (asset.originalFilePath) {
    const p = path.isAbsolute(asset.originalFilePath)
      ? asset.originalFilePath
      : path.resolve(base, asset.originalFilePath);
    try {
      await fs.access(p);
      return p;
    } catch {
      // Fall through to try originalFilename.
    }
  }

  // 2. Try originalFilename in /uploads/originals/.
  const byName = path.join(base, "originals", asset.originalFilename);
  try {
    await fs.access(byName);
    return byName;
  } catch {
    // Fall through.
  }

  // 3. Not found.
  return null;
}

// Compute the total duration of an Avance (sum of clip cuts).
function computeTotalDurationMs(clips: AvanceClip[]): number {
  let total = 0;
  for (const clip of clips) {
    const assetDur = Math.max(clip.asset.durationMs, 1);
    const inMs = Math.max(0, Math.min(clip.inMs, assetDur - 1));
    const outMs = Math.max(inMs + 1, Math.min(clip.outMs > 0 ? clip.outMs : assetDur, assetDur));
    total += outMs - inMs;
  }
  return total;
}

// Compute the expiration date for a render.
// The render expires at the end of the broadcast day (23:59:59) + grace period.
export function computeExpiry(date: string): Date {
  // date is YYYY-MM-DD. Parse as UTC midnight to avoid tz issues.
  const [y, m, d] = date.split("-").map(Number);
  const startOfNextDay = new Date(Date.UTC(y, m - 1, d + 1));
  return new Date(startOfNextDay.getTime() + EXPIRY_GRACE_HOURS * 3600 * 1000);
}

// Parse ffmpeg's progress output to extract the current time position.
// ffmpeg writes lines like "frame=  123 fps= 45 q=23.0 size=    128kB time=00:00:05.12 ..."
// to stderr. We parse the "time=HH:MM:SS.ss" field and convert to a 0-100 progress.
function parseFfmpegProgress(line: string, totalDurationSec: number): number | null {
  const match = line.match(/time=(\d{2}):(\d{2}):(\d{2}\.\d{2})/);
  if (!match) return null;
  const h = parseInt(match[1], 10);
  const m = parseInt(match[2], 10);
  const s = parseFloat(match[3]);
  const elapsedSec = h * 3600 + m * 60 + s;
  if (totalDurationSec <= 0) return null;
  return Math.min(99, Math.max(0, Math.round((elapsedSec / totalDurationSec) * 100)));
}

// Main render function.
// Renders the given Avance to a single MP4 file and updates the RenderedAvance record.
//
// This function is long-running (10s-2min depending on Avance length).
// It should be called from an API route that does NOT await it — instead,
// the API creates a "pending" record, kicks off this function in the background,
// and returns immediately. The client polls for status.
export async function renderAvanceToMp4(
  renderId: string
): Promise<RenderResult> {
  const render = await db.renderedAvance.findUnique({
    where: { id: renderId },
    include: {
      avance: {
        include: {
          clips: {
            orderBy: { orderIndex: "asc" },
            include: { asset: true },
          },
        },
      },
    },
  });

  if (!render) {
    return { ok: false, error: "Render record not found" };
  }

  const avance = render.avance as unknown as Avance;
  if (!avance || avance.clips.length === 0) {
    await db.renderedAvance.update({
      where: { id: renderId },
      data: { status: "failed", error: "El Avance no tiene clips" },
    });
    return { ok: false, error: "El Avance no tiene clips" };
  }

  // Mark as rendering.
  await db.renderedAvance.update({
    where: { id: renderId },
    data: { status: "rendering", progress: 0, error: null },
  });

  try {
    // Ensure the renders directory exists.
    const base = await getMediaStoragePath();
    const rendersDir = path.join(base, "renders");
    await fs.mkdir(rendersDir, { recursive: true });

    // Resolve source paths for all clips.
    // Skip clips with duration < 100ms (they're too short to produce a valid frame
    // and would cause ffmpeg to fail with "Nothing was written into output file").
    const MIN_CLIP_DURATION_MS = 100;
    const clipSources: Array<{ clip: AvanceClip; srcPath: string; inMs: number; outMs: number }> = [];
    for (const clip of avance.clips) {
      const srcPath = await resolveSourcePath(clip.asset);
      if (!srcPath) {
        throw new Error(
          `No se encontró el archivo fuente para el clip "${clip.asset.title}" ` +
          `(originalFilename: ${clip.asset.originalFilename}). ` +
          `Sube el archivo original o regenera el HLS desde Medios (MAM).`
        );
      }
      const assetDur = Math.max(clip.asset.durationMs, 1);
      const inMs = Math.max(0, Math.min(clip.inMs, assetDur - 1));
      const outMs = Math.max(inMs + 1, Math.min(clip.outMs > 0 ? clip.outMs : assetDur, assetDur));
      const clipDur = outMs - inMs;
      if (clipDur < MIN_CLIP_DURATION_MS) {
        // Skip this clip — it's too short to render.
        console.warn(`[render] Skipping clip "${clip.asset.title}" — duration ${clipDur}ms < ${MIN_CLIP_DURATION_MS}ms minimum`);
        continue;
      }
      clipSources.push({ clip, srcPath, inMs, outMs });
    }

    if (clipSources.length === 0) {
      throw new Error(
        "Todos los clips del Avance son demasiado cortos (<100ms) o no tienen archivo fuente. " +
        "Edita el Avance y agrega clips válidos."
      );
    }

    const totalDurationMs = computeTotalDurationMs(avance.clips);
    const totalDurationSec = totalDurationMs / 1000;

    // Build the ffmpeg arguments.
    // For each clip: -ss <inMs/1000> -to <outMs/1000> -i <srcPath>
    // Note: -ss before -i is faster (seeks before decoding); -to after -i is
    // an output option but we use it as input option here for per-input trim.
    const inputArgs: string[] = [];
    for (const cs of clipSources) {
      inputArgs.push(
        "-ss", (cs.inMs / 1000).toString(),
        "-to", (cs.outMs / 1000).toString(),
        "-i", cs.srcPath
      );
    }

    // Build the filter_complex string.
    // 1. Normalize each clip's video to a common resolution (the first clip's
    //    resolution, or 1280x720 if unknown). This is REQUIRED because ffmpeg's
    //    concat filter fails if inputs have different resolutions.
    //    We use scale=WIDTH:HEIGHT:force_original_aspect_ratio=decrease,pad=WIDTH:HEIGHT
    //    to letterbox clips that have a different aspect ratio.
    // 2. Concatenate all normalized clips: [0v][0a][1v][1a]...concat=n=N:v=1:a=1[vcat][acat]
    // 3. Apply fade in/out on the concatenated stream.

    // Determine the target resolution: use the first clip's asset dimensions.
    // Default to 1280x720 if we can't determine (probe would be ideal but
    // we don't have the dimensions in the Asset model — they're in the HLS).
    // For now, we use a fixed 1280x720 target which works for all standard content.
    const TARGET_WIDTH = 1280;
    const TARGET_HEIGHT = 720;

    // Per-clip scale+pad filters to normalize resolution before concat.
    const scaleFilters = clipSources.map((_, i) => {
      const s = `scale=${TARGET_WIDTH}:${TARGET_HEIGHT}:force_original_aspect_ratio=decrease,pad=${TARGET_WIDTH}:${TARGET_HEIGHT}:(ow-iw)/2:(oh-ih)/2,setsar=1,format=yuv420p`;
      return `[${i}:v]${s}[v${i}];[${i}:a]anull[a${i}]`;
    });

    // Concat all normalized clips.
    const concatInputs = clipSources.map((_, i) => `[v${i}][a${i}]`).join("");
    const n = clipSources.length;
    const fadeInSecs = avance.fadeEnabled ? avance.fadeInMs / 1000 : 0;
    const fadeOutSecs = avance.fadeEnabled ? avance.fadeOutMs / 1000 : 0;
    const fadeOutStartSec = Math.max(0, totalDurationSec - fadeOutSecs);

    const filterParts: string[] = [
      ...scaleFilters,
      `${concatInputs}concat=n=${n}:v=1:a=1[vcat][acat]`,
    ];

    // Apply fade in/out.
    let videoFilter = "[vcat]copy[v]";
    let audioFilter = "[acat]anull[a]";

    if (avance.fadeEnabled) {
      const vFilters: string[] = [];
      const aFilters: string[] = [];
      if (fadeInSecs > 0) {
        vFilters.push(`fade=t=in:st=0:d=${fadeInSecs}`);
        aFilters.push(`afade=t=in:st=0:d=${fadeInSecs}`);
      }
      if (fadeOutSecs > 0) {
        vFilters.push(`fade=t=out:st=${fadeOutStartSec}:d=${fadeOutSecs}`);
        aFilters.push(`afade=t=out:st=${fadeOutStartSec}:d=${fadeOutSecs}`);
      }
      if (vFilters.length > 0) {
        videoFilter = `[vcat]${vFilters.join(",")}[v]`;
      }
      if (aFilters.length > 0) {
        audioFilter = `[acat]${aFilters.join(",")}[a]`;
      }
    }
    filterParts.push(videoFilter);
    filterParts.push(audioFilter);
    const filterComplex = filterParts.join(";");

    // Output file path.
    const outputFileName = `avance_${avance.id}_${render.date}.mp4`;
    const outputPath = path.join(rendersDir, outputFileName);
    const relativePath = `renders/${outputFileName}`;

    // Build the full ffmpeg command.
    const ffmpegArgs = [
      "-nostdin",  // don't read stdin (prevents the "p-eating" bug)
      "-y",        // overwrite output
      ...inputArgs,
      "-filter_complex", filterComplex,
      "-map", "[v]",
      "-map", "[a]",
      "-c:v", VIDEO_CODEC,
      "-preset", VIDEO_PRESET,
      "-crf", VIDEO_CRF,
      "-pix_fmt", "yuv420p",  // wide compatibility
      "-c:a", AUDIO_CODEC,
      "-b:a", AUDIO_BITRATE,
      "-ar", "48000",
      "-ac", "2",
      "-movflags", "+faststart",  // web-optimized MP4
      outputPath,
    ];

    // Run ffmpeg as a child process.
    await new Promise<void>((resolve, reject) => {
      const proc = spawn("ffmpeg", ffmpegArgs, { stdio: ["ignore", "pipe", "pipe"] });
      let stderrBuffer = "";

      // Parse stderr for progress updates.
      proc.stderr?.on("data", async (chunk: Buffer) => {
        const text = chunk.toString();
        stderrBuffer += text;
        const progress = parseFfmpegProgress(text, totalDurationSec);
        if (progress !== null) {
          // Update progress in DB (throttle to avoid spamming).
          // Only update if the change is >= 2%.
          try {
            const current = await db.renderedAvance.findUnique({
              where: { id: renderId },
              select: { progress: true },
            });
            if (current && progress > current.progress + 1) {
              await db.renderedAvance.update({
                where: { id: renderId },
                data: { progress },
              });
            }
          } catch {
            // Ignore DB errors during progress updates.
          }
        }
      });

      proc.on("error", (err) => {
        reject(new Error(`Failed to spawn ffmpeg: ${err.message}`));
      });

      proc.on("close", (code) => {
        if (code === 0) {
          resolve();
        } else {
          // Extract the last few lines of stderr for the error message.
          const lastLines = stderrBuffer.split("\n").slice(-10).join("\n");
          reject(new Error(`ffmpeg exited with code ${code}\n${lastLines}`));
        }
      });
    });

    // Verify the output file exists and get its size.
    const stat = await fs.stat(outputPath);

    // Update the render record to completed.
    await db.renderedAvance.update({
      where: { id: renderId },
      data: {
        status: "completed",
        progress: 100,
        filePath: relativePath,
        fileSizeBytes: stat.size,
        durationMs: totalDurationMs,
      },
    });

    return {
      ok: true,
      filePath: relativePath,
      durationMs: totalDurationMs,
      fileSizeBytes: stat.size,
    };
  } catch (e) {
    const errorMsg = e instanceof Error ? e.message : String(e);
    await db.renderedAvance.update({
      where: { id: renderId },
      data: { status: "failed", error: errorMsg },
    });
    return { ok: false, error: errorMsg };
  }
}

// Delete expired renders (file + DB record).
// Called by the cleanup cron.
export async function cleanupExpiredRenders(): Promise<{ deleted: number; errors: number }> {
  const now = new Date();
  const expired = await db.renderedAvance.findMany({
    where: { expiresAt: { lt: now } },
  });

  let deleted = 0;
  let errors = 0;

  for (const render of expired) {
    try {
      // Delete the file.
      if (render.filePath) {
        const base = await getMediaStoragePath();
        const absPath = path.join(base, render.filePath);
        try {
          await fs.unlink(absPath);
        } catch {
          // File may already be gone — not an error.
        }
      }
      // Delete the DB record.
      await db.renderedAvance.delete({ where: { id: render.id } });
      deleted++;
    } catch {
      errors++;
    }
  }

  return { deleted, errors };
}

// Mark all renders of an Avance as stale (when the Avance is edited).
// Stale renders are not used by the playout engine and will be cleaned up
// by the cleanup cron (they expire normally) or can be manually re-rendered.
export async function invalidateRendersForAvance(avanceId: string): Promise<number> {
  const result = await db.renderedAvance.updateMany({
    where: { avanceId, status: { in: ["completed", "pending", "rendering"] } },
    data: { status: "stale" },
  });
  return result.count;
}

// Find a completed, non-expired render for an Avance on a given date.
// Used by the playout engine to decide whether to use the render or fall back to clips.
export async function findUsableRender(
  avanceId: string,
  date: string
): Promise<{ id: string; filePath: string; durationMs: number } | null> {
  const render = await db.renderedAvance.findFirst({
    where: {
      avanceId,
      date,
      status: "completed",
      expiresAt: { gt: new Date() },
    },
    orderBy: { createdAt: "desc" },
    select: { id: true, filePath: true, durationMs: true },
  });
  return render;
}
