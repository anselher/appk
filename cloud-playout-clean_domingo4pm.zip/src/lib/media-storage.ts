// Media storage path management.
// The storage directory is configurable via ChannelSetting "mediaStoragePath".
// Default: ./uploads (relative to project root).
// Can be an absolute path (e.g. /var/videos or C:\videos) or relative to the project.

import { promises as fs } from "fs";
import path from "path";
import { db } from "@/lib/db";

const DEFAULT_STORAGE_PATH = "./uploads";

// Project root (where package.json lives). In Next.js, process.cwd() is the project root.
const PROJECT_ROOT = process.cwd();

// Resolve a storage path (absolute or relative) to an absolute filesystem path.
function resolveAbsolutePath(storagePath: string): string {
  if (path.isAbsolute(storagePath)) {
    return storagePath;
  }
  return path.resolve(PROJECT_ROOT, storagePath);
}

// Get the configured media storage path (from DB, with fallback to default).
export async function getMediaStoragePath(): Promise<string> {
  const row = await db.channelSetting.findUnique({ where: { key: "mediaStoragePath" } });
  const configured = row?.value?.trim() || DEFAULT_STORAGE_PATH;
  return resolveAbsolutePath(configured);
}

// Get the raw configured value (for display in admin settings).
export async function getConfiguredStoragePath(): Promise<string> {
  const row = await db.channelSetting.findUnique({ where: { key: "mediaStoragePath" } });
  return row?.value?.trim() || DEFAULT_STORAGE_PATH;
}

// Set the media storage path.
export async function setMediaStoragePath(p: string): Promise<void> {
  await db.channelSetting.upsert({
    where: { key: "mediaStoragePath" },
    update: { value: p },
    create: { key: "mediaStoragePath", value: p },
  });
}

// Ensure the storage directory exists (and subdirectories).
export async function ensureStorageDirs(): Promise<string> {
  const base = await getMediaStoragePath();
  await fs.mkdir(base, { recursive: true });
  await fs.mkdir(path.join(base, "originals"), { recursive: true });
  await fs.mkdir(path.join(base, "assets"), { recursive: true });
  return base;
}

// Get the absolute path for an asset's HLS output directory.
export async function getAssetDir(assetId: string): Promise<string> {
  const base = await ensureStorageDirs();
  const dir = path.join(base, "assets", assetId);
  await fs.mkdir(dir, { recursive: true });
  return dir;
}

// Get the absolute path for an original uploaded file.
export async function getOriginalsDir(): Promise<string> {
  const base = await ensureStorageDirs();
  return path.join(base, "originals");
}

// Convert an absolute filesystem path inside the storage to a URL path for /api/media/...
// E.g. /home/z/my-project/uploads/assets/c123/master.m3u8 → assets/c123/master.m3u8
export async function absoluteToRelative(absPath: string): Promise<string> {
  const base = await getMediaStoragePath();
  const rel = path.relative(base, absPath);
  // Normalize to forward slashes for URLs.
  return rel.split(path.sep).join("/");
}

// Check if a path is inside the storage directory (security check for the media-serving route).
export async function isInsideStorage(absPath: string): Promise<boolean> {
  const base = await getMediaStoragePath();
  const resolved = path.resolve(absPath);
  const rel = path.relative(base, resolved);
  return rel !== "" && !rel.startsWith("..") && !path.isAbsolute(rel);
}
