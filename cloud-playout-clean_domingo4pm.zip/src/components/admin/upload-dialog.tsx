"use client";

import { useState, useCallback, useRef, useEffect } from "react";
import { Upload, Link2, FileVideo, X, CheckCircle, AlertCircle, Loader2 } from "lucide-react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import type { AssetCategory } from "@/lib/types";

interface UploadDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onCompleted: () => void;
}

type UploadMode = "file" | "url";
type JobPhase = "idle" | "uploading" | "processing" | "completed" | "failed";

interface JobStatus {
  assetId: string;
  phase: JobPhase;
  progress: number;
  error?: string;
  title: string;
  hlsUrl?: string;
  thumbnailUrl?: string;
}

export function UploadDialog({ open, onOpenChange, onCompleted }: UploadDialogProps) {
  const { toast } = useToast();
  const [mode, setMode] = useState<UploadMode>("file");
  const [title, setTitle] = useState("");
  const [category, setCategory] = useState<AssetCategory>("PROGRAM");
  const [description, setDescription] = useState("");
  const [url, setUrl] = useState("");
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [dragOver, setDragOver] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [jobs, setJobs] = useState<JobStatus[]>([]);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const pollingRef = useRef<Map<string, ReturnType<typeof setInterval>>>(new Map());

  // Reset form when dialog closes.
  const handleClose = useCallback((open: boolean) => {
    if (!open) {
      setTitle("");
      setCategory("PROGRAM");
      setDescription("");
      setUrl("");
      setSelectedFile(null);
      setJobs([]);
      // Stop all polling.
      pollingRef.current.forEach((interval) => clearInterval(interval));
      pollingRef.current.clear();
    }
    onOpenChange(open);
  }, [onOpenChange]);

  // Handle file selection.
  const handleFileSelect = useCallback((file: File | null) => {
    if (!file) return;
    setSelectedFile(file);
    // Auto-fill title from filename if empty.
    if (!title) {
      const name = file.name.replace(/\.[^/.]+$/, "");
      setTitle(name);
    }
  }, [title]);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
    const file = e.dataTransfer.files[0];
    if (file) handleFileSelect(file);
  }, [handleFileSelect]);

  // Submit upload.
  const submitUpload = async () => {
    if (!title.trim()) {
      toast({ title: "El título es obligatorio", variant: "destructive" });
      return;
    }

    setUploading(true);
    try {
      let response: Response;
      if (mode === "file") {
        if (!selectedFile) {
          toast({ title: "Selecciona un archivo", variant: "destructive" });
          setUploading(false);
          return;
        }
        const formData = new FormData();
        formData.append("file", selectedFile);
        formData.append("title", title);
        formData.append("category", category);
        if (description) formData.append("description", description);

        response = await fetch("/api/assets/upload", {
          method: "POST",
          body: formData,
        });
      } else {
        if (!url.trim()) {
          toast({ title: "Introduce una URL", variant: "destructive" });
          setUploading(false);
          return;
        }
        response = await fetch("/api/assets/import-url", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ url, title, category, description }),
        });
      }

      const result = await response.json();
      if (!response.ok) {
        throw new Error(result.error || "Upload failed");
      }

      // Add job to tracking list.
      const newJob: JobStatus = {
        assetId: result.id,
        phase: "processing",
        progress: 0,
        title,
      };
      setJobs((prev) => [...prev, newJob]);

      // Start polling for status.
      const interval = setInterval(async () => {
        try {
          const statusResp = await fetch(`/api/assets/${result.id}/status`);
          const status = await statusResp.json();
          setJobs((prev) =>
            prev.map((j) =>
              j.assetId === result.id
                ? {
                    ...j,
                    phase: status.status === "completed" ? "completed" : status.status === "failed" ? "failed" : "processing",
                    progress: status.progress,
                    error: status.error,
                    hlsUrl: status.hlsUrl,
                    thumbnailUrl: status.thumbnailUrl,
                  }
                : j
            )
          );

          if (status.status === "completed" || status.status === "failed") {
            const pollInterval = pollingRef.current.get(result.id);
            if (pollInterval) {
              clearInterval(pollInterval);
              pollingRef.current.delete(result.id);
            }
            if (status.status === "completed") {
              toast({
                title: "Transcodificación completa",
                description: `"${title}" está listo para programar.`,
              });
              onCompleted();
            } else {
              toast({
                title: "Error de transcodificación",
                description: status.error || "Error desconocido",
                variant: "destructive",
              });
            }
          }
        } catch {
          // ignore polling errors
        }
      }, 2000);
      pollingRef.current.set(result.id, interval);

      // Clear form for next upload.
      setTitle("");
      setDescription("");
      setUrl("");
      setSelectedFile(null);
      toast({
        title: "Subida iniciada",
        description: "La transcodificación ABR HLS está en progreso…",
      });
    } catch (e) {
      toast({
        title: "Error al subir",
        description: e instanceof Error ? e.message : "internal error",
        variant: "destructive",
      });
    } finally {
      setUploading(false);
    }
  };

  // Retry a failed job.
  const retryJob = async (assetId: string) => {
    try {
      await fetch(`/api/assets/${assetId}/status`, { method: "POST" });
      setJobs((prev) =>
        prev.map((j) =>
          j.assetId === assetId ? { ...j, phase: "processing", progress: 0, error: undefined } : j
        )
      );
      // Restart polling.
      const interval = setInterval(async () => {
        try {
          const statusResp = await fetch(`/api/assets/${assetId}/status`);
          const status = await statusResp.json();
          setJobs((prev) =>
            prev.map((j) =>
              j.assetId === assetId
                ? {
                    ...j,
                    phase: status.status === "completed" ? "completed" : status.status === "failed" ? "failed" : "processing",
                    progress: status.progress,
                    error: status.error,
                  }
                : j
            )
          );
          if (status.status === "completed" || status.status === "failed") {
            const pollInterval = pollingRef.current.get(assetId);
            if (pollInterval) {
              clearInterval(pollInterval);
              pollingRef.current.delete(assetId);
            }
            if (status.status === "completed") {
              onCompleted();
            }
          }
        } catch {
          // ignore
        }
      }, 2000);
      pollingRef.current.set(assetId, interval);
    } catch {
      toast({ title: "Error al reintentar", variant: "destructive" });
    }
  };

  // Cleanup on unmount.
  useEffect(() => {
    return () => {
      pollingRef.current.forEach((interval) => clearInterval(interval));
      pollingRef.current.clear();
    };
  }, []);

  const allDone = jobs.length > 0 && jobs.every((j) => j.phase === "completed" || j.phase === "failed");

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="max-h-[90vh] gap-0 overflow-y-auto custom-scrollbar border-zinc-800 bg-zinc-900 p-0 sm:max-w-2xl">
        <DialogHeader className="border-b border-zinc-800 px-5 py-4">
          <DialogTitle className="text-base text-zinc-100">
            Subir nuevo contenido
          </DialogTitle>
          <DialogDescription className="text-xs text-zinc-500">
            Los videos se transcodifican automáticamente a ABR HLS (adaptativo, sin
            upscaling) y se genera una miniatura automática.
          </DialogDescription>
        </DialogHeader>

        <div className="grid gap-4 px-5 py-4">
          {/* Mode tabs */}
          <Tabs value={mode} onValueChange={(v) => setMode(v as UploadMode)}>
            <TabsList className="h-9 bg-zinc-950">
              <TabsTrigger value="file" className="gap-1.5 text-xs">
                <Upload className="size-3.5" />
                Desde mi PC
              </TabsTrigger>
              <TabsTrigger value="url" className="gap-1.5 text-xs">
                <Link2 className="size-3.5" />
                Desde una URL
              </TabsTrigger>
            </TabsList>
          </Tabs>

          {/* File dropzone */}
          {mode === "file" && (
            <div
              onDragOver={(e) => { e.preventDefault(); setDragOver(true); }}
              onDragLeave={() => setDragOver(false)}
              onDrop={handleDrop}
              onClick={() => fileInputRef.current?.click()}
              className={cn(
                "flex cursor-pointer flex-col items-center justify-center gap-2 rounded-lg border-2 border-dashed px-4 py-8 transition-colors",
                dragOver
                  ? "border-amber-500 bg-amber-500/5"
                  : selectedFile
                  ? "border-emerald-600/50 bg-emerald-950/10"
                  : "border-zinc-700 bg-zinc-950/50 hover:border-zinc-600"
              )}
            >
              {selectedFile ? (
                <>
                  <FileVideo className="size-8 text-emerald-400" />
                  <div className="text-center">
                    <div className="text-sm font-medium text-emerald-300">{selectedFile.name}</div>
                    <div className="text-xs text-zinc-500">
                      {(selectedFile.size / (1024 * 1024)).toFixed(1)} MB
                    </div>
                  </div>
                  <button
                    onClick={(e) => { e.stopPropagation(); setSelectedFile(null); }}
                    className="mt-1 text-xs text-zinc-500 hover:text-rose-400"
                  >
                    Quitar archivo
                  </button>
                </>
              ) : (
                <>
                  <Upload className="size-8 text-zinc-600" />
                  <div className="text-center">
                    <div className="text-sm font-medium text-zinc-300">
                      Arrastra un video aquí o haz clic para seleccionar
                    </div>
                    <div className="mt-1 text-xs text-zinc-500">
                      Formatos: MP4, MOV, AVI, MKV, WebM
                    </div>
                  </div>
                </>
              )}
              <input
                ref={fileInputRef}
                type="file"
                accept="video/*"
                className="hidden"
                onChange={(e) => handleFileSelect(e.target.files?.[0] ?? null)}
              />
            </div>
          )}

          {/* URL input */}
          {mode === "url" && (
            <div className="grid gap-1.5">
              <Label className="text-xs text-zinc-400">URL del video</Label>
              <Input
                value={url}
                onChange={(e) => setUrl(e.target.value)}
                className="h-9 border-zinc-700 bg-zinc-950 text-sm text-zinc-100"
                placeholder="https://ejemplo.com/video.mp4"
              />
              <span className="text-[11px] text-zinc-500">
                El servidor descargará el archivo y lo transcodificará.
              </span>
            </div>
          )}

          {/* Metadata */}
          <div className="grid grid-cols-2 gap-3">
            <div className="grid gap-1.5">
              <Label className="text-xs text-zinc-400">Título *</Label>
              <Input
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                className="h-9 border-zinc-700 bg-zinc-950 text-sm text-zinc-100"
                placeholder="Ej: Noticiero Estelar"
              />
            </div>
            <div className="grid gap-1.5">
              <Label className="text-xs text-zinc-400">Categoría</Label>
              <Select value={category} onValueChange={(v) => setCategory(v as AssetCategory)}>
                <SelectTrigger className="h-9 border-zinc-700 bg-zinc-950 text-xs text-zinc-100">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="border-zinc-700 bg-zinc-900 text-zinc-100">
                  <SelectItem value="PROGRAM">Programa</SelectItem>
                  <SelectItem value="FILLER">Planta</SelectItem>
                  <SelectItem value="SPOT">Spot</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid gap-1.5">
            <Label className="text-xs text-zinc-400">Descripción (opcional)</Label>
            <Textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="min-h-[60px] border-zinc-700 bg-zinc-950 text-sm text-zinc-100"
              placeholder="Descripción del contenido…"
            />
          </div>

          {/* Active jobs */}
          {jobs.length > 0 && (
            <div className="space-y-2 rounded-lg border border-zinc-800 bg-zinc-950/50 p-3">
              <div className="text-[11px] font-medium uppercase tracking-wider text-zinc-500">
                Cola de transcodificación ({jobs.length})
              </div>
              {jobs.map((job) => (
                <div key={job.assetId} className="space-y-1.5">
                  <div className="flex items-center gap-2 text-xs">
                    {job.phase === "completed" && <CheckCircle className="size-4 text-emerald-400" />}
                    {job.phase === "failed" && <AlertCircle className="size-4 text-rose-400" />}
                    {job.phase === "processing" && <Loader2 className="size-4 animate-spin text-amber-400" />}
                    <span className="flex-1 truncate text-zinc-200">{job.title}</span>
                    <span className="font-mono tabular-nums text-zinc-500">
                      {job.phase === "completed" ? "100%" : `${job.progress}%`}
                    </span>
                  </div>
                  {job.phase === "processing" && (
                    <div className="h-1.5 overflow-hidden rounded-full bg-zinc-800">
                      <div
                        className="h-full bg-gradient-to-r from-amber-500 to-orange-500 transition-all duration-500"
                        style={{ width: `${job.progress}%` }}
                      />
                    </div>
                  )}
                  {job.phase === "failed" && (
                    <div className="flex items-center justify-between gap-2">
                      <span className="truncate text-[11px] text-rose-400">{job.error}</span>
                      <Button
                        size="sm"
                        variant="ghost"
                        className="h-6 px-2 text-[11px] text-amber-300 hover:bg-zinc-800"
                        onClick={() => retryJob(job.assetId)}
                      >
                        Reintentar
                      </Button>
                    </div>
                  )}
                  {job.phase === "completed" && job.thumbnailUrl && (
                    <div className="flex items-center gap-2">
                      <img
                        src={job.thumbnailUrl}
                        alt={job.title}
                        className="h-10 w-16 rounded object-cover"
                      />
                      <span className="text-[11px] text-emerald-300">
                        Listo para programar
                      </span>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>

        <DialogFooter className="border-t border-zinc-800 px-5 py-3">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => handleClose(false)}
            className="text-zinc-400 hover:bg-zinc-800 hover:text-zinc-100"
          >
            {allDone ? "Cerrar" : "Cancelar"}
          </Button>
          <Button
            size="sm"
            onClick={submitUpload}
            disabled={uploading || (!selectedFile && !url) || !title}
            className="gap-1.5 bg-amber-500 text-zinc-950 hover:bg-amber-400"
          >
            {uploading ? (
              <>
                <Loader2 className="size-3.5 animate-spin" />
                Subiendo…
              </>
            ) : (
              <>
                <Upload className="size-3.5" />
                Subir y transcodificar
              </>
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
