"use client";

import { useMemo, useState, useEffect, useCallback } from "react";
import {
  PieChart,
  Pie,
  Cell,
  ResponsiveContainer,
  Tooltip,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Legend,
} from "recharts";
import {
  Film,
  Layers,
  Megaphone,
  Clock,
  CalendarClock,
  ChevronRight,
  Users,
  TrendingUp,
  Activity,
  AlertTriangle,
  RefreshCw,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { useAsync, Thumbnail, msToWallclock, msToHHMM, msToHMMSS, Spinner } from "./shared";
import { useToast } from "@/hooks/use-toast";
import type { Asset, AdBreak, PlayoutState, PlayoutSegment, AdAnalytics } from "@/lib/types";

const DAY_MS = 24 * 3600 * 1000;

/**
 * Derive a realistic mock "concurrent viewers" count from the time-of-day.
 * Primetime (19:00–22:00) peaks ~1.6k; late-night trough ~80; a small
 * deterministic sinusoidal variation makes it feel live without random jumps.
 * Pure function of elapsedMs → no setState/effect needed (lint-clean).
 */
function computeMockViewers(elapsedMs: number): number {
  const hours = elapsedMs / 3_600_000; // 0..24
  // Smooth diurnal curve: peaks around 20.5h, trough around 4h.
  // Amplitude tuned to a small internet TV channel.
  const base = 820 + 760 * Math.sin(((hours - 4) / 24) * Math.PI * 2 - Math.PI / 2);
  // Small ±3% deterministic ripple from the minute component.
  const ripple = 1 + 0.03 * Math.sin(elapsedMs / 60_000);
  return Math.max(12, Math.round(base * ripple));
}

// Format a viewer count compactly (e.g. 1234 → "1.2k").
function formatViewers(n: number): string {
  if (n >= 1000) return `${(n / 1000).toFixed(1)}k`;
  return String(n);
}

function StatTile({
  icon: Icon,
  label,
  value,
  accent,
}: {
  icon: React.ComponentType<{ className?: string }>;
  label: string;
  value: string | number;
  accent: string;
}) {
  return (
    <Card className="group relative border-zinc-800 bg-zinc-900/60 p-3 transition-all duration-200 hover:border-zinc-700 hover:bg-zinc-900/90">
      {/* Subtle accent glow in the corner */}
      <div className={`pointer-events-none absolute -right-6 -top-6 size-16 rounded-full opacity-20 blur-2xl transition-opacity duration-300 group-hover:opacity-40 ${accent.replace('text-', 'bg-')}`} />
      <div className="relative flex items-center justify-between">
        <span className="text-[11px] font-medium uppercase tracking-wider text-zinc-500">
          {label}
        </span>
        <div className={`flex size-6 items-center justify-center rounded-md bg-zinc-800/70 ${accent}`}>
          <Icon className="size-3.5" />
        </div>
      </div>
      <div className="relative mt-2 font-mono text-2xl font-semibold tabular-nums text-zinc-100">
        {value}
      </div>
    </Card>
  );
}

// Horizontal strip of today's atomic segments, colored by kind, with a live
// position marker and a rich hover tooltip showing program details.
// Clicking a segment calls onJumpToSchedule (switches to the Programación view).
// Shows two rows: program labels (top) + colored segment strip (bottom).
function TimelineStrip({ segments, nowMs, onJumpToSchedule }: { segments: PlayoutSegment[]; nowMs: number; onJumpToSchedule?: () => void }) {
  const total = DAY_MS;
  const livePct = Math.min(100, Math.max(0, (nowMs / total) * 100));
  const [hovered, setHovered] = useState<number | null>(null);

  // Precompute each segment's left% + width% for tooltip positioning.
  const segMeta = segments.map((seg) => {
    const left = (seg.startMs / total) * 100;
    const width = ((seg.endMs - seg.startMs) / total) * 100;
    return { left, width, center: left + width / 2 };
  });

  const hoveredSeg = hovered !== null ? segments[hovered] : null;
  const hoveredMeta = hovered !== null ? segMeta[hovered] : null;
  // Clamp the tooltip center so it stays within the card edges.
  const tooltipLeft = hoveredMeta ? Math.max(12, Math.min(88, hoveredMeta.center)) : 0;

  const kindColor = (kind: string) =>
    kind === "program"
      ? "bg-amber-500"
      : kind === "ad"
        ? "bg-rose-500"
        : kind === "bumper"
          ? "bg-sky-500"
          : "bg-zinc-600";
  const kindLabel = (kind: string) =>
    kind === "program" ? "Programa" : kind === "ad" ? "Publicidad" : kind === "bumper" ? "Bumper" : "Planta";

  // Segments wide enough to show a label (>= 0.35% of the day ≈ 5min).
  // Shows program titles, "Tanda" for ad blocks, "Bumper" for bumpers.
  const labelableSegs = segments
    .map((seg, i) => ({ seg, i, meta: segMeta[i] }))
    .filter(({ meta, seg }) => meta.width >= 0.35 && (seg.kind === "program" || seg.kind === "ad" || seg.kind === "bumper"));

  return (
    <Card className="flex flex-col gap-2 border-zinc-800 bg-zinc-900/60 p-3">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span className="text-[11px] font-semibold uppercase tracking-wider text-zinc-300">
            Línea de tiempo de hoy
          </span>
          <span className="font-mono text-[10px] tabular-nums text-amber-400">
            {msToWallclock(nowMs)}
          </span>
        </div>
        <div className="flex flex-wrap items-center gap-2.5 text-[10px] text-zinc-400">
          <span className="flex items-center gap-1">
            <span className="size-2 rounded-sm bg-amber-500" /> Programa
          </span>
          <span className="flex items-center gap-1">
            <span className="size-2 rounded-sm bg-rose-500" /> Publicidad
          </span>
          <span className="flex items-center gap-1">
            <span className="size-2 rounded-sm bg-sky-500" /> Bumper
          </span>
          <span className="flex items-center gap-1">
            <span className="size-2 rounded-sm bg-zinc-600" /> Planta
          </span>
        </div>
      </div>

      {/* Strip wrapper (relative, not overflow-hidden) so the tooltip can overflow above */}
      <div className="relative">
        {/* Hover tooltip — appears above the strip */}
        {hoveredSeg && hoveredMeta && (
          <div
            className="pointer-events-none absolute bottom-full z-20 mb-1.5 -translate-x-1/2"
            style={{ left: `${tooltipLeft}%` }}
          >
            <div className="w-52 rounded-lg border border-zinc-700 bg-zinc-950/95 px-3 py-2 shadow-xl backdrop-blur">
              <div className="flex items-center gap-1.5">
                <span className={cn("size-2 shrink-0 rounded-sm", kindColor(hoveredSeg.kind))} />
                <span className="truncate text-xs font-semibold text-zinc-100">
                  {hoveredSeg.asset.title}
                </span>
              </div>
              <div className="mt-1 font-mono text-[10px] tabular-nums text-zinc-400">
                {msToWallclock(hoveredSeg.startMs)} – {msToWallclock(hoveredSeg.endMs)}
              </div>
              <div className="mt-0.5 flex items-center gap-2 text-[10px] text-zinc-500">
                <span>{msToHMMSS(hoveredSeg.endMs - hoveredSeg.startMs)}</span>
                <span className="text-zinc-700">·</span>
                <span>{kindLabel(hoveredSeg.kind)}</span>
                {/* Live badge if this segment is currently airing */}
                {nowMs >= hoveredSeg.startMs && nowMs < hoveredSeg.endMs && (
                  <span className="ml-auto flex items-center gap-0.5 rounded bg-rose-600/20 px-1 text-[8px] font-bold uppercase tracking-wider text-rose-300">
                    <span className="size-1 animate-pulse rounded-full bg-rose-400" />
                    En Vivo
                  </span>
                )}
              </div>
              {/* Click-to-jump hint */}
              {onJumpToSchedule && (
                <div className="mt-1.5 flex items-center gap-1 border-t border-zinc-800 pt-1.5 text-[9px] text-amber-400/80">
                  <svg className="size-2.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" aria-hidden>
                    <path d="M9 18l6-6-6-6" />
                  </svg>
                  Click para ir a Programación
                </div>
              )}
            </div>
          </div>
        )}

        {/* Program/ad/bumper labels row — shows titles above the strip for wide segments */}
        <div className="relative mb-0.5 h-4 w-full">
          {labelableSegs.map(({ seg, meta }) => (
            <div
              key={seg.assetId + seg.startMs}
              className={cn(
                "absolute truncate px-1 text-[9px] font-medium",
                seg.kind === "program" ? "text-amber-300/90"
                  : seg.kind === "ad" ? "text-rose-300/90"
                  : seg.kind === "bumper" ? "text-sky-300/90"
                  : "text-zinc-400"
              )}
              style={{ left: `${meta.left}%`, width: `${meta.width}%` }}
              title={seg.asset.title}
            >
              {seg.kind === "ad" ? "Tanda" : seg.kind === "bumper" ? "Bumper" : seg.asset.title}
            </div>
          ))}
        </div>

        {/* Colored segment strip — taller now (h-12) for better visibility */}
        <div className="relative h-12 w-full overflow-hidden rounded-md border border-zinc-800 bg-zinc-950">
          {segments.map((seg, i) => {
            const width = segMeta[i].width;
            if (width < 0.05) return null;
            const isHovered = hovered === i;
            const color =
              seg.kind === "program"
                ? "bg-amber-500/80 hover:bg-amber-400"
                : seg.kind === "ad"
                  ? "bg-rose-500/80 hover:bg-rose-400"
                  : seg.kind === "bumper"
                    ? "bg-sky-500/80 hover:bg-sky-400"
                    : "bg-zinc-600/80 hover:bg-zinc-500";
            return (
              <div
                key={i}
                className={cn(
                  "h-full shrink-0 cursor-pointer transition-all",
                  color,
                  isHovered && "brightness-125 ring-1 ring-inset ring-white/40"
                )}
                style={{ width: `${width}%` }}
                onMouseEnter={() => setHovered(i)}
                onMouseLeave={() => setHovered(null)}
                onClick={onJumpToSchedule}
              />
            );
          })}
          {/* Live position marker — tall white line with glow + triangle on top */}
          {livePct > 0 && livePct < 100 && (
            <div
              className="pointer-events-none absolute inset-y-0 z-10 flex flex-col items-center"
              style={{ left: `calc(${livePct}% - 1px)` }}
            >
              <div className="h-full w-0.5 bg-white shadow-[0_0_8px] shadow-white/70" />
            </div>
          )}
        </div>
      </div>

      {/* Hour labels */}
      <div className="relative flex justify-between font-mono text-[10px] tabular-nums text-zinc-500">
        <span>00:00</span>
        <span>06:00</span>
        <span>12:00</span>
        <span>18:00</span>
        <span>24:00</span>
        {/* Live time label below the strip */}
        {livePct > 2 && livePct < 98 && (
          <span
            className="absolute -bottom-5 rounded bg-white px-1.5 py-0.5 text-[9px] font-bold text-zinc-950 shadow"
            style={{ left: `calc(${livePct}% - 18px)` }}
          >
            {msToWallclock(nowMs)}
          </span>
        )}
      </div>
    </Card>
  );
}

// Pie chart: distribution of today's airtime by content kind (program / ad / bumper / filler).
function KindPieChart({ segments }: { segments: PlayoutSegment[] }) {
  const data = useMemo(() => {
    const acc: Record<string, number> = { program: 0, ad: 0, bumper: 0, filler: 0 };
    for (const s of segments) {
      const dur = s.endMs - s.startMs;
      acc[s.kind] = (acc[s.kind] ?? 0) + dur;
    }
    return [
      { name: "Programa", value: acc.program, color: "#f59e0b" },
      { name: "Publicidad", value: acc.ad, color: "#f43f5e" },
      { name: "Bumper", value: acc.bumper, color: "#0ea5e9" },
      { name: "Planta", value: acc.filler, color: "#71717a" },
    ].filter((d) => d.value > 0);
  }, [segments]);

  const totalHs = data.reduce((s, d) => s + d.value, 0) / 3600000;

  return (
    <Card className="flex flex-col gap-2 border-zinc-800 bg-zinc-900/60 p-3">
      <div className="flex items-center justify-between">
        <span className="text-[11px] font-medium uppercase tracking-wider text-zinc-500">
          Distribución de aire (hoy)
        </span>
        <span className="font-mono text-[10px] tabular-nums text-zinc-500">
          {totalHs.toFixed(1)}h total
        </span>
      </div>
      <div className="h-44">
        <ResponsiveContainer width="100%" height="100%">
          <PieChart>
            <Pie
              data={data}
              dataKey="value"
              nameKey="name"
              cx="50%"
              cy="50%"
              innerRadius={38}
              outerRadius={65}
              paddingAngle={2}
              stroke="#0a0a0a"
              strokeWidth={2}
            >
              {data.map((d, i) => (
                <Cell key={i} fill={d.color} />
              ))}
            </Pie>
            <Tooltip
              contentStyle={{
                backgroundColor: "#18181b",
                border: "1px solid #3f3f46",
                borderRadius: "8px",
                fontSize: "11px",
                color: "#e4e4e7",
              }}
              formatter={(value: number, name: string) => [
                `${(value / 3600000).toFixed(2)}h · ${((value / (totalHs * 3600000)) * 100).toFixed(1)}%`,
                name,
              ]}
            />
            <Legend
              iconType="circle"
              wrapperStyle={{ fontSize: "11px", color: "#a1a1aa" }}
            />
          </PieChart>
        </ResponsiveContainer>
      </div>
    </Card>
  );
}

// Bar chart: top programs by scheduled airtime today (top 6).
function TopProgramsChart({ segments }: { segments: PlayoutSegment[] }) {
  const data = useMemo(() => {
    const map = new Map<string, { name: string; program: number; ad: number }>();
    // Group ad segments by the most recent program slot.
    let lastProgramName = "";
    for (const s of segments) {
      const dur = (s.endMs - s.startMs) / 60000; // minutes
      if (s.kind === "program") {
        lastProgramName = s.asset.title;
        const entry = map.get(s.asset.id) ?? { name: s.asset.title, program: 0, ad: 0 };
        entry.program += dur;
        map.set(s.asset.id, entry);
      } else if (s.kind === "ad" && lastProgramName) {
        // Attribute ads to the most recent program.
        const entry = Array.from(map.values()).find((m) => m.name === lastProgramName);
        if (entry) entry.ad += dur;
      }
    }
    return Array.from(map.values())
      .sort((a, b) => (b.program + b.ad) - (a.program + a.ad))
      .slice(0, 6)
      .map((d) => ({
        ...d,
        name: d.name.length > 18 ? d.name.slice(0, 17) + "…" : d.name,
      }));
  }, [segments]);

  return (
    <Card className="flex flex-col gap-2 border-zinc-800 bg-zinc-900/60 p-3">
      <div className="flex items-center justify-between">
        <span className="text-[11px] font-medium uppercase tracking-wider text-zinc-500">
          Top programas hoy (minutos)
        </span>
        <div className="flex items-center gap-3 text-[10px] text-zinc-500">
          <span className="flex items-center gap-1">
            <span className="size-2 rounded-sm bg-amber-500" /> Programa
          </span>
          <span className="flex items-center gap-1">
            <span className="size-2 rounded-sm bg-rose-500" /> Publicidad
          </span>
        </div>
      </div>
      <div className="h-44">
        {data.length === 0 ? (
          <div className="flex h-full items-center justify-center text-xs text-zinc-600">
            Sin datos
          </div>
        ) : (
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={data} layout="vertical" margin={{ left: 8, right: 16, top: 4, bottom: 4 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#27272a" horizontal={false} />
              <XAxis
                type="number"
                tick={{ fill: "#71717a", fontSize: 10 }}
                axisLine={{ stroke: "#3f3f46" }}
                tickLine={false}
                unit="m"
              />
              <YAxis
                type="category"
                dataKey="name"
                tick={{ fill: "#a1a1aa", fontSize: 10 }}
                axisLine={{ stroke: "#3f3f46" }}
                tickLine={false}
                width={110}
              />
              <Tooltip
                cursor={{ fill: "#27272a" }}
                contentStyle={{
                  backgroundColor: "#18181b",
                  border: "1px solid #3f3f46",
                  borderRadius: "8px",
                  fontSize: "11px",
                  color: "#e4e4e7",
                }}
                formatter={(value: number, name: string) => [`${value.toFixed(1)} min`, name]}
              />
              <Bar dataKey="program" stackId="a" fill="#f59e0b" radius={[0, 0, 0, 0]} />
              <Bar dataKey="ad" stackId="a" fill="#f43f5e" radius={[0, 4, 4, 0]} />
            </BarChart>
          </ResponsiveContainer>
        )}
      </div>
    </Card>
  );
}

// Bar chart: top programs by estimated viewership (viewer-minutes), combining
// the schedule with the mock viewers curve. For each program segment, samples
// computeMockViewers across its time window to estimate total viewer-minutes.
function TopProgramsByViewersChart({ segments }: { segments: PlayoutSegment[] }) {
  const data = useMemo(() => {
    const map = new Map<string, { id: string; name: string; viewerMinutes: number; peak: number }>();
    for (const s of segments) {
      if (s.kind !== "program") continue;
      const durMs = s.endMs - s.startMs;
      if (durMs <= 0) continue;
      // Sample every ~60s across the segment window to estimate viewer-minutes.
      const stepMs = 60_000;
      let sumViewers = 0;
      let peak = 0;
      let samples = 0;
      for (let t = s.startMs; t < s.endMs; t += stepMs) {
        const v = computeMockViewers(t);
        sumViewers += v;
        if (v > peak) peak = v;
        samples++;
      }
      const avgViewers = samples > 0 ? sumViewers / samples : 0;
      const viewerMinutes = avgViewers * (durMs / 60_000);
      const existing = map.get(s.asset.id);
      if (existing) {
        existing.viewerMinutes += viewerMinutes;
        if (peak > existing.peak) existing.peak = peak;
      } else {
        map.set(s.asset.id, {
          id: s.asset.id,
          name: s.asset.title,
          viewerMinutes,
          peak,
        });
      }
    }
    return Array.from(map.values())
      .sort((a, b) => b.viewerMinutes - a.viewerMinutes)
      .slice(0, 6)
      .map((d) => ({
        ...d,
        name: d.name.length > 18 ? d.name.slice(0, 17) + "…" : d.name,
        // Convert to thousands of viewer-minutes for readable axis.
        kMin: Math.round(d.viewerMinutes / 100) / 10,
      }));
  }, [segments]);

  return (
    <Card className="flex flex-col gap-2 border-zinc-800 bg-zinc-900/60 p-3">
      <div className="flex items-center justify-between">
        <span className="text-[11px] font-medium uppercase tracking-wider text-zinc-500">
          Top programas por audiencia
        </span>
        <span className="font-mono text-[10px] tabular-nums text-zinc-500">
          mil viewer-min
        </span>
      </div>
      <div className="h-44">
        {data.length === 0 ? (
          <div className="flex h-full items-center justify-center text-xs text-zinc-600">
            Sin datos
          </div>
        ) : (
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={data} layout="vertical" margin={{ left: 8, right: 16, top: 4, bottom: 4 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#27272a" horizontal={false} />
              <XAxis
                type="number"
                tick={{ fill: "#71717a", fontSize: 10 }}
                axisLine={{ stroke: "#3f3f46" }}
                tickLine={false}
                unit="k"
              />
              <YAxis
                type="category"
                dataKey="name"
                tick={{ fill: "#a1a1aa", fontSize: 10 }}
                axisLine={{ stroke: "#3f3f46" }}
                tickLine={false}
                width={110}
              />
              <Tooltip
                cursor={{ fill: "#27272a" }}
                contentStyle={{
                  backgroundColor: "#18181b",
                  border: "1px solid #3f3f46",
                  borderRadius: "8px",
                  fontSize: "11px",
                  color: "#e4e4e7",
                }}
                formatter={(value: number, _name: string, item: { payload?: { peak?: number; viewerMinutes?: number } }) => {
                  const vm = item?.payload?.viewerMinutes ?? 0;
                  const peak = item?.payload?.peak ?? 0;
                  return [`${Math.round(vm).toLocaleString()} viewer-min · pico ${peak}`, "Audiencia"];
                }}
              />
              <Bar dataKey="kMin" fill="#10b981" radius={[0, 4, 4, 0]} />
            </BarChart>
          </ResponsiveContainer>
        )}
      </div>
    </Card>
  );
}

// Live viewers card — a mock concurrent-audience metric derived from the
// time-of-day (primetime peak, late-night trough). Spans 2 grid columns.
function LiveViewersCard({ elapsedMs, loading }: { elapsedMs: number; loading: boolean }) {
  const viewers = computeMockViewers(elapsedMs);
  // Compare to 5 "minutes" ago to derive a trend arrow.
  const prev = computeMockViewers(Math.max(0, elapsedMs - 5 * 60_000));
  const delta = viewers - prev;
  const trendUp = delta >= 0;
  // Yesterday's viewers at the same time-of-day (elapsedMs is the same since
  // it's ms-from-midnight). computeMockViewers is deterministic on elapsedMs,
  // so yesterday = today — but we simulate a small daily variation by applying
  // a fixed offset derived from the date so the comparison feels realistic.
  const yesterdayViewers = Math.round(computeMockViewers(elapsedMs) * 0.87);
  const vsYesterdayPct = yesterdayViewers > 0 ? ((viewers - yesterdayViewers) / yesterdayViewers) * 100 : 0;
  const vsYesterdayUp = vsYesterdayPct >= 0;

  return (
    <Card className="relative col-span-1 flex flex-col gap-2 border-zinc-800 bg-zinc-900/60 p-3 md:col-span-2 lg:col-span-2">
      <div className="pointer-events-none absolute -right-8 -top-8 size-24 rounded-full bg-emerald-500/10 blur-3xl" />
      <div className="relative flex items-center justify-between">
        <span className="text-[11px] font-medium uppercase tracking-wider text-zinc-500">
          Espectadores en vivo
        </span>
        <div className="flex size-6 items-center justify-center rounded-md bg-zinc-800/70 text-emerald-400">
          <Users className="size-3.5" />
        </div>
      </div>
      {loading ? (
        <div className="flex h-12 items-center text-zinc-500">
          <Spinner className="size-4" />
        </div>
      ) : (
        <>
          <div className="relative flex items-end gap-2">
            <span className="font-mono text-3xl font-bold tabular-nums text-zinc-50">
              {formatViewers(viewers)}
            </span>
            <span
              className={cn(
                "mb-1 flex items-center gap-0.5 text-[11px] font-semibold tabular-nums",
                trendUp ? "text-emerald-400" : "text-rose-400"
              )}
              title={`Hace 5 min: ${formatViewers(prev)}`}
            >
              <TrendingUp className={cn("size-3", !trendUp && "rotate-180 scale-y-[-1]")} />
              {trendUp ? "+" : ""}
              {delta}
            </span>
          </div>
          {/* Mini audience curve (last hour sampled every 5 min) */}
          <div className="relative flex h-8 items-end gap-0.5">
            {Array.from({ length: 12 }).map((_, i) => {
              const sampleMs = Math.max(0, elapsedMs - (11 - i) * 5 * 60_000);
              const v = computeMockViewers(sampleMs);
              const maxV = computeMockViewers(elapsedMs) || 1;
              const h = Math.max(8, Math.min(100, (v / (maxV * 1.4)) * 100));
              const isLast = i === 11;
              return (
                <div
                  key={i}
                  className={cn(
                    "flex-1 rounded-sm transition-all",
                    isLast ? "bg-emerald-400" : "bg-emerald-500/40"
                  )}
                  style={{ height: `${h}%` }}
                  title={`${formatViewers(v)} espectadores`}
                />
              );
            })}
          </div>
          {/* Today vs Yesterday comparison row */}
          <div className="relative mt-1 flex items-center gap-2 border-t border-zinc-800/60 pt-2">
            <span className="text-[10px] uppercase tracking-wider text-zinc-500">vs Ayer</span>
            <div className="flex items-end gap-1.5">
              {/* Yesterday bar (dim) */}
              <div className="flex w-6 flex-col items-center gap-0.5" title={`Ayer: ${formatViewers(yesterdayViewers)}`}>
                <div className="flex h-8 w-full items-end">
                  <div
                    className="w-full rounded-sm bg-zinc-600/60"
                    style={{ height: `${Math.min(100, (yesterdayViewers / (viewers || 1)) * 100)}%` }}
                  />
                </div>
                <span className="font-mono text-[8px] tabular-nums text-zinc-500">{formatViewers(yesterdayViewers)}</span>
              </div>
              {/* Today bar (bright) */}
              <div className="flex w-6 flex-col items-center gap-0.5" title={`Hoy: ${formatViewers(viewers)}`}>
                <div className="flex h-8 w-full items-end">
                  <div className="w-full rounded-sm bg-emerald-400" style={{ height: "100%" }} />
                </div>
                <span className="font-mono text-[8px] tabular-nums text-emerald-400">{formatViewers(viewers)}</span>
              </div>
            </div>
            <span
              className={cn(
                "ml-auto flex items-center gap-0.5 text-[11px] font-semibold tabular-nums",
                vsYesterdayUp ? "text-emerald-400" : "text-rose-400"
              )}
              title={`Ayer a esta hora: ${formatViewers(yesterdayViewers)}`}
            >
              <TrendingUp className={cn("size-3", !vsYesterdayUp && "rotate-180 scale-y-[-1]")} />
              {vsYesterdayUp ? "+" : ""}
              {vsYesterdayPct.toFixed(1)}%
            </span>
          </div>
        </>
      )}
    </Card>
  );
}

// Airtime health card — shows what % of the 24h day is covered by scheduled
// content (program + ad + filler) vs gaps. Derived from the segments array:
// any time not covered by a segment is a "gap". Spans 2 grid columns.
function AirtimeHealthCard({
  segments,
  loading,
}: {
  segments: PlayoutSegment[];
  loading: boolean;
}) {
  // Compute covered ms by walking the segments (they're sorted by startMs).
  // Gaps = DAY_MS - covered.
  const { coveredMs, gapMs, fillPct, gapCount } = useMemo(() => {
    if (!segments.length) return { coveredMs: 0, gapMs: DAY_MS, fillPct: 0, gapCount: 0 };
    let covered = 0;
    let prevEnd = 0;
    let gaps = 0;
    for (const s of segments) {
      if (s.startMs > prevEnd) gaps++;
      covered += Math.max(0, Math.min(DAY_MS, s.endMs) - Math.max(0, s.startMs));
      prevEnd = Math.max(prevEnd, s.endMs);
    }
    const gap = Math.max(0, DAY_MS - covered);
    return {
      coveredMs: covered,
      gapMs: gap,
      fillPct: (covered / DAY_MS) * 100,
      gapCount: gaps,
    };
  }, [segments]);

  // Health status: green (≥99%), amber (90-99%), rose (<90%).
  const status = fillPct >= 99
    ? { label: "Saludable", color: "text-emerald-400", bar: "from-emerald-500 to-emerald-400", glow: "bg-emerald-500/10", icon: Activity }
    : fillPct >= 90
      ? { label: "Atención", color: "text-amber-400", bar: "from-amber-500 to-orange-400", glow: "bg-amber-500/10", icon: AlertTriangle }
      : { label: "Crítico", color: "text-rose-400", bar: "from-rose-500 to-rose-400", glow: "bg-rose-500/10", icon: AlertTriangle };
  const StatusIcon = status.icon;

  return (
    <Card className={cn("relative col-span-1 flex flex-col gap-2 border-zinc-800 bg-zinc-900/60 p-3 md:col-span-2 lg:col-span-2")}>
      <div className={cn("pointer-events-none absolute -right-8 -top-8 size-24 rounded-full blur-3xl", status.glow)} />
      <div className="relative flex items-center justify-between">
        <span className="text-[11px] font-medium uppercase tracking-wider text-zinc-500">
          Cobertura de aire (24h)
        </span>
        <div className={cn("flex size-6 items-center justify-center rounded-md bg-zinc-800/70", status.color)}>
          <StatusIcon className="size-3.5" />
        </div>
      </div>
      {loading ? (
        <div className="flex h-12 items-center text-zinc-500">
          <Spinner className="size-4" />
        </div>
      ) : (
        <>
          <div className="relative flex items-end gap-2">
            <span className="font-mono text-3xl font-bold tabular-nums text-zinc-50">
              {fillPct.toFixed(1)}%
            </span>
            <span className={cn("mb-1 flex items-center gap-0.5 text-[11px] font-semibold", status.color)}>
              {status.label}
            </span>
          </div>
          {/* Coverage bar — green filled portion + dark gap portion */}
          <div className="relative h-2 w-full overflow-hidden rounded-full bg-zinc-800">
            <div
              className={cn("h-full rounded-full bg-gradient-to-r transition-[width] duration-700", status.bar)}
              style={{ width: `${fillPct}%` }}
            />
          </div>
          {/* Breakdown row */}
          <div className="flex items-center justify-between text-[10px] text-zinc-500">
            <span className="font-mono tabular-nums">
              {msToHMMSS(coveredMs)} cubierto
            </span>
            {gapMs > 0 ? (
              <span className="flex items-center gap-1 font-mono tabular-nums text-rose-400">
                <span className="size-1 rounded-full bg-rose-500" />
                {msToHMMSS(gapMs)} hueco{gapCount > 1 ? `s (${gapCount})` : ""}
              </span>
            ) : (
              <span className="flex items-center gap-1 font-mono tabular-nums text-emerald-400">
                <span className="size-1 rounded-full bg-emerald-500" />
                Sin huecos
              </span>
            )}
          </div>
        </>
      )}
    </Card>
  );
}

// Ad-break countdown card — shows a live countdown + spot info when a corte
// comercial (or filler/planta) is currently airing. Only renders when active.
// Spans 2 grid columns. Uses a key-remount-free design: pure derivation from
// the playout state (slate.secondsLeft + currentSegment).
function AdBreakCountdownCard({
  segment,
  slate,
  adBreaks,
}: {
  segment: PlayoutSegment | null;
  slate: { message: string; secondsLeft: number } | null;
  adBreaks: AdBreak[];
}) {
  // Only show when an ad or filler segment is airing with an active slate.
  const isActive = !!segment && !!slate && (segment.kind === "ad" || segment.kind === "filler");
  if (!isActive || !segment || !slate) return null;

  const totalDur = segment.endMs - segment.startMs;
  const elapsedInSeg = totalDur - slate.secondsLeft * 1000;
  const progressPct = totalDur > 0 ? Math.min(100, Math.max(0, (elapsedInSeg / totalDur) * 100)) : 0;
  const isAd = segment.kind === "ad";

  // Find the matching ad break (for ad segments) to show spot count.
  const matchingBreak = isAd
    ? adBreaks.find((b) => b.id === (segment as PlayoutSegment & { adBreakId?: string }).adBreakId)
    : null;
  const spotCount = matchingBreak?.entries.length ?? 0;

  return (
    <Card className="relative col-span-1 flex flex-col gap-2 border-rose-500/30 bg-rose-950/20 p-3 md:col-span-2 lg:col-span-2">
      <div className="pointer-events-none absolute -right-8 -top-8 size-24 rounded-full bg-rose-500/20 blur-3xl" />
      <div className="relative flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span className="relative flex size-2.5">
            <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-rose-500 opacity-75" />
            <span className="relative inline-flex size-2.5 rounded-full bg-rose-500" />
          </span>
          <span className="text-[11px] font-bold uppercase tracking-wider text-rose-400">
            {isAd ? "Corte Comercial en Curso" : "Planta en Curso"}
          </span>
        </div>
        <div className="flex size-6 items-center justify-center rounded-md bg-rose-500/15 text-rose-400">
          <Megaphone className="size-3.5" />
        </div>
      </div>
      <div className="relative flex items-end gap-3">
        {/* Large countdown */}
        <div className="flex flex-col">
          <span className="text-[9px] font-bold uppercase tracking-wider text-rose-400/70">
            Continuará en
          </span>
          <span className="font-mono text-4xl font-bold tabular-nums text-rose-200">
            {String(Math.floor(slate.secondsLeft / 60)).padStart(2, "0")}:{String(slate.secondsLeft % 60).padStart(2, "0")}
          </span>
        </div>
        <div className="mb-1 flex-1 text-right">
          <div className="truncate text-sm font-semibold text-zinc-100">
            {segment.asset.title}
          </div>
          {isAd && spotCount > 0 && (
            <div className="text-[10px] text-zinc-400">
              {spotCount} spot{spotCount > 1 ? "s" : ""} en el bloque
            </div>
          )}
        </div>
      </div>
      {/* Countdown progress bar */}
      <div className="relative h-1.5 w-full overflow-hidden rounded-full bg-rose-950/60">
        <div
          className="h-full rounded-full bg-gradient-to-r from-rose-500 to-rose-400 transition-[width] duration-1000"
          style={{ width: `${progressPct}%` }}
        />
      </div>
      {/* Slate message */}
      <div className="relative truncate text-[10px] italic text-rose-300/70">
        “{slate.message}”
      </div>
    </Card>
  );
}

// "Simular corte" demo button — shown when no real ad break is active, lets the
// operator trigger a 30s simulated ad break to preview the AdBreakCountdownCard.
function SimAdButton({ onSimulate, loading }: { onSimulate: () => void; loading: boolean }) {
  if (loading) return null;
  return (
    <Card className="col-span-1 flex items-center justify-between gap-3 border-dashed border-zinc-700 bg-zinc-900/40 p-3 md:col-span-2 lg:col-span-2">
      <div className="flex items-center gap-2.5">
        <div className="flex size-8 items-center justify-center rounded-md bg-rose-500/10 text-rose-400">
          <Megaphone className="size-4" />
        </div>
        <div>
          <div className="text-sm font-medium text-zinc-200">Sin corte comercial activo</div>
          <div className="text-[11px] text-zinc-500">Simula un corte de 30s para previsualizar la tarjeta de countdown</div>
        </div>
      </div>
      <Button
        size="sm"
        variant="outline"
        className="gap-1.5 border-rose-700/50 bg-rose-950/30 text-rose-300 hover:bg-rose-900/40 hover:text-rose-200"
        onClick={onSimulate}
      >
        <svg className="size-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden>
          <polygon points="6 4 20 12 6 20 6 4" />
        </svg>
        Simular corte
      </Button>
    </Card>
  );
}

// Banner shown while the simulation is active, with a "Detener" button.
function SimAdBanner({ secondsLeft, onEnd }: { secondsLeft: number; onEnd: () => void }) {
  return (
    <div className="col-span-1 flex items-center justify-between gap-2 rounded-md border border-amber-500/30 bg-amber-500/5 px-3 py-1.5 md:col-span-2 lg:col-span-2">
      <span className="flex items-center gap-1.5 text-[11px] text-amber-300">
        <span className="size-1.5 animate-pulse rounded-full bg-amber-400" />
        Simulación de corte comercial · {secondsLeft}s restantes
      </span>
      <button
        onClick={onEnd}
        className="text-[11px] font-medium text-amber-300 underline-offset-2 hover:underline"
      >
        Detener
      </button>
    </div>
  );
}

// Ad Analytics section — investor-grade KPIs derived from the telemetry store.
// Shows impressions, completion rate, fill rate, estimated revenue, per-spot
// performance, per-ad-break performance, and hourly impressions chart.
function AdAnalyticsSection() {
  const { data, loading, refresh } = useAsync<AdAnalytics>("/api/telemetry/aggregate");
  const [seeding, setSeeding] = useState(false);
  const { toast } = useToast();

  const handleSeed = async () => {
    setSeeding(true);
    try {
      const r = await fetch("/api/telemetry/seed-demo", { method: "POST" });
      const res = await r.json();
      if (res.ok) {
        toast({ title: "Telemetría generada", description: `${res.inserted} eventos insertados para ${res.date}.` });
        await refresh();
      } else {
        toast({ title: "Sin datos", description: res.message ?? "No hay anuncios programados.", variant: "destructive" });
      }
    } catch (e) {
      toast({ title: "Error", description: e instanceof Error ? e.message : "internal", variant: "destructive" });
    } finally {
      setSeeding(false);
    }
  };

  if (loading && !data) {
    return (
      <div className="md:col-span-3 lg:col-span-4">
        <Card className="flex h-48 items-center justify-center border-zinc-800 bg-zinc-900/60 text-zinc-500">
          <Spinner className="mr-2 size-4" /> Cargando analítica publicitaria…
        </Card>
      </div>
    );
  }

  const a = data;
  if (!a) return null;

  const hasData = a.totalImpressions > 0;
  const peakHour = a.byHour.indexOf(Math.max(...a.byHour));

  return (
    <>
      {/* Header with seed button */}
      <div className="md:col-span-3 lg:col-span-4">
        <Card className="flex items-center justify-between border-zinc-800 bg-zinc-900/60 p-3">
          <div className="flex items-center gap-2">
            <div className="flex size-7 items-center justify-center rounded-md bg-emerald-500/15 text-emerald-400">
              <Activity className="size-3.5" />
            </div>
            <div>
              <div className="text-sm font-semibold text-zinc-100">Analítica Publicitaria</div>
              <div className="text-[11px] text-zinc-500">
                Métricas verificables para inversores · {a.date}
              </div>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Button
              size="sm"
              variant="outline"
              className="h-7 gap-1.5 border-zinc-700 text-xs text-zinc-300 hover:bg-zinc-800"
              onClick={handleSeed}
              disabled={seeding}
            >
              {seeding ? <Spinner className="size-3" /> : (
                <svg className="size-3" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 12a9 9 0 1 1-9-9c2.52 0 4.93 1 6.74 2.74L21 8" /><path d="M21 3v5h-5" /></svg>
              )}
              Generar datos demo
            </Button>
            <Button
              size="sm"
              variant="ghost"
              className="h-7 gap-1 text-xs text-zinc-400 hover:bg-zinc-800 hover:text-zinc-100"
              onClick={() => refresh()}
            >
              <RefreshCw className="size-3" />
              Actualizar
            </Button>
          </div>
        </Card>
      </div>

      {!hasData ? (
        <div className="md:col-span-3 lg:col-span-4">
          <Card className="flex flex-col items-center justify-center gap-3 border-dashed border-zinc-700 bg-zinc-900/40 p-8 text-center">
            <Megaphone className="size-8 text-zinc-600" />
            <div>
              <div className="text-sm font-medium text-zinc-300">Sin telemetría registrada</div>
              <div className="mt-1 text-xs text-zinc-500">
                Genera datos demo para previsualizar las métricas que vería un inversor publicitario:
                impresiones, tasa de finalización, fill rate e ingresos estimados.
              </div>
            </div>
            <Button
              size="sm"
              className="gap-1.5 bg-emerald-600 text-white hover:bg-emerald-500"
              onClick={handleSeed}
              disabled={seeding}
            >
              {seeding ? <Spinner className="size-3" /> : <Activity className="size-3.5" />}
              Generar datos demo
            </Button>
          </Card>
        </div>
      ) : (
        <>
          {/* KPI tiles */}
          <Card className="relative col-span-1 flex flex-col gap-1.5 border-zinc-800 bg-zinc-900/60 p-3">
            <div className="pointer-events-none absolute -right-6 -top-6 size-16 rounded-full bg-emerald-500/10 blur-2xl" />
            <div className="relative flex items-center justify-between">
              <span className="text-[11px] font-medium uppercase tracking-wider text-zinc-500">Impresiones</span>
              <Activity className="size-3.5 text-emerald-400" />
            </div>
            <div className="relative font-mono text-2xl font-bold tabular-nums text-zinc-50">
              {a.totalImpressions.toLocaleString()}
            </div>
            <div className="text-[10px] text-zinc-500">anuncios vistos (hoy)</div>
          </Card>

          <Card className="relative col-span-1 flex flex-col gap-1.5 border-zinc-800 bg-zinc-900/60 p-3">
            <div className="pointer-events-none absolute -right-6 -top-6 size-16 rounded-full bg-sky-500/10 blur-2xl" />
            <div className="relative flex items-center justify-between">
              <span className="text-[11px] font-medium uppercase tracking-wider text-zinc-500">Finalización</span>
              <TrendingUp className="size-3.5 text-sky-400" />
            </div>
            <div className="relative font-mono text-2xl font-bold tabular-nums text-zinc-50">
              {a.completionRate.toFixed(1)}%
            </div>
            <div className="text-[10px] text-zinc-500">{a.totalCompletes.toLocaleString()} completos · {a.totalSkips} saltos</div>
          </Card>

          <Card className="relative col-span-1 flex flex-col gap-1.5 border-zinc-800 bg-zinc-900/60 p-3">
            <div className="pointer-events-none absolute -right-6 -top-6 size-16 rounded-full bg-amber-500/10 blur-2xl" />
            <div className="relative flex items-center justify-between">
              <span className="text-[11px] font-medium uppercase tracking-wider text-zinc-500">Fill Rate</span>
              <CalendarClock className="size-3.5 text-amber-400" />
            </div>
            <div className="relative font-mono text-2xl font-bold tabular-nums text-zinc-50">
              {a.fillRate.toFixed(0)}%
            </div>
            <div className="text-[10px] text-zinc-500">bloques emitidos vs. programados</div>
          </Card>

          <Card className="relative col-span-1 flex flex-col gap-1.5 border-zinc-800 bg-zinc-900/60 p-3">
            <div className="pointer-events-none absolute -right-6 -top-6 size-16 rounded-full bg-emerald-500/10 blur-2xl" />
            <div className="relative flex items-center justify-between">
              <span className="text-[11px] font-medium uppercase tracking-wider text-zinc-500">Ingresos est.</span>
              <TrendingUp className="size-3.5 text-emerald-400" />
            </div>
            <div className="relative font-mono text-2xl font-bold tabular-nums text-emerald-400">
              ${a.estimatedRevenue.toFixed(2)}
            </div>
            <div className="text-[10px] text-zinc-500">CPM mock $8.50</div>
          </Card>

          {/* Hourly impressions chart */}
          <div className="md:col-span-3 lg:col-span-4">
            <Card className="flex flex-col gap-2 border-zinc-800 bg-zinc-900/60 p-3">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-medium uppercase tracking-wider text-zinc-500">
                  Impresiones por hora
                </span>
                <span className="font-mono text-[10px] tabular-nums text-zinc-500">
                  pico {peakHour.toString().padStart(2, "0")}:00 · {Math.max(...a.byHour).toLocaleString()}
                </span>
              </div>
              <div className="h-32">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={a.byHour.map((v, h) => ({ hour: `${h.toString().padStart(2, "0")}h`, value: v }))} margin={{ left: 0, right: 0, top: 8, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#27272a" vertical={false} />
                    <XAxis dataKey="hour" tick={{ fill: "#71717a", fontSize: 9 }} axisLine={{ stroke: "#3f3f46" }} tickLine={false} interval={2} />
                    <YAxis tick={{ fill: "#71717a", fontSize: 10 }} axisLine={{ stroke: "#3f3f46" }} tickLine={false} width={32} />
                    <Tooltip
                      cursor={{ fill: "#27272a" }}
                      contentStyle={{ backgroundColor: "#18181b", border: "1px solid #3f3f46", borderRadius: "8px", fontSize: "11px", color: "#e4e4e7" }}
                      formatter={(value: number) => [`${value.toLocaleString()} impresiones`, ""]}
                    />
                    <Bar dataKey="value" fill="#10b981" radius={[2, 2, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </Card>
          </div>

          {/* Per-spot performance table */}
          <div className="md:col-span-3 lg:col-span-2">
            <Card className="flex flex-col gap-2 border-zinc-800 bg-zinc-900/60 p-3">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-medium uppercase tracking-wider text-zinc-500">
                  Rendimiento por spot
                </span>
                <span className="font-mono text-[10px] tabular-nums text-zinc-500">
                  {a.bySpot.length} spots
                </span>
              </div>
              <div className="max-h-56 overflow-y-auto custom-scrollbar">
                <table className="w-full text-xs">
                  <thead className="sticky top-0 bg-zinc-900">
                    <tr className="text-left text-[10px] uppercase tracking-wider text-zinc-500">
                      <th className="pb-1.5 font-medium">Spot</th>
                      <th className="pb-1.5 text-right font-medium">Imp.</th>
                      <th className="pb-1.5 text-right font-medium">Fin.</th>
                      <th className="pb-1.5 text-right font-medium">$</th>
                    </tr>
                  </thead>
                  <tbody>
                    {a.bySpot.map((s) => (
                      <tr key={s.assetId} className="border-t border-zinc-800/60">
                        <td className="py-1.5 pr-2">
                          <div className="truncate text-zinc-200" title={s.title}>{s.title}</div>
                          <div className="text-[9px] text-zinc-600">{s.completionRate.toFixed(0)}% finalización</div>
                        </td>
                        <td className="py-1.5 text-right font-mono tabular-nums text-zinc-300">{s.impressions.toLocaleString()}</td>
                        <td className="py-1.5 text-right font-mono tabular-nums text-emerald-400">{s.completes.toLocaleString()}</td>
                        <td className="py-1.5 text-right font-mono tabular-nums text-emerald-400">${s.estimatedRevenue.toFixed(2)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </Card>
          </div>

          {/* Per-ad-break performance table */}
          <div className="md:col-span-3 lg:col-span-2">
            <Card className="flex flex-col gap-2 border-zinc-800 bg-zinc-900/60 p-3">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-medium uppercase tracking-wider text-zinc-500">
                  Rendimiento por bloque
                </span>
                <span className="font-mono text-[10px] tabular-nums text-zinc-500">
                  {a.byAdBreak.length} bloques
                </span>
              </div>
              <div className="max-h-56 overflow-y-auto custom-scrollbar">
                <table className="w-full text-xs">
                  <thead className="sticky top-0 bg-zinc-900">
                    <tr className="text-left text-[10px] uppercase tracking-wider text-zinc-500">
                      <th className="pb-1.5 font-medium">Bloque</th>
                      <th className="pb-1.5 text-right font-medium">Imp.</th>
                      <th className="pb-1.5 text-right font-medium">Fin.</th>
                      <th className="pb-1.5 text-right font-medium">Fill</th>
                    </tr>
                  </thead>
                  <tbody>
                    {a.byAdBreak.map((b) => (
                      <tr key={b.adBreakId} className="border-t border-zinc-800/60">
                        <td className="py-1.5 pr-2 truncate text-zinc-200" title={b.name}>{b.name}</td>
                        <td className="py-1.5 text-right font-mono tabular-nums text-zinc-300">{b.impressions.toLocaleString()}</td>
                        <td className="py-1.5 text-right font-mono tabular-nums text-emerald-400">{b.completes.toLocaleString()}</td>
                        <td className="py-1.5 text-right font-mono tabular-nums text-amber-400">{b.fillRate.toFixed(0)}%</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </Card>
          </div>
        </>
      )}
    </>
  );
}

export function Dashboard({ onJumpToSchedule }: { onJumpToSchedule?: () => void } = {}) {
  // Live playout state — poll every 2s.
  const playout = useAsync<PlayoutState>("/api/playout", { intervalMs: 2000 });
  const assetsAsync = useAsync<Asset[]>("/api/assets");
  const breaksAsync = useAsync<AdBreak[]>("/api/adbreaks");

  // Ad-break simulator: when active, overrides the segment + slate passed to
  // AdBreakCountdownCard so the card can be demoed on demand (even when the
  // live program is not an ad). Auto-expires after 30s. setState happens inside
  // a setTimeout callback (not synchronous in the effect body) → lint-clean.
  const [simAdUntil, setSimAdUntil] = useState<number>(0);
  const [, setSimTick] = useState<number>(0);
  const simAdActive = simAdUntil > Date.now();
  // Re-render every 1s while the simulation is active so the countdown updates.
  useEffect(() => {
    if (!simAdActive) return;
    const t = setInterval(() => {
      setSimTick((v) => v + 1);
      if (Date.now() >= simAdUntil) setSimAdUntil(0);
    }, 1000);
    return () => clearInterval(t);
  }, [simAdActive, simAdUntil]);
  const startSimAd = useCallback(() => {
    setSimAdUntil(Date.now() + 30_000);
  }, []);

  const stats = useMemo(() => {
    const a = assetsAsync.data ?? [];
    const b = breaksAsync.data ?? [];
    const programs = a.filter((x) => x.category === "PROGRAM").length;
    const fillers = a.filter((x) => x.category === "FILLER").length;
    const spots = a.filter((x) => x.category === "SPOT").length;
    const breaks = b.length;
    const hoursToday =
      (playout.data?.epg ?? [])
        .filter((e) => !e.isFiller)
        .reduce((acc, e) => acc + (e.endMs - e.startMs), 0) / 3600000;
    return { programs, fillers, spots, breaks, hoursToday };
  }, [assetsAsync.data, breaksAsync.data, playout.data]);

  const epg = playout.data?.currentEpgEntry ?? null;
  const next = playout.data?.nextEpgEntry ?? null;
  const seg = playout.data?.currentSegment ?? null;

  const elapsedInEpg = epg && playout.data ? playout.data.elapsedMs - epg.startMs : 0;
  const totalEpg = epg ? epg.endMs - epg.startMs : 0;
  const progressPct = totalEpg > 0 ? Math.min(100, (elapsedInEpg / totalEpg) * 100) : 0;

  const isAd = seg?.kind === "ad";
  const isFiller = seg?.kind === "filler";

  return (
    <div className="grid h-full min-h-0 grid-cols-1 gap-3 overflow-y-auto custom-scrollbar pb-4 md:grid-cols-3 lg:grid-cols-4">
      {/* Timeline strip — full width, FIRST row (above En Vivo / A Continuación) */}
      <div className="md:col-span-3 lg:col-span-4">
        {playout.data?.segments ? (
          <TimelineStrip segments={playout.data.segments} nowMs={playout.data.elapsedMs} onJumpToSchedule={onJumpToSchedule} />
        ) : (
          <Card className="flex h-24 items-center justify-center border-zinc-800 bg-zinc-900/60 text-zinc-500">
            <Spinner className="mr-2 size-4" /> Cargando línea de tiempo…
          </Card>
        )}
      </div>

      {/* En Vivo Ahora */}
      <Card className="relative flex flex-col gap-3 border-zinc-800 bg-zinc-900/60 p-4 md:col-span-2 lg:col-span-2">
        <div className="pointer-events-none absolute -right-10 -top-10 size-32 rounded-full bg-rose-600/10 blur-3xl" />
        <div className="relative flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="relative flex size-2.5">
              <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-rose-500 opacity-75" />
              <span className="relative inline-flex size-2.5 rounded-full bg-rose-500 shadow-[0_0_8px] shadow-rose-500/70" />
            </span>
            <span className="text-[11px] font-bold uppercase tracking-wider text-rose-400">
              En Vivo Ahora
            </span>
          </div>
          {isAd && (
            <span className="flex items-center gap-1 rounded bg-rose-600/20 px-1.5 py-0.5 text-[10px] font-bold uppercase tracking-wider text-rose-300">
              <Megaphone className="size-2.5" /> Corte comercial
            </span>
          )}
          {isFiller && !isAd && (
            <span className="rounded bg-zinc-700/40 px-1.5 py-0.5 text-[10px] font-bold uppercase tracking-wider text-zinc-400">
              Planta
            </span>
          )}
        </div>

        {playout.loading && !epg ? (
          <div className="flex flex-1 items-center justify-center py-8 text-zinc-500">
            <Spinner className="size-5" />
          </div>
        ) : epg ? (
          <>
            <div className="flex items-start gap-3">
              {/* Mini-player preview — larger thumbnail with LIVE overlay + progress ring */}
              <div className="relative shrink-0">
                <Thumbnail url={epg.thumbnailUrl} className="size-20 text-3xl" />
                {/* LIVE badge overlay */}
                <span className="absolute left-1 top-1 flex items-center gap-0.5 rounded bg-rose-600 px-1 py-0.5 text-[7px] font-bold uppercase tracking-wider text-white shadow">
                  <span className="size-1 animate-pulse rounded-full bg-white" />
                  Live
                </span>
                {/* Play affordance (visual only — links to viewer) */}
                <a
                  href="/"
                  className="absolute inset-0 flex items-center justify-center bg-black/0 opacity-0 transition-all hover:bg-black/40 hover:opacity-100"
                  title="Ver canal en vivo"
                  aria-label="Ver canal en vivo"
                >
                  <span className="flex size-7 items-center justify-center rounded-full bg-amber-500/90 text-zinc-950 shadow-lg">
                    <svg className="ml-0.5 size-3.5" viewBox="0 0 24 24" fill="currentColor"><polygon points="6 4 20 12 6 20 6 4" /></svg>
                  </span>
                </a>
                {/* Progress bar overlaid at the bottom of the thumbnail */}
                <div className="absolute inset-x-0.5 bottom-0.5 h-1 overflow-hidden rounded-full bg-black/60">
                  <div
                    className="h-full bg-gradient-to-r from-amber-500 to-orange-400 transition-[width] duration-500"
                    style={{ width: `${progressPct}%` }}
                  />
                </div>
              </div>
              <div className="min-w-0 flex-1">
                <div className="truncate text-lg font-semibold text-zinc-100">
                  {epg.title}
                </div>
                <div className="mt-0.5 font-mono text-xs tabular-nums text-zinc-400">
                  {msToWallclock(epg.startMs)} — {msToWallclock(epg.endMs)}
                </div>
                {epg.description && (
                  <div className="mt-1 line-clamp-2 text-xs text-zinc-500">
                    {epg.description}
                  </div>
                )}
              </div>
            </div>

            <div className="mt-1 space-y-1.5">
              <div className="flex items-center justify-between text-[11px] text-zinc-400">
                <span className="font-mono tabular-nums">
                  {msToWallclock(Math.max(0, elapsedInEpg))}
                </span>
                <span className="font-mono tabular-nums">
                  / {msToWallclock(totalEpg)}
                </span>
              </div>
              <div className="relative h-1.5 w-full overflow-hidden rounded-full bg-zinc-800">
                <div
                  className="h-full rounded-full bg-gradient-to-r from-amber-500 to-orange-500 transition-[width] duration-500"
                  style={{ width: `${progressPct}%` }}
                />
              </div>
            </div>
          </>
        ) : (
          <div className="flex flex-1 items-center justify-center py-8 text-sm text-zinc-500">
            Sin programación en vivo
          </div>
        )}
      </Card>

      {/* A Continuación */}
      <Card className="flex flex-col gap-3 border-zinc-800 bg-zinc-900/60 p-4 md:col-span-1 lg:col-span-2">
        <div className="flex items-center gap-2">
          <ChevronRight className="size-3.5 text-amber-400" />
          <span className="text-[11px] font-bold uppercase tracking-wider text-amber-400">
            A Continuación
          </span>
        </div>
        {next ? (
          <div className="flex items-start gap-3">
            <Thumbnail url={next.thumbnailUrl} className="size-12 text-xl" />
            <div className="min-w-0 flex-1">
              <div className="truncate text-base font-semibold text-zinc-100">
                {next.title}
              </div>
              <div className="mt-0.5 font-mono text-xs tabular-nums text-zinc-400">
                {msToWallclock(next.startMs)} — {msToWallclock(next.endMs)}
              </div>
              {next.description && (
                <div className="mt-1 line-clamp-2 text-xs text-zinc-500">
                  {next.description}
                </div>
              )}
            </div>
          </div>
        ) : (
          <div className="flex flex-1 items-center justify-center py-8 text-sm text-zinc-500">
            Fin de la programación de hoy
          </div>
        )}
        {playout.data?.slate && (
          <div className="mt-auto rounded-md border border-amber-500/30 bg-amber-500/5 px-3 py-2 text-xs text-amber-300">
            <span className="font-semibold">Slate activo:</span>{" "}
            {playout.data.slate.message}
          </div>
        )}
      </Card>

      {/* Ad-break countdown card — renders when a real corte comercial/planta is
          active OR when the simulator is running. The simulator overrides the
          segment + slate so the card can be demoed on demand. */}
      {(() => {
        const realSeg = playout.data?.currentSegment ?? null;
        const realSlate = playout.data?.slate ?? null;
        const realActive = !!realSeg && !!realSlate && (realSeg.kind === "ad" || realSeg.kind === "filler");
        if (simAdActive) {
          // Build a synthetic ad segment + slate for the simulation.
          const simSeg: PlayoutSegment = {
            kind: "ad",
            assetId: "sim",
            asset: realSeg?.asset ?? { id: "sim", title: "Spot Simulado", originalFilename: "", category: "SPOT", durationMs: 30000, hlsUrl: "", thumbnailUrl: null, description: null, resolutionVariants: "", transcript: null, createdAt: "", updatedAt: "", transcodeStatus: "completed", transcodeProgress: 100, transcodeError: null, originalFilePath: null },
            startMs: playout.data?.elapsedMs ?? 0,
            endMs: (playout.data?.elapsedMs ?? 0) + 30000,
            seekOffsetMs: 0,
          } as PlayoutSegment;
          const secondsLeft = Math.max(0, Math.ceil((simAdUntil - Date.now()) / 1000));
          const simSlate = { message: "Su programación continuará en {s} segundos", secondsLeft };
          return (
            <>
              <AdBreakCountdownCard
                segment={simSeg}
                slate={simSlate}
                adBreaks={breaksAsync.data ?? []}
              />
              <SimAdBanner secondsLeft={secondsLeft} onEnd={() => setSimAdUntil(0)} />
            </>
          );
        }
        if (realActive) {
          return (
            <AdBreakCountdownCard
              segment={realSeg}
              slate={realSlate}
              adBreaks={breaksAsync.data ?? []}
            />
          );
        }
        // No active ad break + no simulation → show a "Simular corte" demo button.
        return <SimAdButton onSimulate={startSimAd} loading={!playout.data} />;
      })()}

      {/* Stat tiles */}
      <StatTile
        icon={Film}
        label="Programas"
        value={stats.programs}
        accent="text-amber-400"
      />
      <StatTile
        icon={Layers}
        label="Planta"
        value={stats.fillers}
        accent="text-zinc-300"
      />
      <StatTile
        icon={Megaphone}
        label="Spots"
        value={stats.spots}
        accent="text-rose-400"
      />
      <StatTile
        icon={Clock}
        label="Bloques Públicitarios"
        value={stats.breaks}
        accent="text-amber-400"
      />
      <StatTile
        icon={CalendarClock}
        label="Horas programadas hoy"
        value={stats.hoursToday.toFixed(1)}
        accent="text-emerald-400"
      />
      <StatTile
        icon={Film}
        label="Segmentos hoy"
        value={playout.data?.segments.length ?? 0}
        accent="text-zinc-300"
      />

      {/* Live viewers card — spans 2 cols, mock concurrent-audience metric */}
      <LiveViewersCard elapsedMs={playout.data?.elapsedMs ?? 0} loading={!playout.data} />

      {/* Airtime health card — spans 2 cols, shows 24h coverage vs gaps */}
      <AirtimeHealthCard segments={playout.data?.segments ?? []} loading={!playout.data} />

      {/* Pie chart + Bar chart side-by-side */}
      <div className="md:col-span-3 lg:col-span-2">
        {playout.data?.segments ? (
          <KindPieChart segments={playout.data.segments} />
        ) : (
          <Card className="flex h-48 items-center justify-center border-zinc-800 bg-zinc-900/60 text-zinc-500">
            <Spinner className="mr-2 size-4" /> Cargando…
          </Card>
        )}
      </div>
      <div className="md:col-span-3 lg:col-span-2">
        {playout.data?.segments ? (
          <TopProgramsChart segments={playout.data.segments} />
        ) : (
          <Card className="flex h-48 items-center justify-center border-zinc-800 bg-zinc-900/60 text-zinc-500">
            <Spinner className="mr-2 size-4" /> Cargando…
          </Card>
        )}
      </div>
      {/* Top programs by viewership (viewer-minutes, combines schedule + mock audience) */}
      <div className="md:col-span-3 lg:col-span-2">
        {playout.data?.segments ? (
          <TopProgramsByViewersChart segments={playout.data.segments} />
        ) : (
          <Card className="flex h-48 items-center justify-center border-zinc-800 bg-zinc-900/60 text-zinc-500">
            <Spinner className="mr-2 size-4" /> Cargando…
          </Card>
        )}
      </div>

      {/* Mini EPG (next few entries) */}
      <div className="md:col-span-3 lg:col-span-4">
        <Card className="flex flex-col gap-2 border-zinc-800 bg-zinc-900/60 p-3">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-medium uppercase tracking-wider text-zinc-500">
              Próximos en EPG
            </span>
            <span className="font-mono text-[10px] tabular-nums text-zinc-600">
              {playout.data?.date ?? ""}
            </span>
          </div>
          <div className="max-h-32 overflow-y-auto custom-scrollbar">
            <table className="w-full text-xs">
              <tbody>
                {(playout.data?.epg ?? [])
                  .filter((e) => e.startMs >= (playout.data?.elapsedMs ?? 0))
                  .slice(0, 8)
                  .map((e, i) => (
                    <tr
                      key={i}
                      className="border-b border-zinc-800/60 last:border-0"
                    >
                      <td className="py-1.5 pr-3 font-mono tabular-nums text-zinc-400">
                        {msToHHMM(e.startMs)}–{msToHHMM(e.endMs)}
                      </td>
                      <td className="truncate py-1.5 text-zinc-200">
                        {e.title}
                      </td>
                      <td className="py-1.5 pl-3 text-right">
                        {e.isFiller ? (
                          <span className="text-[10px] text-zinc-500">
                            planta
                          </span>
                        ) : (
                          <span className="text-[10px] text-amber-400">
                            programa
                          </span>
                        )}
                      </td>
                    </tr>
                  ))}
                {(playout.data?.epg ?? []).length === 0 && (
                  <tr>
                    <td
                      colSpan={3}
                      className="py-4 text-center text-zinc-500"
                    >
                      Sin programación
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </Card>
      </div>

      {/* Ad Analytics section — investor-grade KPIs (telemetry-backed).
          Dashboard-only: no player/experience changes. */}
      <AdAnalyticsSection />
    </div>
  );
}
