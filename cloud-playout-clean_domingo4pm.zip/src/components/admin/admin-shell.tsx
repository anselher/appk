"use client";

import { useState } from "react";
import Link from "next/link";
import { motion, AnimatePresence } from "framer-motion";
import {
  LayoutDashboard,
  Film,
  CalendarClock,
  Megaphone,
  Settings,
  Tv,
  Menu,
  Radio,
  RefreshCw,
  PanelLeftClose,
  PanelLeftOpen,
  Clapperboard,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import {
  Sheet,
  SheetContent,
  SheetTrigger,
  SheetTitle,
} from "@/components/ui/sheet";
import { useToast } from "@/hooks/use-toast";
import { useAsync, msToWallclock } from "./shared";
import { Dashboard } from "./dashboard";
import { MediaLibrary } from "./media-library";
import { ScheduleGrid } from "./schedule-grid";
import { AdBreaks } from "./ad-breaks";
import { AvancesModule } from "./avances";
import { SettingsModule } from "./settings";
import type { PlayoutState } from "@/lib/types";

export type AdminView =
  | "dashboard"
  | "media"
  | "schedule"
  | "adbreaks"
  | "avances"
  | "settings";

interface NavItem {
  id: AdminView;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
}

const NAV: NavItem[] = [
  { id: "dashboard", label: "Dashboard", icon: LayoutDashboard },
  { id: "media", label: "Medios (MAM)", icon: Film },
  { id: "schedule", label: "Programación", icon: CalendarClock },
  { id: "adbreaks", label: "Bloques Publicitarios", icon: Megaphone },
  { id: "avances", label: "Avances", icon: Clapperboard },
  { id: "settings", label: "Ajustes", icon: Settings },
];

function SidebarContent({
  view,
  setView,
  channelName,
  channelLogo,
  collapsed,
}: {
  view: AdminView;
  setView: (v: AdminView) => void;
  channelName: string;
  channelLogo: string;
  collapsed?: boolean;
}) {
  return (
    <div className="flex h-full flex-col bg-zinc-950">
      {/* Channel logo + name */}
      <div className={cn("flex items-center gap-2.5 border-b border-zinc-800/80 py-4", collapsed ? "justify-center px-2" : "px-4")}>
        <div className="flex size-9 shrink-0 items-center justify-center rounded-md bg-gradient-to-br from-amber-500 to-orange-600 text-sm font-bold text-zinc-950 shadow-lg shadow-amber-500/20">
          {channelLogo || "CN"}
        </div>
        {!collapsed && (
          <div className="min-w-0">
            <div className="truncate text-sm font-semibold text-zinc-100">
              {channelName}
            </div>
            <div className="text-[11px] font-medium uppercase tracking-wider text-amber-500/80">
              Playout Admin
            </div>
          </div>
        )}
      </div>

      {/* Nav */}
      <nav className="flex-1 overflow-y-auto custom-scrollbar px-2 py-3">
        {collapsed ? (
          <ul className="space-y-1">
            {NAV.map((item) => {
              const active = view === item.id;
              const Icon = item.icon;
              return (
                <li key={item.id} className="flex justify-center">
                  <button
                    onClick={() => setView(item.id)}
                    className={cn(
                      "group relative flex size-9 items-center justify-center rounded-md transition-all",
                      active
                        ? "bg-amber-500/10 text-amber-300"
                        : "text-zinc-400 hover:bg-zinc-800/60 hover:text-zinc-100"
                    )}
                    title={item.label}
                    aria-label={item.label}
                  >
                    {active && (
                      <span className="absolute left-0 top-1/2 h-5 w-0.5 -translate-y-1/2 rounded-r-full bg-amber-400" />
                    )}
                    <Icon
                      className={cn(
                        "size-4 shrink-0 transition-transform group-hover:scale-110",
                        active ? "text-amber-400" : "text-zinc-500 group-hover:text-zinc-300"
                      )}
                    />
                  </button>
                </li>
              );
            })}
          </ul>
        ) : (
          <>
            <div className="mb-1.5 flex items-center gap-2 px-2 text-[10px] font-semibold uppercase tracking-wider text-zinc-500">
              <span className="h-px flex-1 bg-zinc-800" />
              Operación
              <span className="h-px flex-1 bg-zinc-800" />
            </div>
            <ul className="space-y-0.5">
              {NAV.map((item) => {
                const active = view === item.id;
                const Icon = item.icon;
                return (
                  <li key={item.id}>
                    <button
                      onClick={() => setView(item.id)}
                      className={cn(
                        "group relative flex w-full items-center gap-2.5 rounded-md px-2.5 py-2 text-sm font-medium transition-all",
                        active
                          ? "bg-amber-500/10 text-amber-300"
                          : "text-zinc-400 hover:bg-zinc-800/60 hover:text-zinc-100"
                      )}
                    >
                      {/* Active left accent bar */}
                      {active && (
                        <span className="absolute left-0 top-1/2 h-5 w-0.5 -translate-y-1/2 rounded-r-full bg-amber-400" />
                      )}
                      <Icon
                        className={cn(
                          "size-4 shrink-0 transition-transform group-hover:scale-110",
                          active
                            ? "text-amber-400"
                            : "text-zinc-500 group-hover:text-zinc-300"
                        )}
                      />
                      <span className="truncate">{item.label}</span>
                      {active && (
                        <span className="ml-auto size-1.5 rounded-full bg-amber-400 shadow-[0_0_6px] shadow-amber-400/70" />
                      )}
                    </button>
                  </li>
                );
              })}
            </ul>
          </>
        )}
      </nav>

      {/* Footer: link back to viewer */}
      <div className="border-t border-zinc-800/80 p-2">
        <Button
          asChild
          variant="outline"
          className={cn(
            "border-zinc-700 bg-transparent text-zinc-300 hover:bg-zinc-800 hover:text-zinc-100",
            collapsed ? "size-9 p-0" : "w-full justify-start"
          )}
        >
          <Link href="/" title={collapsed ? "Ver Canal" : undefined} aria-label={collapsed ? "Ver Canal" : undefined}>
            <Tv className="size-4" />
            {!collapsed && <span>Ver Canal</span>}
          </Link>
        </Button>
      </div>
    </div>
  );
}

function LiveClock() {
  // Poll playout state every 1s for the wallclock + EN VIVO badge.
  const { data, loading } = useAsync<PlayoutState>("/api/playout", {
    intervalMs: 1000,
  });
  const clock = data ? msToWallclock(data.elapsedMs) : "--:--:--";
  const isLive = !!data?.currentSegment;

  return (
    <div className="flex items-center gap-2 rounded-md border border-zinc-800 bg-zinc-900/80 px-3 py-1.5">
      <div className="flex items-center gap-1.5">
        <span
          className={cn(
            "size-2 rounded-full",
            loading
              ? "bg-zinc-600"
              : "bg-emerald-500 shadow-[0_0_6px] shadow-emerald-500/70"
          )}
        />
        <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-400">
          Sync
        </span>
      </div>
      <div className="h-4 w-px bg-zinc-800" />
      <div className="font-mono text-sm tabular-nums text-zinc-100">{clock}</div>
      <span className="inline-flex items-center gap-1 rounded bg-rose-600/20 px-1.5 py-0.5 text-[10px] font-bold uppercase tracking-wider text-rose-300">
        <Radio className="size-3 animate-pulse" />
        En Vivo
      </span>
    </div>
  );
}

export function AdminShell() {
  const [view, setView] = useState<AdminView>("dashboard");
  const [mobileOpen, setMobileOpen] = useState(false);
  // Sidebar collapse state — lazy-initialized from localStorage (SSR-safe:
  // typeof window guard) so the user's preference persists across sessions.
  const [collapsed, setCollapsed] = useState<boolean>(
    typeof window !== "undefined" && window.localStorage.getItem("admin:sidebarCollapsed") === "1"
  );
  const toggleCollapsed = () => {
    setCollapsed((prev) => {
      const next = !prev;
      if (typeof window !== "undefined") {
        window.localStorage.setItem("admin:sidebarCollapsed", next ? "1" : "0");
      }
      return next;
    });
  };
  const { toast } = useToast();

  // Fetch channel name + logo for the sidebar header.
  const settingsAsync = useAsync<{
    channelName: string;
    channelLogo: string;
  }>("/api/settings");

  // Note: the `dark` class + `colorScheme: dark` are now applied server-side
  // on <html> in src/app/layout.tsx (the entire app is dark-themed), so this
  // component no longer needs a useEffect to toggle dark mode — this also
  // eliminates the previous hydration mismatch warning.

  const channelName = settingsAsync.data?.channelName ?? "Canal Nova";
  const channelLogo = settingsAsync.data?.channelLogo ?? "CN";

  const handleSetView = (v: AdminView) => {
    setView(v);
    setMobileOpen(false);
  };

  const currentNav = NAV.find((n) => n.id === view);

  return (
    <div className="dark h-screen w-screen overflow-hidden bg-zinc-950 text-zinc-100">
      <div className="flex h-full w-full">
        {/* Desktop sidebar */}
        <aside className={cn(
          "hidden shrink-0 border-r border-zinc-800/80 transition-[width] duration-200 md:block",
          collapsed ? "w-16" : "w-60"
        )}>
          <SidebarContent
            view={view}
            setView={handleSetView}
            channelName={channelName}
            channelLogo={channelLogo}
            collapsed={collapsed}
          />
        </aside>

        {/* Mobile sidebar (Sheet) */}
        <Sheet open={mobileOpen} onOpenChange={setMobileOpen}>
          <SheetContent side="left" className="w-64 border-zinc-800 p-0">
            <SheetTitle className="sr-only">Navegación</SheetTitle>
            <SidebarContent
              view={view}
              setView={handleSetView}
              channelName={channelName}
              channelLogo={channelLogo}
            />
          </SheetContent>
        </Sheet>

        {/* Main area */}
        <div className="flex min-w-0 flex-1 flex-col overflow-hidden">
          {/* Top bar */}
          <header className="flex h-14 shrink-0 items-center gap-3 border-b border-zinc-800/80 bg-zinc-950/95 px-3 backdrop-blur sm:px-4">
            {/* Mobile hamburger */}
            <Sheet open={mobileOpen} onOpenChange={setMobileOpen}>
              <SheetTrigger asChild>
                <Button
                  variant="ghost"
                  size="icon"
                  className="text-zinc-300 hover:bg-zinc-800 hover:text-zinc-100 md:hidden"
                  aria-label="Abrir menú"
                >
                  <Menu className="size-5" />
                </Button>
              </SheetTrigger>
            </Sheet>

            {/* Desktop sidebar collapse toggle */}
            <Button
              variant="ghost"
              size="icon"
              className="hidden text-zinc-400 hover:bg-zinc-800 hover:text-zinc-100 md:inline-flex"
              onClick={toggleCollapsed}
              aria-label={collapsed ? "Expandir sidebar" : "Colapsar sidebar"}
              title={collapsed ? "Expandir sidebar" : "Colapsar sidebar"}
            >
              {collapsed ? <PanelLeftOpen className="size-4" /> : <PanelLeftClose className="size-4" />}
            </Button>

            <div className="flex min-w-0 items-center gap-2.5">
              {currentNav && (
                <currentNav.icon className="size-5 shrink-0 text-amber-400" />
              )}
              <h1 className="truncate text-sm font-semibold text-zinc-100 sm:text-base">
                {currentNav?.label ?? "Dashboard"}
              </h1>
            </div>

            <div className="ml-auto flex items-center gap-2">
              <Button
                variant="ghost"
                size="icon"
                className="hidden text-zinc-400 hover:bg-zinc-800 hover:text-zinc-100 sm:inline-flex"
                onClick={() => {
                  settingsAsync.refresh();
                  toast({ title: "Sincronizando…" });
                }}
                aria-label="Sincronizar"
              >
                <RefreshCw className="size-4" />
              </Button>
              <LiveClock />
            </div>
          </header>

          {/* Module area */}
          <main className="min-h-0 flex-1 overflow-hidden p-3 sm:p-4">
            <AnimatePresence mode="wait">
              <motion.div
                key={view}
                initial={{ opacity: 0, y: 6 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -4 }}
                transition={{ duration: 0.16, ease: "easeOut" }}
                className="h-full min-h-0"
              >
                {view === "dashboard" && <Dashboard onJumpToSchedule={() => setView("schedule")} />}
                {view === "media" && <MediaLibrary />}
                {view === "schedule" && <ScheduleGrid />}
                {view === "adbreaks" && <AdBreaks />}
                {view === "avances" && <AvancesModule />}
                {view === "settings" && <SettingsModule />}
              </motion.div>
            </AnimatePresence>
          </main>
        </div>
      </div>
    </div>
  );
}
