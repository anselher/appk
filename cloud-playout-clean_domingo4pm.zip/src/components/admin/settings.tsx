"use client";

import { useEffect, useState } from "react";
import { Save, Tv, Monitor, Radio, Calendar, MessageSquare, Layers, Globe, HardDrive, Cpu, Video, CheckCircle, AlertCircle } from "lucide-react";
import { cn } from "@/lib/utils";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { useAsync, Spinner } from "./shared";
import type { ChannelSettings, Asset } from "@/lib/types";

function FieldRow({
  icon: Icon,
  label,
  hint,
  children,
}: {
  icon: React.ComponentType<{ className?: string }>;
  label: string;
  hint?: string;
  children: React.ReactNode;
}) {
  return (
    <div className="grid grid-cols-1 gap-2 border-b border-zinc-800/60 px-4 py-3 transition-colors last:border-0 hover:bg-zinc-800/20 sm:grid-cols-[260px_1fr] sm:items-center">
      <div className="flex items-start gap-2.5">
        <Icon className="mt-0.5 size-4 shrink-0 text-zinc-500" />
        <div>
          <div className="text-sm font-medium text-zinc-200">{label}</div>
          {hint && <div className="text-[11px] text-zinc-500">{hint}</div>}
        </div>
      </div>
      <div>{children}</div>
    </div>
  );
}

// Polished card header with a colored icon container, gradient background,
// and a one-line description. Each settings section gets a distinct accent
// color so sections are distinguishable at a glance.
function SectionHeader({
  icon: Icon,
  title,
  description,
  iconClass,
  glowClass,
}: {
  icon: React.ComponentType<{ className?: string }>;
  title: string;
  description: string;
  iconClass: string;
  glowClass: string;
}) {
  return (
    <div className={cn("relative flex items-center gap-2.5 overflow-hidden border-b border-zinc-800 bg-gradient-to-r px-4 py-2.5", glowClass)}>
      <div className={cn("flex size-7 items-center justify-center rounded-md bg-zinc-800/70", iconClass)}>
        <Icon className="size-3.5" />
      </div>
      <div className="min-w-0">
        <div className="text-sm font-semibold text-zinc-100">{title}</div>
        <div className="text-[11px] text-zinc-500">{description}</div>
      </div>
    </div>
  );
}

export function SettingsModule() {
  const settingsAsync = useAsync<ChannelSettings>("/api/settings");
  const fillersAsync = useAsync<Asset[]>("/api/fillers");
  const { toast } = useToast();

  const [form, setForm] = useState<ChannelSettings | null>(null);
  const [saving, setSaving] = useState(false);
  const [dirty, setDirty] = useState(false);
  const [ffmpegStatus, setFfmpegStatus] = useState<{ ok: boolean; version?: string; error?: string } | null>(null);
  const [checkingFfmpeg, setCheckingFfmpeg] = useState(false);

  useEffect(() => {
    if (settingsAsync.data) {
      setForm(settingsAsync.data);
      setDirty(false);
    }
  }, [settingsAsync.data]);

  const update = <K extends keyof ChannelSettings>(
    key: K,
    value: ChannelSettings[K]
  ) => {
    setForm((prev) => (prev ? { ...prev, [key]: value } : prev));
    setDirty(true);
  };

  const save = async () => {
    if (!form) return;
    setSaving(true);
    try {
      const r = await fetch(`/api/settings`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      if (!r.ok) throw new Error(await r.text());
      const updated = (await r.json()) as ChannelSettings;
      setForm(updated);
      setDirty(false);
      toast({ title: "Ajustes guardados", description: "Configuración del canal actualizada." });
      await settingsAsync.refresh();
    } catch (e) {
      toast({
        title: "Error al guardar",
        description: e instanceof Error ? e.message : "internal error",
        variant: "destructive",
      });
    } finally {
      setSaving(false);
    }
  };

  if (!form) {
    return (
      <div className="flex h-full items-center justify-center gap-2 text-zinc-500">
        <Spinner /> Cargando ajustes…
      </div>
    );
  }

  // Check FFmpeg availability.
  const checkFfmpeg = async () => {
    setCheckingFfmpeg(true);
    setFfmpegStatus(null);
    try {
      // If the form has a custom ffmpeg path, save it first so the check uses it.
      if (form.ffmpegPath !== undefined) {
        await fetch("/api/settings", {
          method: "PATCH",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ ffmpegPath: form.ffmpegPath }),
        });
      }
      const r = await fetch("/api/settings/ffmpeg-check", { cache: "no-store" });
      const result = await r.json();
      setFfmpegStatus(result);
      if (result.ok) {
        toast({ title: "FFmpeg detectado", description: result.version });
      } else {
        toast({ title: "FFmpeg no disponible", description: result.error, variant: "destructive" });
      }
    } catch (e) {
      setFfmpegStatus({ ok: false, error: e instanceof Error ? e.message : "error" });
    } finally {
      setCheckingFfmpeg(false);
    }
  };

  return (
    <div className="grid h-full min-h-0 grid-cols-1 gap-3 overflow-y-auto custom-scrollbar lg:grid-cols-2">
      {/* Channel identity */}
      <Card className="flex flex-col border-zinc-800 bg-zinc-900/60 p-0">
        <SectionHeader
          icon={Tv}
          title="Identidad del canal"
          description="Nombre, logo y zona horaria"
          iconClass="text-amber-400"
          glowClass="from-amber-500/10"
        />
        <div className="divide-y divide-zinc-800/60">
          <FieldRow
            icon={Tv}
            label="Nombre del canal"
            hint="Mostrado en el logo del reproductor"
          >
            <Input
              value={form.channelName}
              onChange={(e) => update("channelName", e.target.value)}
              className="h-8 border-zinc-700 bg-zinc-950 text-sm text-zinc-100"
            />
          </FieldRow>
          <FieldRow
            icon={Tv}
            label="Logo (emoji o texto corto)"
            hint="1-2 caracteres, ej: 🔴 o CN"
          >
            <Input
              value={form.channelLogo}
              onChange={(e) => update("channelLogo", e.target.value)}
              maxLength={4}
              className="h-8 w-24 border-zinc-700 bg-zinc-950 text-center text-lg text-zinc-100"
            />
          </FieldRow>
          <FieldRow
            icon={Globe}
            label="Zona horaria (offset UTC)"
            hint="Horas de diferencia respecto a UTC. Venezuela = -4. Cámbialo si tu servidor está en otra zona."
          >
            <div className="flex items-center gap-2">
              <Input
                type="number"
                step="0.5"
                min="-12"
                max="14"
                value={form.timezoneOffset ?? "-4"}
                onChange={(e) => update("timezoneOffset", e.target.value)}
                className="h-8 w-24 border-zinc-700 bg-zinc-950 font-mono text-sm text-zinc-100"
              />
              <span className="text-xs text-zinc-500">
                GMT{parseFloat(form.timezoneOffset ?? "-4") >= 0 ? "+" : ""}{form.timezoneOffset ?? "-4"}
              </span>
            </div>
          </FieldRow>
        </div>
      </Card>

      {/* Player & EPG */}
      <Card className="flex flex-col border-zinc-800 bg-zinc-900/60 p-0">
        <SectionHeader
          icon={Monitor}
          title="Reproductor y EPG"
          description="Posición, sincronización y guía"
          iconClass="text-sky-400"
          glowClass="from-sky-500/10"
        />
        <div className="divide-y divide-zinc-800/60">
          <FieldRow
            icon={Monitor}
            label="Lado del reproductor"
            hint="Posición del video en el visor"
          >
            <Select
              value={form.playerSide}
              onValueChange={(v) =>
                update("playerSide", v as "left" | "right")
              }
            >
              <SelectTrigger className="h-8 w-40 border-zinc-700 bg-zinc-950 text-sm text-zinc-100">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="border-zinc-700 bg-zinc-900 text-zinc-100">
                <SelectItem value="left">Izquierda</SelectItem>
                <SelectItem value="right">Derecha</SelectItem>
              </SelectContent>
            </Select>
          </FieldRow>
          <FieldRow
            icon={Radio}
            label="Sincronización en vivo (sin DVR)"
            hint="Todos los espectadores ven el mismo frame al mismo tiempo"
          >
            <div className="flex items-center gap-3">
              <Switch
                checked={form.liveSync}
                onCheckedChange={(v) => update("liveSync", v)}
              />
              <span className="text-xs text-zinc-400">
                {form.liveSync ? "Activado" : "Desactivado (DVR)"}
              </span>
            </div>
          </FieldRow>
          <FieldRow
            icon={Calendar}
            label="Días de anticipación en EPG"
            hint="Cuántos días futuros muestra la guía"
          >
            <Input
              type="number"
              min={1}
              max={14}
              value={form.previewDays}
              onChange={(e) =>
                update("previewDays", Number(e.target.value) || 1)
              }
              className="h-8 w-24 border-zinc-700 bg-zinc-950 font-mono text-sm text-zinc-100"
            />
          </FieldRow>
          <FieldRow
            icon={Monitor}
            label="Barra de programación (Ahora / Siguiente)"
            hint="Muestra la barra inferior en el reproductor del visor con el programa actual y el siguiente"
          >
            <div className="flex items-center gap-3">
              <Switch
                checked={form.showBroadcastTicker !== false}
                onCheckedChange={(v) => update("showBroadcastTicker", v)}
              />
              <span className="text-xs text-zinc-400">
                {form.showBroadcastTicker !== false ? "Visible" : "Oculta"}
              </span>
            </div>
          </FieldRow>
          <FieldRow
            icon={Monitor}
            label="Bloquear pausa (transmisión siempre activa)"
            hint="Cuando está activado, el espectador no puede pausar el video. Doble-click = pantalla completa. Ideal para TV lineal puro."
          >
            <div className="flex items-center gap-3">
              <Switch
                checked={form.disablePause === true}
                onCheckedChange={(v) => update("disablePause", v)}
              />
              <span className="text-xs text-zinc-400">
                {form.disablePause === true ? "Bloqueada" : "Permitida"}
              </span>
            </div>
          </FieldRow>
        </div>
      </Card>

      {/* Slate & fillers */}
      <Card className="flex flex-col border-zinc-800 bg-zinc-900/60 p-0">
        <SectionHeader
          icon={MessageSquare}
          title="Slate y relleno"
          description="Mensajes durante cortes y vacíos"
          iconClass="text-rose-400"
          glowClass="from-rose-500/10"
        />
        <div className="divide-y divide-zinc-800/60">
          <FieldRow
            icon={MessageSquare}
            label="Mensaje de slate global"
            hint="Mostrado durante cortes y planta. Usa {s} para segundos restantes."
          >
            <Textarea
              value={form.slateMessage}
              onChange={(e) => update("slateMessage", e.target.value)}
              className="min-h-16 border-zinc-700 bg-zinc-950 text-sm text-zinc-100"
            />
          </FieldRow>
          <FieldRow
            icon={Layers}
            label="Relleno de vacíos por defecto"
            hint="Activo de planta que rellena huecos en la parrilla"
          >
            <Select
              value={form.fillFillerAssetId ?? "__none__"}
              onValueChange={(v) =>
                update(
                  "fillFillerAssetId",
                  v === "__none__" ? null : v
                )
              }
            >
              <SelectTrigger className="h-8 w-full border-zinc-700 bg-zinc-950 text-sm text-zinc-100 sm:w-80">
                <SelectValue placeholder="Auto (primer filler)" />
              </SelectTrigger>
              <SelectContent className="border-zinc-700 bg-zinc-900 text-zinc-100">
                <SelectItem value="__none__">
                  Automático (primer activo de planta)
                </SelectItem>
                {(fillersAsync.data ?? []).map((f) => (
                  <SelectItem key={f.id} value={f.id}>
                    🎬 {f.title}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </FieldRow>
        </div>
      </Card>

      {/* Media storage & transcoding */}
      <Card className="flex flex-col border-zinc-800 bg-zinc-900/60 p-0">
        <SectionHeader
          icon={Video}
          title="Almacenamiento y Transcodificación"
          description="Rutas de medios y FFmpeg"
          iconClass="text-emerald-400"
          glowClass="from-emerald-500/10"
        />
        <div className="divide-y divide-zinc-800/60">
          <FieldRow
            icon={HardDrive}
            label="Ruta de almacenamiento de medios"
            hint="Donde se guardan los videos subidos y las transcodificaciones HLS. Puede ser relativa (./uploads) o absoluta (C:\videos o /var/videos)."
          >
            <Input
              value={form.mediaStoragePath ?? "./uploads"}
              onChange={(e) => update("mediaStoragePath", e.target.value)}
              className="h-8 border-zinc-700 bg-zinc-950 font-mono text-xs text-zinc-100"
              placeholder="./uploads"
            />
          </FieldRow>
          <FieldRow
            icon={Cpu}
            label="Ruta de FFmpeg (opcional)"
            hint="Deja vacío para usar FFmpeg del sistema PATH. En Windows: ruta a ffmpeg.exe"
          >
            <div className="flex gap-2">
              <Input
                value={form.ffmpegPath ?? ""}
                onChange={(e) => update("ffmpegPath", e.target.value)}
                className="h-8 border-zinc-700 bg-zinc-950 font-mono text-xs text-zinc-100"
                placeholder="/usr/bin/ffmpeg o C:\ffmpeg\bin\ffmpeg.exe"
              />
              <Button
                type="button"
                variant="outline"
                size="sm"
                className="h-8 shrink-0 gap-1.5 border-zinc-700 text-xs text-zinc-300 hover:bg-zinc-800"
                onClick={checkFfmpeg}
                disabled={checkingFfmpeg}
              >
                {checkingFfmpeg ? (
                  <Spinner className="border-amber-400 border-t-transparent" />
                ) : (
                  <Cpu className="size-3.5" />
                )}
                Probar
              </Button>
            </div>
          </FieldRow>

          {/* FFmpeg status indicator */}
          <div className="px-4 py-3">
            {ffmpegStatus ? (
              <div className={`flex items-center gap-2 rounded-md border px-3 py-2 text-xs ${
                ffmpegStatus.ok
                  ? "border-emerald-700/50 bg-emerald-950/20 text-emerald-300"
                  : "border-rose-700/50 bg-rose-950/20 text-rose-300"
              }`}>
                {ffmpegStatus.ok ? (
                  <CheckCircle className="size-4 shrink-0" />
                ) : (
                  <AlertCircle className="size-4 shrink-0" />
                )}
                <div className="min-w-0 flex-1">
                  <div className="font-medium">
                    {ffmpegStatus.ok ? "FFmpeg disponible" : "FFmpeg no disponible"}
                  </div>
                  <div className="truncate font-mono text-[10px] opacity-80">
                    {ffmpegStatus.ok ? ffmpegStatus.version : ffmpegStatus.error}
                  </div>
                </div>
              </div>
            ) : (
              <div className="flex items-center gap-2 rounded-md border border-zinc-800 bg-zinc-950/40 px-3 py-2 text-xs text-zinc-500">
                <Cpu className="size-4 shrink-0" />
                Haz clic en "Probar" para verificar que FFmpeg está instalado.
              </div>
            )}
          </div>

          {/* Help text */}
          <div className="px-4 py-3">
            <div className="rounded-md border border-sky-500/20 bg-sky-950/10 px-3 py-2 text-[11px] text-sky-300/80">
              <strong>Instalación de FFmpeg:</strong><br />
              • <strong>Windows:</strong> Descarga desde ffmpeg.org, extrae y pega la ruta a ffmpeg.exe arriba.<br />
              • <strong>Linux (Debian/Ubuntu):</strong> <code className="font-mono">sudo apt install ffmpeg</code><br />
              • <strong>macOS:</strong> <code className="font-mono">brew install ffmpeg</code><br />
              Los videos se transcodifican a ABR HLS adaptativo (sin upscaling) y se generan miniaturas automáticas.
            </div>
          </div>
        </div>
      </Card>

      {/* Save bar */}
      <Card className="flex flex-col border-zinc-800 bg-zinc-900/60 p-0 lg:col-span-2">
        <div className="flex items-center justify-between gap-2 px-4 py-3">
          <div className="flex items-center gap-2">
            {dirty ? (
              <span className="flex items-center gap-1.5 rounded-md border border-amber-500/40 bg-amber-500/10 px-2 py-1 text-[11px] font-medium text-amber-300">
                <span className="relative flex size-1.5">
                  <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-amber-400 opacity-75" />
                  <span className="relative inline-flex size-1.5 rounded-full bg-amber-400" />
                </span>
                Cambios sin guardar
              </span>
            ) : (
              <span className="flex items-center gap-1.5 text-[11px] text-zinc-500">
                <CheckCircle className="size-3.5 text-emerald-500/70" />
                Todo guardado
              </span>
            )}
          </div>
          <div className="flex items-center gap-2">
            <Button
              variant="ghost"
              size="sm"
              className="text-zinc-400 hover:bg-zinc-800 hover:text-zinc-100"
              onClick={() => {
                if (settingsAsync.data) setForm(settingsAsync.data);
                setDirty(false);
              }}
              disabled={!dirty}
            >
              Descartar
            </Button>
            <Button
              size="sm"
              onClick={save}
              disabled={saving || !dirty}
              className="gap-1.5 bg-amber-500 text-zinc-950 hover:bg-amber-400 disabled:opacity-50"
            >
              {saving ? (
                <Spinner className="border-zinc-950 border-t-transparent" />
              ) : (
                <Save className="size-3.5" />
              )}
              Guardar cambios
            </Button>
          </div>
        </div>
      </Card>
    </div>
  );
}
