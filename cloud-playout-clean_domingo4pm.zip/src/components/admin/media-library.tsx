"use client";

import { useMemo, useState } from "react";
import { Plus, Pencil, Trash2, Search, Upload, Film, CalendarCheck, Video, Play } from "lucide-react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import {
  useAsync,
  Thumbnail,
  CategoryBadge,
  Spinner,
  secondsToMs,
  msToHMMSS,
} from "./shared";
import { UploadDialog } from "./upload-dialog";
import { AssetPreviewDialog } from "./asset-preview-dialog";
import type { Asset, AssetCategory } from "@/lib/types";

type FilterTab = "all" | "PROGRAM" | "FILLER" | "SPOT" | "BUMPER";

interface AssetForm {
  title: string;
  originalFilename: string;
  category: AssetCategory;
  durationSec: string; // seconds (user input) → converted to ms
  hlsUrl: string;
  thumbnailUrl: string;
  description: string;
  resolutionVariants: string;
}

const EMPTY_FORM: AssetForm = {
  title: "",
  originalFilename: "",
  category: "PROGRAM",
  durationSec: "",
  hlsUrl: "",
  thumbnailUrl: "🎬",
  description: "",
  resolutionVariants: "240p,480p,720p,1080p",
};

export function MediaLibrary() {
  const { data, loading, refresh } = useAsync<Asset[]>("/api/assets");
  // Usage stats: { [assetId]: { scheduledCount, lastScheduledDate } }
  const statsAsync = useAsync<Record<string, { scheduledCount: number; lastScheduledDate: string | null }>>("/api/assets/stats");
  const refreshAll = async () => {
    await Promise.all([refresh(), statsAsync.refresh()]);
  };
  const { toast } = useToast();

  const [filter, setFilter] = useState<FilterTab>("all");
  const [query, setQuery] = useState("");

  const [uploadOpen, setUploadOpen] = useState(false);
  const [realUploadOpen, setRealUploadOpen] = useState(false);
  const [editing, setEditing] = useState<Asset | null>(null);
  const [deleting, setDeleting] = useState<Asset | null>(null);
  const [previewing, setPreviewing] = useState<Asset | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [transcoding, setTranscoding] = useState(false);
  const [form, setForm] = useState<AssetForm>(EMPTY_FORM);

  const [sortBy, setSortBy] = useState<"recent" | "title" | "duration">("recent");

  const filtered = useMemo(() => {
    let list = data ?? [];
    if (filter !== "all") list = list.filter((a) => a.category === filter);
    if (query.trim()) {
      const q = query.trim().toLowerCase();
      list = list.filter(
        (a) =>
          a.title.toLowerCase().includes(q) ||
          a.originalFilename.toLowerCase().includes(q) ||
          (a.description ?? "").toLowerCase().includes(q)
      );
    }
    // Sort
    list = [...list].sort((a, b) => {
      if (sortBy === "title") return a.title.localeCompare(b.title);
      if (sortBy === "duration") return b.durationMs - a.durationMs;
      // recent (default): newest first
      return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
    });
    return list;
  }, [data, filter, query, sortBy]);

  const counts = useMemo(() => {
    const list = data ?? [];
    return {
      all: list.length,
      PROGRAM: list.filter((a) => a.category === "PROGRAM").length,
      FILLER: list.filter((a) => a.category === "FILLER").length,
      SPOT: list.filter((a) => a.category === "SPOT").length,
      BUMPER: list.filter((a) => a.category === "BUMPER").length,
    };
  }, [data]);

  const openUpload = () => {
    setForm(EMPTY_FORM);
    setEditing(null);
    setUploadOpen(true);
  };

  const openEdit = (a: Asset) => {
    setEditing(a);
    setForm({
      title: a.title,
      originalFilename: a.originalFilename,
      category: a.category,
      durationSec: String(a.durationMs / 1000),
      hlsUrl: a.hlsUrl,
      thumbnailUrl: a.thumbnailUrl ?? "",
      description: a.description ?? "",
      resolutionVariants: a.resolutionVariants,
    });
    setUploadOpen(true);
  };

  const closeDialog = () => {
    setUploadOpen(false);
    setEditing(null);
    setForm(EMPTY_FORM);
    setSubmitting(false);
    setTranscoding(false);
  };

  const submit = async () => {
    if (
      !form.title ||
      !form.originalFilename ||
      !form.hlsUrl ||
      !form.durationSec
    ) {
      toast({
        title: "Faltan campos",
        description: "Título, archivo, duración y HLS URL son obligatorios.",
        variant: "destructive",
      });
      return;
    }
    setSubmitting(true);
    const body = {
      title: form.title,
      originalFilename: form.originalFilename,
      category: form.category,
      durationMs: secondsToMs(form.durationSec),
      hlsUrl: form.hlsUrl,
      thumbnailUrl: form.thumbnailUrl || null,
      description: form.description || null,
      resolutionVariants: form.resolutionVariants,
    };
    try {
      if (editing) {
        const r = await fetch(`/api/assets/${editing.id}`, {
          method: "PATCH",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(body),
        });
        if (!r.ok) throw new Error(await r.text());
        toast({
          title: "Activo actualizado",
          description: form.title,
        });
      } else {
        // Simulate the ABR transcode pipeline.
        setTranscoding(true);
        await new Promise((r) => setTimeout(r, 1200));
        setTranscoding(false);
        const r = await fetch(`/api/assets`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(body),
        });
        if (!r.ok) throw new Error(await r.text());
        toast({
          title: "Contenido subido",
          description: `${form.title} — transcodificación completa`,
        });
      }
      await refreshAll();
      closeDialog();
    } catch (e) {
      toast({
        title: "Error",
        description: e instanceof Error ? e.message : "internal error",
        variant: "destructive",
      });
      setSubmitting(false);
      setTranscoding(false);
    }
  };

  const confirmDelete = async () => {
    if (!deleting) return;
    try {
      const r = await fetch(`/api/assets/${deleting.id}`, { method: "DELETE" });
      if (!r.ok) throw new Error(await r.text());
      toast({ title: "Activo eliminado", description: deleting.title });
      await refreshAll();
    } catch (e) {
      toast({
        title: "Error al eliminar",
        description: e instanceof Error ? e.message : "internal error",
        variant: "destructive",
      });
    } finally {
      setDeleting(null);
    }
  };

  return (
    <div className="flex h-full min-h-0 flex-col gap-3">
      {/* Toolbar */}
      <div className="flex flex-wrap items-center gap-2">
        <Tabs
          value={filter}
          onValueChange={(v) => setFilter(v as FilterTab)}
        >
          <TabsList className="h-8 bg-zinc-900">
            <TabsTrigger value="all" className="text-xs">
              Todos ({counts.all})
            </TabsTrigger>
            <TabsTrigger value="PROGRAM" className="text-xs">
              Programas ({counts.PROGRAM})
            </TabsTrigger>
            <TabsTrigger value="FILLER" className="text-xs">
              Planta ({counts.FILLER})
            </TabsTrigger>
            <TabsTrigger value="SPOT" className="text-xs">
              Spots ({counts.SPOT})
            </TabsTrigger>
            <TabsTrigger value="BUMPER" className="text-xs">
              Bumpers ({counts.BUMPER})
            </TabsTrigger>
          </TabsList>
        </Tabs>

        <div className="relative ml-auto">
          <Search className="absolute left-2.5 top-1/2 size-3.5 -translate-y-1/2 text-zinc-500" />
          <Input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Buscar por título, archivo o descripción…"
            className="h-8 w-44 rounded-md border-zinc-700 bg-zinc-900 pl-8 text-xs text-zinc-100 placeholder:text-zinc-500 sm:w-72"
          />
        </div>

        {/* Sort selector */}
        <Select value={sortBy} onValueChange={(v) => setSortBy(v as typeof sortBy)}>
          <SelectTrigger className="h-8 w-36 shrink-0 border-zinc-700 bg-zinc-900 text-xs text-zinc-300">
            <SelectValue />
          </SelectTrigger>
          <SelectContent className="border-zinc-700 bg-zinc-900 text-zinc-100">
            <SelectItem value="recent">Más recientes</SelectItem>
            <SelectItem value="title">Título (A-Z)</SelectItem>
            <SelectItem value="duration">Duración</SelectItem>
          </SelectContent>
        </Select>

        <Button
          onClick={() => setRealUploadOpen(true)}
          size="sm"
          className="h-8 gap-1.5 rounded-md bg-emerald-600 text-white hover:bg-emerald-500"
          title="Subir video desde PC o URL con transcodificación ABR automática"
        >
          <Video className="size-3.5" />
          Subir video
        </Button>
        <Button
          onClick={openUpload}
          size="sm"
          variant="outline"
          className="h-8 gap-1.5 rounded-md border-zinc-700 bg-transparent text-zinc-300 hover:bg-zinc-800"
          title="Añadir activo con HLS URL manual (para streams externos)"
        >
          <Upload className="size-3.5" />
          Añadir manual
        </Button>
      </div>

      {/* Table card */}
      <Card className="flex min-h-0 flex-1 flex-col border-zinc-800 bg-zinc-900/60 p-0">
        <div className="max-h-[calc(100vh-220px)] min-h-0 flex-1 overflow-y-auto custom-scrollbar">
          <Table>
            <TableHeader className="sticky top-0 z-10 bg-zinc-900">
              <TableRow className="border-zinc-800 hover:bg-transparent">
                <TableHead className="h-8 w-12 text-[11px] uppercase tracking-wider text-zinc-500">
                  Mini
                </TableHead>
                <TableHead className="h-8 text-[11px] uppercase tracking-wider text-zinc-500">
                  Título
                </TableHead>
                <TableHead className="h-8 text-[11px] uppercase tracking-wider text-zinc-500">
                  Archivo original
                </TableHead>
                <TableHead className="h-8 w-24 text-[11px] uppercase tracking-wider text-zinc-500">
                  Categoría
                </TableHead>
                <TableHead className="h-8 w-24 text-[11px] uppercase tracking-wider text-zinc-500">
                  Duración
                </TableHead>
                <TableHead className="h-8 w-44 text-[11px] uppercase tracking-wider text-zinc-500">
                  Variantes
                </TableHead>
                <TableHead className="h-8 w-24 text-right text-[11px] uppercase tracking-wider text-zinc-500">
                  Uso
                </TableHead>
                <TableHead className="h-8 w-20 text-right text-[11px] uppercase tracking-wider text-zinc-500">
                  Acciones
                </TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {loading && (
                <TableRow className="border-zinc-800/60">
                  <TableCell colSpan={8} className="py-10 text-center">
                    <div className="inline-flex items-center gap-2 text-zinc-500">
                      <Spinner /> Cargando activos…
                    </div>
                  </TableCell>
                </TableRow>
              )}
              {!loading && filtered.length === 0 && (
                <TableRow className="border-zinc-800/60">
                  <TableCell colSpan={8} className="py-10 text-center text-zinc-500">
                    <Film className="mx-auto mb-2 size-6 text-zinc-700" />
                    No hay activos que coincidan.
                  </TableCell>
                </TableRow>
              )}
              {filtered.map((a) => (
                <TableRow
                  key={a.id}
                  className="group border-zinc-800/60 text-zinc-200 transition-colors hover:bg-zinc-800/40"
                >
                  <TableCell className="py-2.5">
                    <button
                      onClick={() => setPreviewing(a)}
                      className="relative block rounded-md transition-transform hover:scale-105 hover:ring-2 hover:ring-amber-500/50"
                      title="Previsualizar video"
                      aria-label={`Previsualizar ${a.title}`}
                    >
                      <Thumbnail url={a.thumbnailUrl} className="size-8 text-sm ring-0" />
                      <span className="absolute inset-0 flex items-center justify-center rounded-md bg-black/50 opacity-0 transition-opacity hover:opacity-100">
                        <Play className="size-3 text-white" />
                      </span>
                    </button>
                  </TableCell>
                  <TableCell className="py-2.5 font-medium text-zinc-100">
                    <button
                      onClick={() => setPreviewing(a)}
                      className="block w-full text-left hover:text-amber-300"
                      title="Previsualizar video"
                    >
                      <div className="truncate">{a.title}</div>
                    </button>
                    {a.description && (
                      <div className="truncate text-[11px] text-zinc-500">
                        {a.description}
                      </div>
                    )}
                  </TableCell>
                  <TableCell className="py-2 font-mono text-xs text-zinc-400">
                    {a.originalFilename}
                  </TableCell>
                  <TableCell className="py-2">
                    <CategoryBadge category={a.category} />
                  </TableCell>
                  <TableCell className="py-2 font-mono text-xs tabular-nums text-zinc-300">
                    {msToHMMSS(a.durationMs)}
                  </TableCell>
                  <TableCell className="py-2">
                    <div className="flex flex-wrap gap-1">
                      {a.resolutionVariants
                        .split(",")
                        .map((v) => v.trim())
                        .filter(Boolean)
                        .map((v) => (
                          <Badge
                            key={v}
                            variant="outline"
                            className="border-zinc-700 text-[10px] font-normal text-zinc-400"
                          >
                            {v}
                          </Badge>
                        ))}
                    </div>
                  </TableCell>
                  <TableCell className="py-2 text-right">
                    {(() => {
                      const stat = statsAsync.data?.[a.id];
                      const count = stat?.scheduledCount ?? 0;
                      return (
                        <div className="inline-flex flex-col items-end gap-0.5">
                          <span
                            className={cn(
                              "inline-flex items-center gap-1 rounded-md px-1.5 py-0.5 font-mono text-xs tabular-nums",
                              count > 0
                                ? "bg-emerald-500/10 text-emerald-300"
                                : "bg-zinc-800/60 text-zinc-500"
                            )}
                            title={
                              count > 0
                                ? `Programado ${count} vez(ces) — último: ${stat?.lastScheduledDate ?? "—"}`
                                : "Nunca programado"
                            }
                          >
                            <CalendarCheck className="size-3" />
                            {count}
                          </span>
                          {count > 0 && stat?.lastScheduledDate && (
                            <span className="font-mono text-[9px] text-zinc-600">
                              {stat.lastScheduledDate}
                            </span>
                          )}
                        </div>
                      );
                    })()}
                  </TableCell>
                  <TableCell className="py-2">
                    <div className="flex justify-end gap-1">
                      <Button
                        variant="ghost"
                        size="icon"
                        className="size-7 text-zinc-400 hover:bg-zinc-800 hover:text-emerald-300"
                        onClick={() => setPreviewing(a)}
                        aria-label="Previsualizar"
                        title="Previsualizar video"
                      >
                        <Play className="size-3.5" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="size-7 text-zinc-400 hover:bg-zinc-800 hover:text-amber-300"
                        onClick={() => openEdit(a)}
                        aria-label="Editar"
                      >
                        <Pencil className="size-3.5" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="size-7 text-zinc-400 hover:bg-zinc-800 hover:text-rose-400"
                        onClick={() => setDeleting(a)}
                        aria-label="Eliminar"
                      >
                        <Trash2 className="size-3.5" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </Card>

      {/* Upload / Edit dialog */}
      <Dialog open={uploadOpen} onOpenChange={(o) => !o && closeDialog()}>
        <DialogContent className="max-h-[90vh] gap-0 overflow-y-auto custom-scrollbar border-zinc-800 bg-zinc-900 p-0 sm:max-w-lg">
          <DialogHeader className="border-b border-zinc-800 px-5 py-4">
            <DialogTitle className="text-base text-zinc-100">
              {editing ? "Editar activo" : "Subir nuevo contenido"}
            </DialogTitle>
            <DialogDescription className="text-xs text-zinc-500">
              {editing
                ? "Modifica los metadatos del activo."
                : "Los archivos se transcodifican a ABR HLS (240p–1080p)."}
            </DialogDescription>
          </DialogHeader>

          {transcoding && (
            <div className="flex items-center gap-3 border-b border-amber-500/30 bg-amber-500/10 px-5 py-3 text-xs text-amber-300">
              <Spinner className="size-4 border-amber-400 border-t-transparent" />
              <div>
                <div className="font-semibold">Transcodificando…</div>
                <div className="text-amber-300/70">
                  Generando variantes ABR HLS.
                </div>
              </div>
            </div>
          )}

          <div className="grid gap-3 px-5 py-4">
            <div className="grid gap-1.5">
              <Label className="text-xs text-zinc-400">Título *</Label>
              <Input
                value={form.title}
                onChange={(e) =>
                  setForm({ ...form, title: e.target.value })
                }
                className="h-8 border-zinc-700 bg-zinc-950 text-sm text-zinc-100"
                placeholder="Ej: Noticiero Estelar"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div className="grid gap-1.5">
                <Label className="text-xs text-zinc-400">
                  Archivo original *
                </Label>
                <Input
                  value={form.originalFilename}
                  onChange={(e) =>
                    setForm({ ...form, originalFilename: e.target.value })
                  }
                  className="h-8 border-zinc-700 bg-zinc-950 font-mono text-xs text-zinc-100"
                  placeholder="noticiero.mp4"
                />
              </div>
              <div className="grid gap-1.5">
                <Label className="text-xs text-zinc-400">Categoría</Label>
                <Select
                  value={form.category}
                  onValueChange={(v) =>
                    setForm({ ...form, category: v as AssetCategory })
                  }
                >
                  <SelectTrigger className="h-8 border-zinc-700 bg-zinc-950 text-xs text-zinc-100">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="border-zinc-700 bg-zinc-900 text-zinc-100">
                    <SelectItem value="PROGRAM">Programa</SelectItem>
                    <SelectItem value="FILLER">Planta</SelectItem>
                    <SelectItem value="SPOT">Spot</SelectItem>
                    <SelectItem value="BUMPER">Bumper</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div className="grid gap-1.5">
                <Label className="text-xs text-zinc-400">
                  Duración (segundos) *
                </Label>
                <Input
                  type="number"
                  step="0.1"
                  min="0"
                  value={form.durationSec}
                  onChange={(e) =>
                    setForm({ ...form, durationSec: e.target.value })
                  }
                  className="h-8 border-zinc-700 bg-zinc-950 font-mono text-xs text-zinc-100"
                  placeholder="1800"
                />
              </div>
              <div className="grid gap-1.5">
                <Label className="text-xs text-zinc-400">
                  Miniatura (emoji)
                </Label>
                <Input
                  value={form.thumbnailUrl}
                  onChange={(e) =>
                    setForm({ ...form, thumbnailUrl: e.target.value })
                  }
                  className="h-8 border-zinc-700 bg-zinc-950 text-sm text-zinc-100"
                  placeholder="🎬"
                  maxLength={4}
                />
              </div>
            </div>

            <div className="grid gap-1.5">
              <Label className="text-xs text-zinc-400">HLS URL *</Label>
              <Input
                value={form.hlsUrl}
                onChange={(e) =>
                  setForm({ ...form, hlsUrl: e.target.value })
                }
                className="h-8 border-zinc-700 bg-zinc-950 font-mono text-xs text-zinc-100"
                placeholder="https://…/playlist.m3u8"
              />
            </div>

            <div className="grid gap-1.5">
              <Label className="text-xs text-zinc-400">
                Variantes de resolución
              </Label>
              <Input
                value={form.resolutionVariants}
                onChange={(e) =>
                  setForm({ ...form, resolutionVariants: e.target.value })
                }
                className="h-8 border-zinc-700 bg-zinc-950 text-xs text-zinc-100"
                placeholder="240p,480p,720p,1080p"
              />
            </div>

            <div className="grid gap-1.5">
              <Label className="text-xs text-zinc-400">Descripción</Label>
              <Textarea
                value={form.description}
                onChange={(e) =>
                  setForm({ ...form, description: e.target.value })
                }
                className="min-h-16 border-zinc-700 bg-zinc-950 text-sm text-zinc-100"
                placeholder="Sinopsis o notas internas…"
              />
            </div>
          </div>

          <DialogFooter className="border-t border-zinc-800 px-5 py-3">
            <Button
              variant="ghost"
              size="sm"
              onClick={closeDialog}
              className="text-zinc-400 hover:bg-zinc-800 hover:text-zinc-100"
            >
              Cancelar
            </Button>
            <Button
              size="sm"
              onClick={submit}
              disabled={submitting}
              className="gap-1.5 bg-amber-500 text-zinc-950 hover:bg-amber-400"
            >
              {submitting && <Spinner className="border-zinc-950 border-t-transparent" />}
              {editing ? "Guardar cambios" : "Subir y transcodificar"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete confirmation */}
      <AlertDialog
        open={!!deleting}
        onOpenChange={(o) => !o && setDeleting(null)}
      >
        <AlertDialogContent className="border-zinc-800 bg-zinc-900 text-zinc-100">
          <AlertDialogHeader>
            <AlertDialogTitle className="text-base">
              Eliminar activo
            </AlertDialogTitle>
            <AlertDialogDescription className="text-zinc-400">
              ¿Seguro que deseas eliminar{" "}
              <span className="font-semibold text-zinc-200">
                {deleting?.title}
              </span>
              ? Esta acción no se puede deshacer.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="border-zinc-700 bg-transparent text-zinc-300 hover:bg-zinc-800 hover:text-zinc-100">
              Cancelar
            </AlertDialogCancel>
            <AlertDialogAction
              onClick={confirmDelete}
              className="bg-rose-600 text-white hover:bg-rose-500"
            >
              Eliminar
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Real video upload dialog (FFmpeg ABR transcode) */}
      <UploadDialog
        open={realUploadOpen}
        onOpenChange={setRealUploadOpen}
        onCompleted={refreshAll}
      />

      {/* Asset preview dialog (full video player) */}
      <AssetPreviewDialog
        asset={previewing}
        open={!!previewing}
        onClose={() => setPreviewing(null)}
      />
    </div>
  );
}
