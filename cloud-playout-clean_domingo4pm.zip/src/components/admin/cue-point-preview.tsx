"use client";

import { useEffect, useRef, useState, useCallback } from "react";
import Hls from "hls.js";
import { cn } from "@/lib/utils";
import { Play, Pause, SkipBack, SkipForward, Flag } from "lucide-react";

interface CuePointPreviewProps {
  hlsUrl: string;
  durationMs: number; // asset duration
  existingCueOffsetsMs: number[]; // existing cue points to show on the timeline
  onOffsetChange: (offsetMs: number) => void;
  selectedOffsetMs: number;
}

/**
 * Internal video preview player used inside the cue-point dialog.
 * Lets the admin scrub through a program and visually mark where the
 * commercial break should be inserted (frame-accurate cue point placement).
 *
 * Features:
 * - HLS.js adaptive streaming (same engine as the viewer).
 * - Draggable playhead + click-to-seek on the timeline.
 * - Visual markers for existing cue points (red flags).
 * - Visual marker for the in-progress cue point (amber flag).
 * - Frame-step buttons (±1s) for precise placement.
 * - "Set cue here" button that snaps the cue to the current playhead.
 */
export function CuePointPreview({
  hlsUrl,
  durationMs,
  existingCueOffsetsMs,
  onOffsetChange,
  selectedOffsetMs,
}: CuePointPreviewProps) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const hlsRef = useRef<Hls | null>(null);
  const timelineRef = useRef<HTMLDivElement>(null);
  // Capture the initial selected offset so we can seek to it on load
  // without re-running the HLS loader effect when it changes.
  const initialOffsetRef = useRef(selectedOffsetMs);

  const [ready, setReady] = useState(false);
  const [playing, setPlaying] = useState(false);
  const [currentSec, setCurrentSec] = useState(0);
  const [durationSec, setDurationSec] = useState(durationMs / 1000);
  const [dragging, setDragging] = useState(false);

  // Load HLS source.
  useEffect(() => {
    const video = videoRef.current;
    if (!video || !hlsUrl) return;

    if (hlsRef.current) {
      hlsRef.current.destroy();
      hlsRef.current = null;
    }

    if (Hls.isSupported()) {
      const hls = new Hls({
        enableWorker: true,
        lowLatencyMode: false,
        startLevel: -1,
        maxBufferLength: 10,
      });
      hlsRef.current = hls;
      hls.loadSource(hlsUrl);
      hls.attachMedia(video);
      hls.on(Hls.Events.MANIFEST_PARSED, () => {
        setReady(true);
        setDurationSec(video.duration || durationMs / 1000);
        // Seek to current selected offset to start preview.
        const startSec = Math.min(
          (initialOffsetRef.current / 1000) || 0,
          (video.duration || durationMs / 1000) - 1
        );
        if (Number.isFinite(startSec) && startSec > 0) {
          video.currentTime = Math.max(0, startSec);
        }
      });
      hls.on(Hls.Events.ERROR, (_e, data) => {
        if (data.fatal) {
          if (data.type === Hls.ErrorTypes.NETWORK_ERROR) hls.startLoad();
          else if (data.type === Hls.ErrorTypes.MEDIA_ERROR) hls.recoverMediaError();
        }
      });
    } else if (video.canPlayType("application/vnd.apple.mpegurl")) {
      video.src = hlsUrl;
      const onMeta = () => {
        setReady(true);
        setDurationSec(video.duration || durationMs / 1000);
        const startSec = Math.min(
          (initialOffsetRef.current / 1000) || 0,
          (video.duration || durationMs / 1000) - 1
        );
        if (Number.isFinite(startSec) && startSec > 0) {
          video.currentTime = Math.max(0, startSec);
        }
      };
      video.addEventListener("loadedmetadata", onMeta, { once: true });
    }

    return () => {
      if (hlsRef.current) {
        hlsRef.current.destroy();
        hlsRef.current = null;
      }
    };
  }, [hlsUrl, durationMs]);

  // Track playhead.
  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;
    const onTime = () => {
      if (!dragging) setCurrentSec(video.currentTime);
    };
    const onPlay = () => setPlaying(true);
    const onPause = () => setPlaying(false);
    const onLoaded = () => setDurationSec(video.duration || durationMs / 1000);
    video.addEventListener("timeupdate", onTime);
    video.addEventListener("play", onPlay);
    video.addEventListener("pause", onPause);
    video.addEventListener("loadedmetadata", onLoaded);
    return () => {
      video.removeEventListener("timeupdate", onTime);
      video.removeEventListener("play", onPlay);
      video.removeEventListener("pause", onPause);
      video.removeEventListener("loadedmetadata", onLoaded);
    };
  }, [dragging, durationMs]);

  const togglePlay = useCallback(() => {
    const v = videoRef.current;
    if (!v) return;
    if (v.paused) void v.play().catch(() => {});
    else v.pause();
  }, []);

  const stepFrame = useCallback((deltaSec: number) => {
    const v = videoRef.current;
    if (!v) return;
    v.pause();
    const next = Math.max(0, Math.min((v.duration || durationSec) - 0.05, v.currentTime + deltaSec));
    v.currentTime = next;
    setCurrentSec(next);
  }, [durationSec]);

  // Click / drag on timeline to seek.
  const seekToClientX = useCallback((clientX: number) => {
    const tl = timelineRef.current;
    const v = videoRef.current;
    if (!tl || !v) return;
    const rect = tl.getBoundingClientRect();
    const ratio = Math.max(0, Math.min(1, (clientX - rect.left) / rect.width));
    const target = ratio * (v.duration || durationSec);
    v.currentTime = target;
    setCurrentSec(target);
  }, [durationSec]);

  const onMouseDownTimeline = (e: React.MouseEvent) => {
    setDragging(true);
    seekToClientX(e.clientX);
  };

  useEffect(() => {
    if (!dragging) return;
    const onMove = (e: MouseEvent) => seekToClientX(e.clientX);
    const onUp = () => setDragging(false);
    window.addEventListener("mousemove", onMove);
    window.addEventListener("mouseup", onUp);
    return () => {
      window.removeEventListener("mousemove", onMove);
      window.removeEventListener("mouseup", onUp);
    };
  }, [dragging, seekToClientX]);

  // Set cue at current playhead.
  const setCueHere = useCallback(() => {
    const ms = Math.round(currentSec * 1000);
    onOffsetChange(ms);
  }, [currentSec, onOffsetChange]);

  // Format seconds as HH:MM:SS.mmm (frame-accurate display).
  const fmt = (s: number) => {
    const total = Math.max(0, s);
    const h = Math.floor(total / 3600);
    const m = Math.floor((total % 3600) / 60);
    const sec = Math.floor(total % 60);
    const ms = Math.round((total - Math.floor(total)) * 1000);
    const base = `${String(m).padStart(2, "0")}:${String(sec).padStart(2, "0")}`;
    return h > 0 ? `${String(h).padStart(2, "0")}:${base}.${String(ms).padStart(3, "0")}` : `${base}.${String(ms).padStart(3, "0")}`;
  };

  const playheadPct = durationSec > 0 ? Math.min(100, (currentSec / durationSec) * 100) : 0;
  const selectedPct = durationSec > 0 ? Math.min(100, (selectedOffsetMs / 1000 / durationSec) * 100) : 0;

  return (
    <div className="overflow-hidden rounded-lg border border-zinc-800 bg-zinc-950">
      {/* Video element */}
      <div className="relative aspect-video w-full bg-black">
        <video
          ref={videoRef}
          className="h-full w-full object-contain"
          playsInline
          onClick={togglePlay}
        />
        {!ready && (
          <div className="absolute inset-0 flex items-center justify-center bg-black/60">
            <div className="h-8 w-8 animate-spin rounded-full border-2 border-zinc-700 border-t-amber-400" />
          </div>
        )}
        {/* Time display overlay */}
        <div className="absolute right-2 top-2 rounded bg-black/70 px-2 py-0.5 font-mono text-[11px] tabular-nums text-amber-300 backdrop-blur">
          {fmt(currentSec)} / {fmt(durationSec)}
        </div>
        {playing && (
          <div className="absolute left-2 top-2 flex items-center gap-1 rounded bg-black/70 px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider text-emerald-400 backdrop-blur">
            <span className="size-1.5 animate-pulse rounded-full bg-emerald-400" />
            Preview
          </div>
        )}
      </div>

      {/* Timeline with cue markers */}
      <div className="border-t border-zinc-800 bg-zinc-900/60 px-3 py-2">
        <div
          ref={timelineRef}
          onMouseDown={onMouseDownTimeline}
          className="relative h-9 cursor-pointer select-none rounded-md border border-zinc-800 bg-zinc-950"
        >
          {/* Progress fill */}
          <div
            className="absolute inset-y-0 left-0 rounded-l-md bg-amber-500/20"
            style={{ width: `${playheadPct}%` }}
          />
          {/* Existing cue point markers (red flags) */}
          {existingCueOffsetsMs.map((ms, i) => {
            const pct = durationSec > 0 ? Math.min(100, (ms / 1000 / durationSec) * 100) : 0;
            return (
              <div
                key={i}
                className="absolute top-0 bottom-0 w-0.5 bg-rose-500/80"
                style={{ left: `${pct}%` }}
                title={`Cue existente @ ${fmt(ms / 1000)}`}
              >
                <div className="absolute -top-0.5 -translate-x-1/2 text-rose-400">
                  <Flag className="size-3 fill-rose-500/50" />
                </div>
              </div>
            );
          })}
          {/* Selected cue marker (amber flag — larger) */}
          {selectedOffsetMs > 0 && (
            <div
              className="absolute top-0 bottom-0 w-0.5 bg-amber-400 shadow-[0_0_4px] shadow-amber-400/60"
              style={{ left: `${selectedPct}%` }}
            >
              <div className="absolute -top-0.5 -translate-x-1/2 text-amber-300">
                <Flag className="size-3.5 fill-amber-400" />
              </div>
            </div>
          )}
          {/* Playhead */}
          <div
            className="absolute top-0 bottom-0 w-0.5 bg-white shadow-[0_0_3px] shadow-white/70"
            style={{ left: `${playheadPct}%` }}
          >
            <div className="absolute -top-1 left-1/2 size-2 -translate-x-1/2 rounded-full bg-white" />
          </div>
        </div>
        {/* Time ticks */}
        <div className="mt-1 flex justify-between font-mono text-[9px] tabular-nums text-zinc-600">
          <span>00:00</span>
          <span>{fmt(durationSec / 4)}</span>
          <span>{fmt(durationSec / 2)}</span>
          <span>{fmt((durationSec * 3) / 4)}</span>
          <span>{fmt(durationSec)}</span>
        </div>
      </div>

      {/* Controls */}
      <div className="flex items-center gap-2 border-t border-zinc-800 bg-zinc-900/80 px-3 py-2">
        <button
          onClick={() => stepFrame(-1)}
          className="flex size-8 items-center justify-center rounded-md bg-zinc-800 text-zinc-300 transition-colors hover:bg-zinc-700"
          aria-label="Retroceder 1s"
          title="Retroceder 1s (frame step)"
        >
          <SkipBack className="size-3.5" />
        </button>
        <button
          onClick={togglePlay}
          className="flex size-9 items-center justify-center rounded-md bg-amber-500 text-zinc-950 transition-colors hover:bg-amber-400"
          aria-label={playing ? "Pausar" : "Reproducir"}
        >
          {playing ? (
            <Pause className="size-4" />
          ) : (
            <Play className="ml-0.5 size-4" />
          )}
        </button>
        <button
          onClick={() => stepFrame(1)}
          className="flex size-8 items-center justify-center rounded-md bg-zinc-800 text-zinc-300 transition-colors hover:bg-zinc-700"
          aria-label="Avanzar 1s"
          title="Avanzar 1s (frame step)"
        >
          <SkipForward className="size-3.5" />
        </button>

        <div className="ml-1 flex-1 truncate font-mono text-[11px] tabular-nums text-zinc-400">
          Playhead: <span className="text-zinc-200">{fmt(currentSec)}</span>
        </div>

        <button
          onClick={setCueHere}
          className={cn(
            "flex items-center gap-1.5 rounded-md px-3 py-1.5 text-xs font-semibold transition-colors",
            "bg-amber-500 text-zinc-950 hover:bg-amber-400"
          )}
          title="Fijar corte en el playhead actual"
        >
          <Flag className="size-3.5" />
          Fijar corte aquí
        </button>
      </div>

      {/* Helper text */}
      <div className="border-t border-zinc-800/60 bg-zinc-900/40 px-3 py-1.5 text-[10px] text-zinc-500">
        Haz click en la línea de tiempo para navegar · Usa los botones ±1s para
        ajuste fino · &quot;Fijar corte aquí&quot; establece el punto exacto del playhead.
      </div>
    </div>
  );
}
