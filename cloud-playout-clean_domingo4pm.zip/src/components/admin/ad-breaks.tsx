"use client";

import { useEffect, useMemo, useState } from "react";
import {
  DndContext,
  closestCenter,
  KeyboardSensor,
  PointerSensor,
  useSensor,
  useSensors,
  type DragEndEvent,
} from "@dnd-kit/core";
import {
  arrayMove,
  SortableContext,
  sortableKeyboardCoordinates,
  useSortable,
  verticalListSortingStrategy,
} from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";
import {
  Plus,
  Trash2,
  GripVertical,
  Megaphone,
  Check,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import {
  useAsync,
  Thumbnail,
  Spinner,
  msToHMMSS,
} from "./shared";
import type { AdBreak, AdBreakEntry, Asset } from "@/lib/types";

// ---- Sortable entry row ----
function SortableEntry({
  entry,
  onDelete,
}: {
  entry: AdBreakEntry;
  onDelete: () => void;
}) {
  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
    isDragging,
  } = useSortable({ id: entry.id });

  return (
    <div
      ref={setNodeRef}
      style={{
        transform: CSS.Transform.toString(transform),
        transition,
      }}
      className={cn(
        "flex items-center gap-2 rounded-md border border-zinc-800 bg-zinc-900/80 px-2 py-1.5",
        isDragging && "z-10 border-amber-500/50 opacity-80 shadow-lg"
      )}
    >
      <button
        {...attributes}
        {...listeners}
        className="cursor-grab text-zinc-500 hover:text-zinc-300 active:cursor-grabbing"
        aria-label="Arrastrar para reordenar"
      >
        <GripVertical className="size-4" />
      </button>
      <Thumbnail url={entry.asset.thumbnailUrl} className="size-8 text-sm" />
      <div className="min-w-0 flex-1">
        <div className="truncate text-sm text-zinc-100">{entry.asset.title}</div>
        <div className="font-mono text-[10px] tabular-nums text-zinc-500">
          {msToHMMSS(entry.asset.durationMs)}
        </div>
      </div>
      <Button
        variant="ghost"
        size="icon"
        className="size-7 text-zinc-500 hover:bg-zinc-800 hover:text-rose-400"
        onClick={onDelete}
        aria-label="Eliminar spot"
      >
        <Trash2 className="size-3.5" />
      </Button>
    </div>
  );
}

// ---- Pod (entries list) ----
function PodList({
  adBreakId,
  entries,
  onReordered,
  onDeleteEntry,
}: {
  adBreakId: string;
  entries: AdBreakEntry[];
  onReordered: () => void;
  onDeleteEntry: (entryId: string) => void;
}) {
  const [items, setItems] = useState<AdBreakEntry[]>(entries);
  const sensors = useSensors(
    useSensor(PointerSensor, { activationConstraint: { distance: 3 } }),
    useSensor(KeyboardSensor, {
      coordinateGetter: sortableKeyboardCoordinates,
    })
  );

  // Re-sync when the server data changes.
  useEffect(() => {
    setItems(entries);
  }, [entries]);

  const handleDragEnd = async (e: DragEndEvent) => {
    const { active, over } = e;
    if (!over || active.id === over.id) return;
    const oldIdx = items.findIndex((i) => i.id === active.id);
    const newIdx = items.findIndex((i) => i.id === over.id);
    if (oldIdx < 0 || newIdx < 0) return;
    const next = arrayMove(items, oldIdx, newIdx);
    setItems(next);
    try {
      const r = await fetch(`/api/adbreaks/${adBreakId}/entries`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ order: next.map((i) => i.id) }),
      });
      if (!r.ok) throw new Error(await r.text());
      onReordered();
    } catch {
      // revert on failure
      setItems(entries);
    }
  };

  if (items.length === 0) {
    return (
      <div className="rounded-md border border-dashed border-zinc-800 bg-zinc-950/40 px-4 py-8 text-center text-xs text-zinc-600">
        Sin comerciales en este bloque. Añade spots desde abajo.
      </div>
    );
  }

  return (
    <DndContext
      sensors={sensors}
      collisionDetection={closestCenter}
      onDragEnd={handleDragEnd}
    >
      <SortableContext
        items={items.map((i) => i.id)}
        strategy={verticalListSortingStrategy}
      >
        <div className="space-y-1.5">
          {items.map((entry) => (
            <SortableEntry
              key={entry.id}
              entry={entry}
              onDelete={() => onDeleteEntry(entry.id)}
            />
          ))}
        </div>
      </SortableContext>
    </DndContext>
  );
}

export function AdBreaks() {
  const breaksAsync = useAsync<AdBreak[]>("/api/adbreaks");
  const spotsAsync = useAsync<Asset[]>(`/api/assets?category=SPOT`);
  const { toast } = useToast();

  const breaks = breaksAsync.data ?? [];
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const selected = useMemo(
    () => breaks.find((b) => b.id === selectedId) ?? null,
    [breaks, selectedId]
  );

  // Auto-select the first ad break on load.
  useEffect(() => {
    if (!selectedId && breaks.length > 0) setSelectedId(breaks[0].id);
  }, [breaks, selectedId]);

  // --- Create ad break dialog ---
  const [createOpen, setCreateOpen] = useState(false);
  const [createForm, setCreateForm] = useState({
    name: "",
    slateMessage: "",
    showSlate: true,
  });
  const [creating, setCreating] = useState(false);

  const submitCreate = async () => {
    if (!createForm.name) {
      toast({ title: "Nombre obligatorio", variant: "destructive" });
      return;
    }
    setCreating(true);
    try {
      const r = await fetch(`/api/adbreaks`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: createForm.name,
          slateMessage: createForm.slateMessage || null,
          showSlate: createForm.showSlate,
        }),
      });
      if (!r.ok) throw new Error(await r.text());
      const created = (await r.json()) as AdBreak;
      toast({ title: "Bloque creado", description: createForm.name });
      await breaksAsync.refresh();
      setSelectedId(created.id);
      setCreateOpen(false);
      setCreateForm({ name: "", slateMessage: "", showSlate: true });
    } catch (e) {
      toast({
        title: "Error",
        description: e instanceof Error ? e.message : "internal error",
        variant: "destructive",
      });
    } finally {
      setCreating(false);
    }
  };

  // --- Editable fields on selected ad break ---
  const [editName, setEditName] = useState("");
  const [editSlate, setEditSlate] = useState("");
  const [editShow, setEditShow] = useState(true);
  const [editing, setEditing] = useState(false);

  useEffect(() => {
    if (selected) {
      setEditName(selected.name);
      setEditSlate(selected.slateMessage ?? "");
      setEditShow(selected.showSlate);
      setEditing(false);
    }
  }, [selected]);

  const saveEdits = async () => {
    if (!selected) return;
    setEditing(true);
    try {
      const r = await fetch(`/api/adbreaks/${selected.id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: editName,
          slateMessage: editSlate || null,
          showSlate: editShow,
        }),
      });
      if (!r.ok) throw new Error(await r.text());
      toast({ title: "Bloque actualizado" });
      await breaksAsync.refresh();
    } catch (e) {
      toast({
        title: "Error",
        description: e instanceof Error ? e.message : "internal error",
        variant: "destructive",
      });
    } finally {
      setEditing(false);
    }
  };

  // --- Add entry dialog ---
  const [addEntryOpen, setAddEntryOpen] = useState(false);
  const [addEntryAssetId, setAddEntryAssetId] = useState("");
  const [addingEntry, setAddingEntry] = useState(false);

  const openAddEntry = () => {
    setAddEntryAssetId(spotsAsync.data?.[0]?.id ?? "");
    setAddEntryOpen(true);
  };

  const submitAddEntry = async () => {
    if (!selected || !addEntryAssetId) {
      toast({ title: "Selecciona un spot", variant: "destructive" });
      return;
    }
    setAddingEntry(true);
    try {
      const r = await fetch(`/api/adbreaks/${selected.id}/entries`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ assetId: addEntryAssetId }),
      });
      if (!r.ok) throw new Error(await r.text());
      toast({ title: "Spot añadido al bloque" });
      await breaksAsync.refresh();
      setAddEntryOpen(false);
    } catch (e) {
      toast({
        title: "Error",
        description: e instanceof Error ? e.message : "internal error",
        variant: "destructive",
      });
    } finally {
      setAddingEntry(false);
    }
  };

  // --- Delete entry ---
  const deleteEntry = async (entryId: string) => {
    if (!selected) return;
    try {
      const r = await fetch(
        `/api/adbreaks/${selected.id}/entries/${entryId}`,
        { method: "DELETE" }
      );
      if (!r.ok) throw new Error(await r.text());
      toast({ title: "Spot eliminado" });
      await breaksAsync.refresh();
    } catch (e) {
      toast({
        title: "Error",
        description: e instanceof Error ? e.message : "internal error",
        variant: "destructive",
      });
    }
  };

  // --- Delete ad break ---
  const [deletingBreak, setDeletingBreak] = useState<AdBreak | null>(null);
  const confirmDeleteBreak = async () => {
    if (!deletingBreak) return;
    try {
      const r = await fetch(`/api/adbreaks/${deletingBreak.id}`, {
        method: "DELETE",
      });
      if (!r.ok) throw new Error(await r.text());
      toast({ title: "Bloque eliminado" });
      if (selectedId === deletingBreak.id) setSelectedId(null);
      await breaksAsync.refresh();
    } catch (e) {
      toast({
        title: "Error",
        description: e instanceof Error ? e.message : "internal error",
        variant: "destructive",
      });
    } finally {
      setDeletingBreak(null);
    }
  };

  // Compute total pod duration.
  const podDuration = useMemo(() => {
    if (!selected) return 0;
    return selected.entries.reduce((s, e) => s + e.asset.durationMs, 0);
  }, [selected]);

  return (
    <div className="grid h-full min-h-0 grid-cols-1 gap-3 lg:grid-cols-[280px_1fr]">
      {/* Left: ad breaks list */}
      <Card className="flex min-h-0 flex-col border-zinc-800 bg-zinc-900/60 p-0">
        <div className="flex items-center justify-between border-b border-zinc-800 px-3 py-2">
          <span className="text-[11px] font-medium uppercase tracking-wider text-zinc-500">
            Bloques ({breaks.length})
          </span>
          <Button
            size="sm"
            className="h-7 gap-1 bg-amber-500 px-2 text-[11px] text-zinc-950 hover:bg-amber-400"
            onClick={() => setCreateOpen(true)}
          >
            <Plus className="size-3" /> Nuevo
          </Button>
        </div>
        <div className="min-h-0 flex-1 overflow-y-auto custom-scrollbar">
          {breaksAsync.loading && (
            <div className="flex items-center justify-center gap-2 py-8 text-zinc-500">
              <Spinner /> Cargando…
            </div>
          )}
          {!breaksAsync.loading && breaks.length === 0 && (
            <div className="px-4 py-8 text-center text-xs text-zinc-600">
              No hay bloques. Crea el primero.
            </div>
          )}
          <ul className="space-y-0.5 p-1.5">
            {breaks.map((b) => {
              const active = b.id === selectedId;
              const totalDur = b.entries.reduce(
                (s, e) => s + e.asset.durationMs,
                0
              );
              return (
                <li key={b.id}>
                  <button
                    onClick={() => setSelectedId(b.id)}
                    className={cn(
                      "group relative flex w-full flex-col gap-0.5 rounded-md border px-2.5 py-2 text-left transition-all",
                      active
                        ? "border-amber-500/40 bg-amber-500/10 shadow-sm shadow-amber-900/20"
                        : "border-transparent hover:bg-zinc-800/50 hover:border-zinc-700/60"
                    )}
                  >
                    {active && (
                      <span className="absolute left-0 top-1/2 h-6 w-0.5 -translate-y-1/2 rounded-r-full bg-amber-400" />
                    )}
                    <div className="flex items-center gap-2">
                      <Megaphone
                        className={cn(
                          "size-3.5 shrink-0 transition-transform group-hover:scale-110",
                          active ? "text-amber-400" : "text-zinc-500"
                        )}
                      />
                      <span
                        className={cn(
                          "truncate text-sm font-medium",
                          active ? "text-amber-200" : "text-zinc-200"
                        )}
                      >
                        {b.name}
                      </span>
                    </div>
                    <div className="flex items-center gap-2 pl-5 text-[10px] text-zinc-500">
                      <span>{b.entries.length} spots</span>
                      <span>·</span>
                      <span className="font-mono tabular-nums">
                        {msToHMMSS(totalDur)}
                      </span>
                      {b.showSlate ? (
                        <span className="ml-auto flex items-center gap-1 rounded border border-sky-500/30 bg-sky-500/10 px-1 py-0.5 text-[9px] font-medium uppercase tracking-wide text-sky-300">
                          <span className="size-1 rounded-full bg-sky-400" />
                          slate
                        </span>
                      ) : null}
                    </div>
                  </button>
                </li>
              );
            })}
          </ul>
        </div>
      </Card>

      {/* Right: detail */}
      <Card className="flex min-h-0 flex-col border-zinc-800 bg-zinc-900/60 p-0">
        {!selected ? (
          <div className="flex flex-1 flex-col items-center justify-center gap-2 text-zinc-500">
            <Megaphone className="size-8 text-zinc-700" />
            <div className="text-sm">Selecciona un bloque publicitario</div>
          </div>
        ) : (
          <>
            {/* Header: editable name + actions */}
            <div className="flex items-center gap-2 border-b border-zinc-800 px-3 py-2">
              <Input
                value={editName}
                onChange={(e) => setEditName(e.target.value)}
                className="h-8 flex-1 border-zinc-700 bg-zinc-950 text-sm font-medium text-zinc-100"
              />
              <Button
                size="sm"
                className="h-8 gap-1 bg-amber-500 px-2 text-zinc-950 hover:bg-amber-400"
                onClick={saveEdits}
                disabled={editing}
              >
                {editing ? (
                  <Spinner className="border-zinc-950 border-t-transparent" />
                ) : (
                  <Check className="size-3.5" />
                )}
                Guardar
              </Button>
              <Button
                variant="ghost"
                size="icon"
                className="size-8 text-zinc-500 hover:bg-zinc-800 hover:text-rose-400"
                onClick={() => setDeletingBreak(selected)}
                aria-label="Eliminar bloque"
              >
                <Trash2 className="size-4" />
              </Button>
            </div>

            <div className="min-h-0 flex-1 overflow-y-auto custom-scrollbar p-3">
              {/* Slate settings */}
              <div className="mb-4 grid gap-3 rounded-md border border-zinc-800 bg-zinc-950/40 p-3">
                <div className="grid gap-1.5">
                  <Label className="text-xs text-zinc-400">
                    Mensaje de slate
                  </Label>
                  <Textarea
                    value={editSlate}
                    onChange={(e) => setEditSlate(e.target.value)}
                    className="min-h-12 border-zinc-700 bg-zinc-950 text-xs text-zinc-100"
                    placeholder="Su programación continuará en {s} segundos"
                  />
                  <span className="text-[10px] text-zinc-500">
                    Usa <code className="text-amber-300">{"{s}"}</code> para
                    mostrar segundos restantes.
                  </span>
                </div>
                <div className="flex items-center justify-between rounded-md border border-zinc-800 bg-zinc-900/60 px-3 py-2">
                  <div>
                    <div className="text-sm text-zinc-200">Mostrar slate</div>
                    <div className="text-[11px] text-zinc-500">
                      Overlay visible al espectador durante el bloque
                    </div>
                  </div>
                  <Switch
                    checked={editShow}
                    onCheckedChange={setEditShow}
                  />
                </div>
              </div>

              {/* Pod entries */}
              <div className="mb-2 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="text-[11px] font-medium uppercase tracking-wider text-zinc-500">
                    Comerciales (pod)
                  </span>
                  <span className="font-mono text-[10px] tabular-nums text-amber-400">
                    {selected.entries.length} · {msToHMMSS(podDuration)}
                  </span>
                </div>
                <Button
                  size="sm"
                  variant="outline"
                  className="h-7 gap-1 border-zinc-700 bg-transparent px-2 text-[11px] text-zinc-300 hover:bg-zinc-800"
                  onClick={openAddEntry}
                >
                  <Plus className="size-3" /> Añadir comercial
                </Button>
              </div>

              <PodList
                adBreakId={selected.id}
                entries={selected.entries}
                onReordered={() => breaksAsync.refresh()}
                onDeleteEntry={deleteEntry}
              />
            </div>
          </>
        )}
      </Card>

      {/* Create ad break dialog */}
      <Dialog open={createOpen} onOpenChange={(o) => !o && setCreateOpen(false)}>
        <DialogContent className="gap-0 border-zinc-800 bg-zinc-900 p-0 sm:max-w-md">
          <DialogHeader className="border-b border-zinc-800 px-5 py-4">
            <DialogTitle className="text-base text-zinc-100">
              Nuevo bloque publicitario
            </DialogTitle>
            <DialogDescription className="text-xs text-zinc-500">
              Un bloque (pod) agrupa uno o más spots que se insertan en un corte
              comercial.
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-3 px-5 py-4">
            <div className="grid gap-1.5">
              <Label className="text-xs text-zinc-400">Nombre *</Label>
              <Input
                value={createForm.name}
                onChange={(e) =>
                  setCreateForm({ ...createForm, name: e.target.value })
                }
                className="h-9 border-zinc-700 bg-zinc-950 text-sm text-zinc-100"
                placeholder="Ej: Corte 1 — Pre-Noticiero"
              />
            </div>
            <div className="grid gap-1.5">
              <Label className="text-xs text-zinc-400">
                Mensaje de slate (opcional)
              </Label>
              <Textarea
                value={createForm.slateMessage}
                onChange={(e) =>
                  setCreateForm({
                    ...createForm,
                    slateMessage: e.target.value,
                  })
                }
                className="min-h-12 border-zinc-700 bg-zinc-950 text-xs text-zinc-100"
                placeholder="Su programación continuará en {s} segundos"
              />
            </div>
            <div className="flex items-center justify-between rounded-md border border-zinc-800 bg-zinc-950/40 px-3 py-2">
              <div>
                <div className="text-sm text-zinc-200">Mostrar slate</div>
                <div className="text-[11px] text-zinc-500">
                  Overlay visible al espectador
                </div>
              </div>
              <Switch
                checked={createForm.showSlate}
                onCheckedChange={(v) =>
                  setCreateForm({ ...createForm, showSlate: v })
                }
              />
            </div>
          </div>
          <DialogFooter className="border-t border-zinc-800 px-5 py-3">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setCreateOpen(false)}
              className="text-zinc-400 hover:bg-zinc-800 hover:text-zinc-100"
            >
              Cancelar
            </Button>
            <Button
              size="sm"
              onClick={submitCreate}
              disabled={creating}
              className="gap-1.5 bg-amber-500 text-zinc-950 hover:bg-amber-400"
            >
              {creating && (
                <Spinner className="border-zinc-950 border-t-transparent" />
              )}
              Crear bloque
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Add entry dialog */}
      <Dialog
        open={addEntryOpen}
        onOpenChange={(o) => !o && setAddEntryOpen(false)}
      >
        <DialogContent className="gap-0 border-zinc-800 bg-zinc-900 p-0 sm:max-w-md">
          <DialogHeader className="border-b border-zinc-800 px-5 py-4">
            <DialogTitle className="text-base text-zinc-100">
              Añadir comercial
            </DialogTitle>
            <DialogDescription className="text-xs text-zinc-500">
              Se añade al final del pod. Reordena arrastrando.
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-3 px-5 py-4">
            <div className="grid gap-1.5">
              <Label className="text-xs text-zinc-400">Spot</Label>
              <Select
                value={addEntryAssetId}
                onValueChange={setAddEntryAssetId}
              >
                <SelectTrigger className="h-9 border-zinc-700 bg-zinc-950 text-sm text-zinc-100">
                  <SelectValue placeholder="Selecciona un spot…" />
                </SelectTrigger>
                <SelectContent className="max-h-72 border-zinc-700 bg-zinc-900 text-zinc-100">
                  {(spotsAsync.data ?? []).map((p) => (
                    <SelectItem key={p.id} value={p.id}>
                      🎬 {p.title} ·{" "}
                      <span className="text-zinc-500">
                        {msToHMMSS(p.durationMs)}
                      </span>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter className="border-t border-zinc-800 px-5 py-3">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setAddEntryOpen(false)}
              className="text-zinc-400 hover:bg-zinc-800 hover:text-zinc-100"
            >
              Cancelar
            </Button>
            <Button
              size="sm"
              onClick={submitAddEntry}
              disabled={addingEntry}
              className="gap-1.5 bg-amber-500 text-zinc-950 hover:bg-amber-400"
            >
              {addingEntry && (
                <Spinner className="border-zinc-950 border-t-transparent" />
              )}
              Añadir
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete ad break confirmation */}
      <AlertDialog
        open={!!deletingBreak}
        onOpenChange={(o) => !o && setDeletingBreak(null)}
      >
        <AlertDialogContent className="border-zinc-800 bg-zinc-900 text-zinc-100">
          <AlertDialogHeader>
            <AlertDialogTitle className="text-base">
              Eliminar bloque
            </AlertDialogTitle>
            <AlertDialogDescription className="text-zinc-400">
              ¿Eliminar{" "}
              <span className="font-semibold text-zinc-200">
                {deletingBreak?.name}
              </span>
              ? Los cue points que lo referencien quedarán huérfanos.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="border-zinc-700 bg-transparent text-zinc-300 hover:bg-zinc-800 hover:text-zinc-100">
              Cancelar
            </AlertDialogCancel>
            <AlertDialogAction
              onClick={confirmDeleteBreak}
              className="bg-rose-600 text-white hover:bg-rose-500"
            >
              Eliminar
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
