"use client";

import { useEffect, useRef, useState, useCallback } from "react";
import Hls from "hls.js";
import {
  Play,
  Pause,
  Scissors,
  Check,
  RotateCcw,
  AlertTriangle,
  RefreshCw,
  Cloud,
  HardDrive,
  SkipBack,
  SkipForward,
  Rewind,
  FastForward,
  Gauge,
  ChevronDown,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { CategoryBadge, Spinner } from "./shared";
import type { AvanceClip } from "@/lib/types";

interface ClipCutEditorProps {
  clip: AvanceClip;
  open: boolean;
  onClose: () => void;
  onSave: (inMs: number, outMs: number, clamped: { inMs: boolean; outMs: boolean }) => void;
}

function fmtTime(ms: number): string {
  const total = Math.floor(ms / 1000);
  const h = Math.floor(total / 3600);
  const m = Math.floor((total % 3600) / 60);
  const s = total % 60;
  if (h > 0) return `${h}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
  return `${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
}

// Format with millisecond precision: MM:SS.mmm
// Used for the live time display so the user can see exact frame positions.
function fmtTimeMs(ms: number): string {
  const total = Math.floor(ms / 1000);
  const m = Math.floor(total / 60);
  const s = total % 60;
  const milli = Math.floor(ms % 1000);
  return `${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}.${String(milli).padStart(3, "0")}`;
}

// Detect if an HLS URL points to a remote stream (slow) or local disk (fast).
function isRemoteHls(url: string): boolean {
  return url.startsWith("http://") || url.startsWith("https://");
}

const LOAD_TIMEOUT_MS = 8000; // show timeout warning after 8s of no manifest

export function ClipCutEditor({ clip, open, onClose, onSave }: ClipCutEditorProps) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const hlsRef = useRef<Hls | null>(null);
  const loadTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  // Timeline drag state — tracks which marker is being dragged and the timeline element.
  // "playhead" lets the user scrub the video by dragging the white playhead.
  const timelineRef = useRef<HTMLDivElement>(null);
  const dragRef = useRef<"in" | "out" | "playhead" | null>(null);
  // Retry counter — re-mount the HLS loader when user clicks "Reintentar".
  const [retryNonce, setRetryNonce] = useState(0);

  const assetDur = Math.max(clip.asset.durationMs, 1);
  const [duration, setDuration] = useState(assetDur);
  const [current, setCurrent] = useState(0);
  const [playing, setPlaying] = useState(false);
  const [ready, setReady] = useState(false);
  // Load state: "loading" | "ready" | "timeout" | "error"
  const [loadState, setLoadState] = useState<"loading" | "ready" | "timeout" | "error">("loading");
  const [loadErrorMsg, setLoadErrorMsg] = useState<string | null>(null);
  // ---- Transport bar state ----
  // Skip step for the ⏪/⏩ buttons — persisted in localStorage so the user's
  // preference survives across sessions.
  const [skipStepMs, setSkipStepMs] = useState<number>(() => {
    if (typeof window === "undefined") return 10000;
    const saved = window.localStorage.getItem("clip-cut-editor:skipStepMs");
    return saved ? Number(saved) : 10000;
  });
  // Playback rate (0.25x to 2x). Default 1x.
  const [playbackRate, setPlaybackRate] = useState(1);
  // Rate dropdown open state — we use a simple toggle since shadcn Select would
  // render a portal that's hard to style inside the dialog footer.
  const [rateMenuOpen, setRateMenuOpen] = useState(false);
  const rateMenuRef = useRef<HTMLDivElement>(null);

  // Cut markers (in ms).
  const [inMs, setInMs] = useState(clip.inMs);
  const [outMs, setOutMs] = useState(clip.outMs > 0 ? clip.outMs : assetDur);

  // Clamp markers to asset duration.
  const safeIn = Math.max(0, Math.min(inMs, duration - 1));
  const safeOut = Math.max(safeIn + 1, Math.min(outMs > 0 ? outMs : duration, duration));

  const isRemote = isRemoteHls(clip.asset.hlsUrl);

  // Reset state when clip changes.
  useEffect(() => {
    if (!open) return;
    setDuration(assetDur);
    setCurrent(clip.inMs);
    setInMs(clip.inMs);
    setOutMs(clip.outMs > 0 ? clip.outMs : assetDur);
    setReady(false);
    setLoadState("loading");
    setLoadErrorMsg(null);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [clip.id, open]);

  // Load HLS source when opening or retrying.
  // We use a ref + rAF + small timeout to ensure the <video> element is mounted
  // (Radix Dialog animates in, so the ref isn't ready on the first effect run).
  useEffect(() => {
    if (!open) return;
    let cancelled = false;
    let rafId: number | null = null;
    let timeoutId: ReturnType<typeof setTimeout> | null = null;

    const startLoading = () => {
      if (cancelled) return;
      const video = videoRef.current;
      if (!video) {
        // Video ref not ready yet — try again on the next frame.
        rafId = requestAnimationFrame(startLoading);
        return;
      }

      setReady(false);
      setLoadState("loading");
      setLoadErrorMsg(null);
      if (hlsRef.current) {
        hlsRef.current.destroy();
        hlsRef.current = null;
      }
      if (loadTimerRef.current) {
        clearTimeout(loadTimerRef.current);
        loadTimerRef.current = null;
      }

      const url = clip.asset.hlsUrl;

      // Start a timeout — if the manifest doesn't parse in LOAD_TIMEOUT_MS,
      // surface a "timeout" state to the user with retry options.
      loadTimerRef.current = setTimeout(() => {
        setLoadState((prev) => (prev === "loading" ? "timeout" : prev));
      }, LOAD_TIMEOUT_MS);

      const onManifestParsed = () => {
        if (loadTimerRef.current) {
          clearTimeout(loadTimerRef.current);
          loadTimerRef.current = null;
        }
        setReady(true);
        setLoadState("ready");
        // Seek to the in-point to preview the cut.
        try {
          video.currentTime = safeIn / 1000;
        } catch {
          /* noop */
        }
      };

      if (Hls.isSupported()) {
        const hls = new Hls({
          enableWorker: true,
          lowLatencyMode: false,
          // Force the lowest quality level for fast preview loading.
          // The cut editor doesn't need high quality — it needs to load FAST.
          startLevel: 0,
          maxBufferLength: 10,
          maxMaxBufferLength: 20,
          // Be more aggressive about recovering from network errors.
          manifestLoadingTimeOut: 10000,
          manifestLoadingMaxRetry: 2,
          levelLoadingTimeOut: 10000,
          levelLoadingMaxRetry: 2,
        });
        hlsRef.current = hls;
        hls.loadSource(url);
        hls.attachMedia(video);
        hls.on(Hls.Events.MANIFEST_PARSED, onManifestParsed);
        hls.on(Hls.Events.ERROR, (_e, data) => {
          if (data.fatal) {
            if (data.type === Hls.ErrorTypes.NETWORK_ERROR) {
              if (loadTimerRef.current) {
                clearTimeout(loadTimerRef.current);
                loadTimerRef.current = null;
              }
              setLoadState("error");
              setLoadErrorMsg(
                `Error de red cargando el video: ${data.details || "network error"}. ` +
                (isRemote
                  ? "El stream remoto puede estar saturado o no disponible."
                  : "Verifica que el servidor esté sirviendo el archivo correctamente.")
              );
            } else if (data.type === Hls.ErrorTypes.MEDIA_ERROR) {
              hls.recoverMediaError();
            } else {
              setLoadState("error");
              setLoadErrorMsg(`Error fatal: ${data.details || data.type}`);
            }
          }
        });
      } else if (video.canPlayType("application/vnd.apple.mpegurl")) {
        video.src = url;
        const onMeta = () => onManifestParsed();
        video.addEventListener("loadedmetadata", onMeta, { once: true });
        const onErr = () => {
          if (loadTimerRef.current) {
            clearTimeout(loadTimerRef.current);
            loadTimerRef.current = null;
          }
          setLoadState("error");
          setLoadErrorMsg("El navegador no pudo cargar el video.");
        };
        video.addEventListener("error", onErr, { once: true });
      }
    };

    // Use requestAnimationFrame to wait for the Dialog to mount the video element.
    // Radix Dialog uses portals + animations, so the ref isn't ready synchronously.
    rafId = requestAnimationFrame(startLoading);

    return () => {
      cancelled = true;
      if (rafId !== null) cancelAnimationFrame(rafId);
      if (timeoutId !== null) clearTimeout(timeoutId);
      if (loadTimerRef.current) {
        clearTimeout(loadTimerRef.current);
        loadTimerRef.current = null;
      }
      if (hlsRef.current) {
        hlsRef.current.destroy();
        hlsRef.current = null;
      }
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [clip.id, open, retryNonce]);

  // Track playback position.
  // IMPORTANT: depends on `loadState` because the <video> element is mounted
  // inside a Radix Dialog (portal + animation), so videoRef.current is null
  // on the first render. When loadState changes to "ready", the video is
  // available and we can attach the event listeners.
  // We also use a ref for `current` to avoid excessive re-renders from
  // timeupdate (which fires ~4x/sec). The ref is updated on every tick,
  // but we only setState every ~100ms to keep the UI smooth.
  const currentMsRef = useRef(0);
  const lastSetStateRef = useRef(0);
  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;
    const onTime = () => {
      const ms = Math.floor(video.currentTime * 1000);
      currentMsRef.current = ms;
      // Throttle setState to every ~100ms to avoid excessive re-renders
      // that can cause the video to stutter on slower machines.
      if (ms - lastSetStateRef.current >= 100 || ms < lastSetStateRef.current) {
        lastSetStateRef.current = ms;
        setCurrent(ms);
      }
    };
    const onPlay = () => {
      // Clear the paused-at ref — we're playing now, so live currentTime is the truth.
      pausedAtMsRef.current = null;
      setPlaying(true);
    };
    const onPause = () => {
      // Capture the EXACT frame position at the moment of pause.
      // This is used by setInHere/setOutHere for frame-accurate marking
      // — video.currentTime can drift a few ms after pause as the browser
      // processes the last frame, but pausedAtMsRef is frozen at the exact
      // moment the user hit pause.
      pausedAtMsRef.current = Math.floor(video.currentTime * 1000);
      currentMsRef.current = pausedAtMsRef.current;
      lastSetStateRef.current = pausedAtMsRef.current;
      setCurrent(pausedAtMsRef.current);
      setPlaying(false);
    };
    const onLoaded = () => {
      if (Number.isFinite(video.duration) && video.duration > 0) {
        setDuration(Math.floor(video.duration * 1000));
      }
    };
    // Use requestVideoFrameCallback if available for smoother tracking
    // (fires once per actual displayed frame, not just on timeupdate).
    if ("requestVideoFrameCallback" in video) {
      const onFrame = () => {
        const ms = Math.floor(video.currentTime * 1000);
        currentMsRef.current = ms;
        if (ms - lastSetStateRef.current >= 50 || ms < lastSetStateRef.current) {
          lastSetStateRef.current = ms;
          setCurrent(ms);
        }
        (video as HTMLVideoElement & { requestVideoFrameCallback: (cb: () => void) => number }).requestVideoFrameCallback(onFrame);
      };
      (video as HTMLVideoElement & { requestVideoFrameCallback: (cb: () => void) => number }).requestVideoFrameCallback(onFrame);
    }
    video.addEventListener("timeupdate", onTime);
    video.addEventListener("play", onPlay);
    video.addEventListener("pause", onPause);
    video.addEventListener("loadedmetadata", onLoaded);
    // Fire once immediately to sync the initial position.
    onTime();
    return () => {
      video.removeEventListener("timeupdate", onTime);
      video.removeEventListener("play", onPlay);
      video.removeEventListener("pause", onPause);
      video.removeEventListener("loadedmetadata", onLoaded);
    };
  }, [loadState]);

  // Auto-pause at out-point (preview the cut).
  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;
    if (current >= safeOut && !video.paused) {
      video.pause();
      // Snap exactly to out for a clean preview.
      try {
        video.currentTime = safeOut / 1000;
      } catch {
        /* noop */
      }
    }
  }, [current, safeOut]);

  const togglePlay = useCallback(() => {
    const video = videoRef.current;
    if (!video) return;
    if (video.paused) {
      // If we're past the out point, loop back to in.
      if (current >= safeOut) {
        try {
          video.currentTime = safeIn / 1000;
        } catch {
          /* noop */
        }
      }
      // Clear paused-at ref — we're about to play.
      pausedAtMsRef.current = null;
      void video.play().catch(() => {});
    } else {
      // Capture the EXACT position before pausing.
      // The onPause event handler will also capture it, but doing it here
      // ensures we get the value BEFORE any potential frame drift.
      pausedAtMsRef.current = Math.floor(video.currentTime * 1000);
      currentMsRef.current = pausedAtMsRef.current;
      video.pause();
    }
  }, [current, safeIn, safeOut]);

  // Mark IN/OUT at the current playhead position.
  // FRAME ACCURACY: when the video is paused, we use the `pausedAtMs` ref
  // which captures the EXACT frame position at the moment the video was paused.
  // This prevents the off-by-N-ms bug where the video.currentTime drifts
  // a few ms between the pause event and the click on [In / Out].
  // When the video is playing (live marking), we use video.currentTime directly.
  const pausedAtMsRef = useRef<number | null>(null);

  const getExactPositionMs = (): number => {
    const video = videoRef.current;
    if (!video) return currentMsRef.current;
    // If the video is paused, use the captured pause position (frame-accurate).
    if (video.paused && pausedAtMsRef.current !== null) {
      return pausedAtMsRef.current;
    }
    // If playing, use the live currentTime.
    return Math.floor(video.currentTime * 1000);
  };

  const setInHere = () => {
    const exactMs = getExactPositionMs();
    const newIn = Math.max(0, Math.min(exactMs, safeOut - 1));
    setInMs(newIn);
    currentMsRef.current = exactMs;
  };
  const setOutHere = () => {
    const exactMs = getExactPositionMs();
    const newOut = Math.max(safeIn + 1, Math.min(exactMs, duration));
    setOutMs(newOut);
    currentMsRef.current = exactMs;
  };
  const resetCut = () => {
    setInMs(0);
    setOutMs(duration);
  };

  const seekTo = (ms: number) => {
    const video = videoRef.current;
    if (!video) return;
    try {
      video.currentTime = ms / 1000;
      currentMsRef.current = ms;
      lastSetStateRef.current = ms;
      // When seeking while paused, update the paused-at ref so that
      // subsequent [In / Out] clicks use the new seek position, not the
      // old pause position.
      if (video.paused) {
        pausedAtMsRef.current = ms;
      }
      setCurrent(ms);
    } catch {
      /* noop */
    }
  };

  // ---- Transport bar handlers ----
  // Persist skipStepMs to localStorage so the user's preference survives.
  const changeSkipStep = (ms: number) => {
    setSkipStepMs(ms);
    if (typeof window !== "undefined") {
      window.localStorage.setItem("clip-cut-editor:skipStepMs", String(ms));
    }
  };

  const skipBackward = useCallback(() => {
    const video = videoRef.current;
    if (!video) return;
    const newMs = Math.max(0, Math.floor(video.currentTime * 1000) - skipStepMs);
    seekTo(newMs);
  }, [skipStepMs]);

  const skipForward = useCallback(() => {
    const video = videoRef.current;
    if (!video) return;
    const durMs = Math.max(1, Math.floor((video.duration || (duration / 1000)) * 1000));
    const newMs = Math.min(durMs, Math.floor(video.currentTime * 1000) + skipStepMs);
    seekTo(newMs);
  }, [skipStepMs, duration]);

  const seekToStart = useCallback(() => seekTo(0), []);
  const seekToEnd = useCallback(() => {
    const video = videoRef.current;
    if (!video) return;
    const durMs = Math.max(1, Math.floor((video.duration || (duration / 1000)) * 1000));
    seekTo(durMs - 1);
  }, [duration]);

  // Apply playbackRate to the video element when it changes.
  useEffect(() => {
    const video = videoRef.current;
    if (video) {
      video.playbackRate = playbackRate;
    }
  }, [playbackRate, ready]);

  // Close the rate dropdown when clicking outside.
  useEffect(() => {
    if (!rateMenuOpen) return;
    const handler = (e: MouseEvent) => {
      if (rateMenuRef.current && !rateMenuRef.current.contains(e.target as Node)) {
        setRateMenuOpen(false);
      }
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, [rateMenuOpen]);

  // ---- Keyboard shortcuts ----
  // (Moved after the function declarations below so the consts are in scope.)
  // The effect itself is declared at the end of the component, before the return.

  const handleSave = () => {
    const clamped = {
      inMs: inMs !== safeIn,
      outMs: outMs !== safeOut,
    };
    onSave(safeIn, safeOut, clamped);
  };

  const cutDuration = safeOut - safeIn;
  const isFullClip = safeIn === 0 && safeOut >= duration;
  const inPct = (safeIn / duration) * 100;
  const outPct = (safeOut / duration) * 100;
  const playPct = (current / duration) * 100;

  // ---- Keyboard shortcuts ----
  // Space = play/pause, ←/→ = -5s/+5s, Shift+←/→ = seek to IN/OUT, I/O = mark IN/OUT.
  // Attached to window so it works regardless of focus (but ignored when typing in inputs).
  useEffect(() => {
    if (!open) return;
    const handler = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement;
      if (target.tagName === "INPUT" || target.tagName === "TEXTAREA" || target.isContentEditable) return;

      switch (e.key) {
        case " ":
          e.preventDefault();
          togglePlay();
          break;
        case "ArrowLeft":
          e.preventDefault();
          if (e.shiftKey) {
            seekTo(safeIn);
          } else {
            const video = videoRef.current;
            if (video) {
              const newMs = Math.max(0, Math.floor(video.currentTime * 1000) - 5000);
              seekTo(newMs);
            }
          }
          break;
        case "ArrowRight":
          e.preventDefault();
          if (e.shiftKey) {
            seekTo(safeOut);
          } else {
            const video = videoRef.current;
            if (video) {
              const durMs = Math.max(1, Math.floor((video.duration || (duration / 1000)) * 1000));
              const newMs = Math.min(durMs, Math.floor(video.currentTime * 1000) + 5000);
              seekTo(newMs);
            }
          }
          break;
        case "i":
        case "I":
          e.preventDefault();
          setInHere();
          break;
        case "o":
        case "O":
          e.preventDefault();
          setOutHere();
          break;
      }
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [open, safeIn, safeOut, duration, togglePlay, setInHere, setOutHere]);

  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-2xl gap-0 border-zinc-800 bg-zinc-950 p-0 sm:rounded-xl">
        <DialogHeader className="border-b border-zinc-800 px-5 py-3">
          <DialogTitle className="flex items-center gap-2 text-sm text-zinc-100">
            <Scissors className="size-4 text-amber-400" />
            Editor de Corte
          </DialogTitle>
          <DialogDescription className="flex items-center gap-2 text-[11px] text-zinc-500">
            <span className="truncate">{clip.asset.title}</span>
            <CategoryBadge category={clip.asset.category} />
          </DialogDescription>
        </DialogHeader>

        <div className="px-5 py-4">
          {/* Video preview */}
          <div className="relative aspect-video w-full overflow-hidden rounded-lg border border-zinc-800 bg-black">
            <video
              ref={videoRef}
              className="h-full w-full"
              playsInline
              muted={false}
              onClick={togglePlay}
            />

            {/* ---- Loading state ---- */}
            {loadState === "loading" && (
              <div className="absolute inset-0 flex flex-col items-center justify-center gap-3 bg-black/70 p-4 text-center">
                <Spinner className="size-7" />
                <div className="text-xs text-zinc-300">
                  Cargando video…
                </div>
                {/* Show source type so the user understands why it might be slow */}
                <div className="flex items-center gap-1.5 rounded-full border border-zinc-700 bg-zinc-900/80 px-2.5 py-0.5 text-[10px] text-zinc-400">
                  {isRemote ? (
                    <>
                      <Cloud className="size-2.5" />
                      Stream remoto (puede tardar)
                    </>
                  ) : (
                    <>
                      <HardDrive className="size-2.5" />
                      Servidor local (rápido)
                    </>
                  )}
                </div>
              </div>
            )}

            {/* ---- Timeout state — video is taking too long ---- */}
            {loadState === "timeout" && (
              <div className="absolute inset-0 flex flex-col items-center justify-center gap-3 bg-black/85 p-4 text-center">
                <AlertTriangle className="size-8 text-amber-400" />
                <div className="max-w-sm text-xs text-zinc-200">
                  El video está tardando más de lo normal en cargar.
                </div>
                {isRemote && (
                  <div className="max-w-sm text-[11px] text-zinc-400">
                    Este asset usa un stream HLS remoto (mux.dev) que puede estar
                    saturado. Puedes esperar, reintentar, o guardar el corte sin
                    previsualizar (los marcadores In/Out funcionan igual).
                  </div>
                )}
                <div className="mt-1 flex flex-wrap items-center justify-center gap-2">
                  <Button
                    size="sm"
                    variant="outline"
                    className="h-7 gap-1.5 border-zinc-700 bg-transparent text-[11px] text-zinc-200 hover:bg-zinc-800"
                    onClick={() => setRetryNonce((n) => n + 1)}
                  >
                    <RefreshCw className="size-3" />
                    Reintentar
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    className="h-7 gap-1.5 border-zinc-700 bg-transparent text-[11px] text-zinc-200 hover:bg-zinc-800"
                    onClick={() => setLoadState("ready")}
                  >
                    Editar sin previsualizar
                  </Button>
                </div>
              </div>
            )}

            {/* ---- Error state ---- */}
            {loadState === "error" && (
              <div className="absolute inset-0 flex flex-col items-center justify-center gap-3 bg-black/85 p-4 text-center">
                <AlertTriangle className="size-8 text-rose-400" />
                <div className="max-w-sm text-xs text-zinc-200">
                  No se pudo cargar el video
                </div>
                {loadErrorMsg && (
                  <div className="max-w-sm text-[11px] text-zinc-400">
                    {loadErrorMsg}
                  </div>
                )}
                <div className="mt-1 flex flex-wrap items-center justify-center gap-2">
                  <Button
                    size="sm"
                    variant="outline"
                    className="h-7 gap-1.5 border-zinc-700 bg-transparent text-[11px] text-zinc-200 hover:bg-zinc-800"
                    onClick={() => setRetryNonce((n) => n + 1)}
                  >
                    <RefreshCw className="size-3" />
                    Reintentar
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    className="h-7 gap-1.5 border-zinc-700 bg-transparent text-[11px] text-zinc-200 hover:bg-zinc-800"
                    onClick={() => setLoadState("ready")}
                  >
                    Editar sin previsualizar
                  </Button>
                </div>
              </div>
            )}

            {/* Big play/pause button overlay (only when ready AND paused) */}
            {loadState === "ready" && !playing && (
              <button
                onClick={togglePlay}
                className="absolute inset-0 z-10 flex items-center justify-center transition-opacity hover:bg-black/20"
                aria-label="Reproducir"
              >
                <span className="flex size-14 items-center justify-center rounded-full bg-black/70 text-white transition-all">
                  <Play className="size-6 translate-x-0.5" />
                </span>
              </button>
            )}
            {/* Current position badge — with millisecond precision */}
            <div className="absolute right-2 top-2 rounded bg-black/70 px-2 py-0.5 font-mono text-[10px] tabular-nums text-zinc-200">
              <span className="text-amber-300">{fmtTimeMs(current)}</span>
              <span className="text-zinc-500"> / </span>
              <span>{fmtTime(duration)}</span>
            </div>
            {/* Source badge (top-left) — helps user understand if it's local or remote */}
            <div className={cn(
              "absolute left-2 top-2 flex items-center gap-1 rounded px-1.5 py-0.5 text-[9px] font-medium",
              isRemote
                ? "bg-amber-950/80 text-amber-300"
                : "bg-emerald-950/80 text-emerald-300"
            )}>
              {isRemote ? (
                <>
                  <Cloud className="size-2.5" />
                  Remoto
                </>
              ) : (
                <>
                  <HardDrive className="size-2.5" />
                  Local
                </>
              )}
            </div>
          </div>

          {/* ---- Transport bar ----
               Full playback controls: skip-to-start, skip-backward, play/pause,
               skip-forward, skip-to-end, time display, playback rate dropdown. */}
          {loadState === "ready" && (
            <div className="mt-3 flex items-center gap-2 rounded-md border border-zinc-800 bg-zinc-900/60 px-3 py-2">
              {/* Skip to start */}
              <Button
                type="button"
                variant="ghost"
                size="icon"
                className="size-8 text-zinc-300 hover:bg-zinc-800 hover:text-white"
                onClick={seekToStart}
                title="Saltar al inicio (0:00)"
                aria-label="Saltar al inicio"
              >
                <SkipBack className="size-4" />
              </Button>
              {/* Skip backward — with configurable step */}
              <div className="relative">
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  className="h-8 gap-1 px-2 text-zinc-300 hover:bg-zinc-800 hover:text-white"
                  onClick={skipBackward}
                  title={`Retroceder ${skipStepMs / 1000}s`}
                  aria-label={`Retroceder ${skipStepMs / 1000} segundos`}
                >
                  <Rewind className="size-4" />
                  <span className="text-[10px] font-mono tabular-nums">{skipStepMs / 1000}s</span>
                </Button>
                {/* Step selector — small dropdown */}
                <Select value={String(skipStepMs)} onValueChange={(v) => changeSkipStep(Number(v))}>
                  <SelectTrigger
                    className="absolute -bottom-1 -right-1 size-3.5 border-zinc-700 bg-zinc-800 p-0 opacity-70 hover:opacity-100"
                    aria-label="Cambiar tamaño de salto"
                  />
                  <SelectContent className="border-zinc-700 bg-zinc-900">
                    <SelectItem value="5000">5s</SelectItem>
                    <SelectItem value="10000">10s</SelectItem>
                    <SelectItem value="30000">30s</SelectItem>
                    <SelectItem value="60000">1min</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              {/* Play/Pause — central */}
              <Button
                type="button"
                variant="default"
                size="icon"
                className="size-9 bg-amber-500 text-zinc-950 hover:bg-amber-400"
                onClick={togglePlay}
                title={playing ? "Pausar (Espacio)" : "Reproducir (Espacio)"}
                aria-label={playing ? "Pausar" : "Reproducir"}
              >
                {playing ? <Pause className="size-4" /> : <Play className="size-4 translate-x-0.5" />}
              </Button>
              {/* Skip forward */}
              <div className="relative">
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  className="h-8 gap-1 px-2 text-zinc-300 hover:bg-zinc-800 hover:text-white"
                  onClick={skipForward}
                  title={`Avanzar ${skipStepMs / 1000}s`}
                  aria-label={`Avanzar ${skipStepMs / 1000} segundos`}
                >
                  <span className="text-[10px] font-mono tabular-nums">{skipStepMs / 1000}s</span>
                  <FastForward className="size-4" />
                </Button>
                <Select value={String(skipStepMs)} onValueChange={(v) => changeSkipStep(Number(v))}>
                  <SelectTrigger
                    className="absolute -bottom-1 -left-1 size-3.5 border-zinc-700 bg-zinc-800 p-0 opacity-70 hover:opacity-100"
                    aria-label="Cambiar tamaño de salto"
                  />
                  <SelectContent className="border-zinc-700 bg-zinc-900">
                    <SelectItem value="5000">5s</SelectItem>
                    <SelectItem value="10000">10s</SelectItem>
                    <SelectItem value="30000">30s</SelectItem>
                    <SelectItem value="60000">1min</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              {/* Skip to end */}
              <Button
                type="button"
                variant="ghost"
                size="icon"
                className="size-8 text-zinc-300 hover:bg-zinc-800 hover:text-white"
                onClick={seekToEnd}
                title="Saltar al final"
                aria-label="Saltar al final"
              >
                <SkipForward className="size-4" />
              </Button>

              {/* Time display — with millisecond precision */}
              <div className="ml-1 mr-auto font-mono text-xs tabular-nums text-zinc-300">
                <span className="text-amber-300">{fmtTimeMs(current)}</span>
                <span className="text-zinc-600"> / </span>
                <span>{fmtTime(duration)}</span>
              </div>

              {/* Playback rate dropdown */}
              <div ref={rateMenuRef} className="relative">
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  className="h-8 gap-1 px-2 text-zinc-300 hover:bg-zinc-800 hover:text-white"
                  onClick={() => setRateMenuOpen((v) => !v)}
                  title="Velocidad de reproducción"
                  aria-label="Cambiar velocidad de reproducción"
                >
                  <Gauge className="size-3.5" />
                  <span className="text-[11px] font-mono tabular-nums">{playbackRate}x</span>
                  <ChevronDown className="size-3 opacity-60" />
                </Button>
                {rateMenuOpen && (
                  <div className="absolute right-0 top-full z-30 mt-1 w-24 rounded-md border border-zinc-700 bg-zinc-900 py-1 shadow-xl">
                    {[0.25, 0.5, 1, 1.5, 2].map((rate) => (
                      <button
                        key={rate}
                        type="button"
                        onClick={() => {
                          setPlaybackRate(rate);
                          setRateMenuOpen(false);
                        }}
                        className={cn(
                          "flex w-full items-center justify-between px-3 py-1.5 text-[11px] font-mono tabular-nums transition-colors",
                          playbackRate === rate
                            ? "bg-amber-500/15 text-amber-300"
                            : "text-zinc-300 hover:bg-zinc-800 hover:text-white"
                        )}
                      >
                        {rate}x
                        {playbackRate === rate && <Check className="size-3" />}
                      </button>
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Timeline with In/Out markers */}
          <div className="mt-4">
            <div className="mb-1.5 flex items-center justify-between text-[11px] text-zinc-500">
              <span>
                1. Arrastra el <span className="text-white">●</span> para ubicar el frame ·
                2. Clic en <span className="text-amber-400 font-semibold">[In</span> o <span className="text-rose-400 font-semibold">Out]</span> para marcar el corte
              </span>
              <span>
                Duración: <span className="font-mono tabular-nums text-zinc-300">{fmtTime(duration)}</span>
              </span>
            </div>

            {/* Wrapper with extra top padding so the floating [In/Out] buttons
                above the playhead have room to render without being clipped. */}
            <div className="relative pt-7">

            {/* Timeline bar — UNIFIED pointer handling.
                ALL drag logic is on this single element. The IN/OUT/playhead
                handles below only set dragRef.current on pointerDown (with
                stopPropagation) and let this parent handle all move/up events.
                This avoids the bug where each handle had its own onPointerMove
                that stopped firing when the cursor left the handle's bounds. */}
            <div
              ref={timelineRef}
              className="relative h-12 cursor-pointer select-none rounded-md border border-zinc-800 bg-zinc-900"
              onPointerDown={(e) => {
                const tl = timelineRef.current;
                if (!tl || duration <= 0) return;
                const rect = tl.getBoundingClientRect();
                const x = e.clientX - rect.left;
                const pct = Math.max(0, Math.min(100, (x / rect.width) * 100));
                const ms = Math.round((pct / 100) * duration);
                // Click on empty timeline → seek the playhead (scrub).
                seekTo(ms);
                dragRef.current = "playhead";
                tl.setPointerCapture(e.pointerId);
              }}
              onPointerMove={(e) => {
                if (!dragRef.current) return;
                const tl = timelineRef.current;
                if (!tl || duration <= 0) return;
                const rect = tl.getBoundingClientRect();
                const x = e.clientX - rect.left;
                const pct = Math.max(0, Math.min(100, (x / rect.width) * 100));
                const ms = Math.round((pct / 100) * duration);
                if (dragRef.current === "playhead") {
                  seekTo(ms);
                } else if (dragRef.current === "in") {
                  setInMs(Math.max(0, Math.min(ms, safeOut - 1)));
                } else if (dragRef.current === "out") {
                  setOutMs(Math.max(safeIn + 1, Math.min(ms, duration)));
                }
              }}
              onPointerUp={(e) => {
                dragRef.current = null;
                const tl = timelineRef.current;
                if (tl) {
                  try { tl.releasePointerCapture(e.pointerId); } catch { /* noop */ }
                }
              }}
              onPointerCancel={() => { dragRef.current = null; }}
            >
              {/* Cut region (between In and Out) */}
              <div
                className="pointer-events-none absolute inset-y-0 bg-amber-500/20 border-x border-amber-500/60"
                style={{ left: `${inPct}%`, right: `${100 - outPct}%` }}
              />
              {/* Played portion (left of playhead) */}
              <div
                className="pointer-events-none absolute inset-y-0 left-0 bg-amber-500/30"
                style={{ width: `${Math.min(playPct, outPct)}%` }}
              />
              {/* Playhead vertical line */}
              <div
                className="pointer-events-none absolute inset-y-0 z-20 w-0.5 bg-white shadow-[0_0_4px] shadow-white/50"
                style={{ left: `${playPct}%` }}
              />

              {/* ---- Floating "Mark IN / Mark OUT" buttons above the playhead ---- */}
              <div
                className="pointer-events-none absolute bottom-full z-40 mb-1 flex -translate-x-1/2 items-center gap-1"
                style={{ left: `${Math.max(15, Math.min(85, playPct))}%` }}
              >
                <button
                  type="button"
                  onClick={(e) => { e.stopPropagation(); setInHere(); }}
                  onPointerDown={(e) => e.stopPropagation()}
                  className="pointer-events-auto flex items-center gap-0.5 rounded-md border border-amber-500/60 bg-amber-500 px-1.5 py-0.5 text-[9px] font-bold text-zinc-950 shadow-lg transition-all hover:bg-amber-400 hover:scale-105 active:scale-95"
                  title="Marcar esta posición como IN (tecla I)"
                  aria-label="Marcar posición actual como entrada"
                >
                  <span className="font-mono">[</span>In
                </button>
                <button
                  type="button"
                  onClick={(e) => { e.stopPropagation(); setOutHere(); }}
                  onPointerDown={(e) => e.stopPropagation()}
                  className="pointer-events-auto flex items-center gap-0.5 rounded-md border border-rose-500/60 bg-rose-500 px-1.5 py-0.5 text-[9px] font-bold text-white shadow-lg transition-all hover:bg-rose-400 hover:scale-105 active:scale-95"
                  title="Marcar esta posición como OUT (tecla O)"
                  aria-label="Marcar posición actual como salida"
                >
                  Out<span className="font-mono">]</span>
                </button>
                <div className="pointer-events-none absolute -bottom-1 left-1/2 h-2 w-2 -translate-x-1/2 rotate-45 bg-zinc-800" aria-hidden />
              </div>

              {/* IN marker handle — only sets dragRef on pointerDown, no move/up.
                  The parent timeline handles all move/up events via pointer capture. */}
              <div
                className="absolute top-0 z-30 flex h-full w-6 -translate-x-1/2 cursor-ew-resize flex-col items-center justify-start"
                style={{ left: `${inPct}%` }}
                onPointerDown={(e) => {
                  e.stopPropagation();
                  dragRef.current = "in";
                  const tl = timelineRef.current;
                  if (tl) tl.setPointerCapture(e.pointerId);
                }}
                role="slider"
                aria-label="Marcador de entrada"
                aria-valuemin={0}
                aria-valuemax={safeOut - 1}
                aria-valuenow={safeIn}
                tabIndex={0}
              >
                <span className="rounded bg-amber-500 px-1 text-[9px] font-bold text-zinc-950 shadow">IN</span>
                <div className="mt-0.5 h-7 w-0.5 bg-amber-500" />
              </div>

              {/* OUT marker handle — same pattern as IN. */}
              <div
                className="absolute bottom-0 z-30 flex h-full w-6 -translate-x-1/2 cursor-ew-resize flex-col items-center justify-end"
                style={{ left: `${outPct}%` }}
                onPointerDown={(e) => {
                  e.stopPropagation();
                  dragRef.current = "out";
                  const tl = timelineRef.current;
                  if (tl) tl.setPointerCapture(e.pointerId);
                }}
                role="slider"
                aria-label="Marcador de salida"
                aria-valuemin={safeIn + 1}
                aria-valuemax={duration}
                aria-valuenow={safeOut}
                tabIndex={0}
              >
                <div className="mb-0.5 h-7 w-0.5 bg-rose-500" />
                <span className="rounded bg-rose-500 px-1 text-[9px] font-bold text-white shadow">OUT</span>
              </div>

              {/* Playhead grab handle — only sets dragRef on pointerDown.
                  z-30 (same as IN/OUT) so it's grabbable when overlapping. */}
              <div
                className="absolute top-0 z-30 flex h-4 w-4 -translate-x-1/2 cursor-grab items-center justify-center"
                style={{ left: `${playPct}%` }}
                onPointerDown={(e) => {
                  e.stopPropagation();
                  dragRef.current = "playhead";
                  const tl = timelineRef.current;
                  if (tl) tl.setPointerCapture(e.pointerId);
                }}
                role="slider"
                aria-label="Posición de reproducción"
                aria-valuemin={0}
                aria-valuemax={duration}
                aria-valuenow={current}
                tabIndex={0}
              >
                <div className="size-2.5 rounded-full bg-white shadow ring-2 ring-amber-500/50" />
              </div>
            </div>
            {/* /wrapper pt-7 */}
            </div>

            {/* Numeric inputs + quick actions */}
            <div className="mt-3 grid grid-cols-2 gap-3 sm:grid-cols-4">
              <div>
                <label className="text-[10px] uppercase tracking-wider text-zinc-500">Entrada</label>
                <div className="mt-1 flex items-center gap-1.5 rounded-md border border-zinc-800 bg-zinc-900 px-2 py-1.5">
                  <span className="font-mono text-xs tabular-nums text-amber-300">{fmtTimeMs(safeIn)}</span>
                </div>
              </div>
              <div>
                <label className="text-[10px] uppercase tracking-wider text-zinc-500">Salida</label>
                <div className="mt-1 flex items-center gap-1.5 rounded-md border border-zinc-800 bg-zinc-900 px-2 py-1.5">
                  <span className="font-mono text-xs tabular-nums text-rose-300">{fmtTimeMs(safeOut)}</span>
                </div>
              </div>
              <div>
                <label className="text-[10px] uppercase tracking-wider text-zinc-500">Duración corte</label>
                <div className="mt-1 flex items-center gap-1.5 rounded-md border border-zinc-800 bg-zinc-900 px-2 py-1.5">
                  <span className="font-mono text-xs tabular-nums text-zinc-200">{fmtTimeMs(cutDuration)}</span>
                  {isFullClip && (
                    <span className="ml-auto text-[9px] text-zinc-500">completo</span>
                  )}
                </div>
              </div>
              <div className="flex flex-col gap-1">
                <label className="text-[10px] uppercase tracking-wider text-zinc-500">Acciones rápidas</label>
                <div className="flex gap-1">
                  <Button
                    type="button"
                    size="sm"
                    variant="outline"
                    className="h-7 flex-1 gap-1 border-amber-500/50 bg-amber-500/10 px-2 text-[10px] text-amber-300 hover:bg-amber-500/20"
                    onClick={setInHere}
                    title="Marcar posición actual como Entrada"
                  >
                    <span className="font-bold">[</span> In
                  </Button>
                  <Button
                    type="button"
                    size="sm"
                    variant="outline"
                    className="h-7 flex-1 gap-1 border-rose-500/50 bg-rose-500/10 px-2 text-[10px] text-rose-300 hover:bg-rose-500/20"
                    onClick={setOutHere}
                    title="Marcar posición actual como Salida"
                  >
                    Out <span className="font-bold">]</span>
                  </Button>
                </div>
              </div>
            </div>

            {/* Seek buttons + keyboard hint */}
            <div className="mt-2 flex flex-wrap items-center gap-1.5">
              <Button
                type="button"
                size="sm"
                variant="ghost"
                className="h-7 gap-1 px-2 text-[10px] text-zinc-400 hover:bg-zinc-800 hover:text-amber-300"
                onClick={() => seekTo(safeIn)}
                title="Ir al punto de entrada (Shift+←)"
              >
                <span className="font-bold">[</span> Ir al In
              </Button>
              <Button
                type="button"
                size="sm"
                variant="ghost"
                className="h-7 gap-1 px-2 text-[10px] text-zinc-400 hover:bg-zinc-800 hover:text-rose-300"
                onClick={() => seekTo(safeOut)}
                title="Ir al punto de salida (Shift+→)"
              >
                Ir al Out <span className="font-bold">]</span>
              </Button>
              <Button
                type="button"
                size="sm"
                variant="ghost"
                className="h-7 gap-1 px-2 text-[10px] text-zinc-400 hover:bg-zinc-800 hover:text-zinc-200"
                onClick={resetCut}
              >
                <RotateCcw className="size-3" />
                Reset
              </Button>
              {/* Keyboard shortcuts hint */}
              <div className="ml-auto flex items-center gap-1.5 text-[9px] text-zinc-600">
                <kbd className="rounded border border-zinc-700 bg-zinc-900 px-1 py-0.5 font-mono">Space</kbd>
                <span>play</span>
                <kbd className="rounded border border-zinc-700 bg-zinc-900 px-1 py-0.5 font-mono">←→</kbd>
                <span>±5s</span>
                <kbd className="rounded border border-zinc-700 bg-zinc-900 px-1 py-0.5 font-mono">I</kbd>
                <kbd className="rounded border border-zinc-700 bg-zinc-900 px-1 py-0.5 font-mono">O</kbd>
                <span>marcar</span>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-end gap-2 border-t border-zinc-800 px-5 py-3">
          <Button
            type="button"
            variant="ghost"
            size="sm"
            className="text-zinc-400 hover:bg-zinc-800 hover:text-zinc-100"
            onClick={onClose}
          >
            Cancelar
          </Button>
          {/* Show hint when video failed to load but cut can still be saved */}
          {(loadState === "timeout" || loadState === "error") && (
            <span className="mr-auto text-[10px] text-zinc-500">
              Puedes guardar el corte sin previsualizar
            </span>
          )}
          <Button
            type="button"
            size="sm"
            className="gap-1.5 bg-amber-500 text-zinc-950 hover:bg-amber-400"
            onClick={handleSave}
          >
            <Check className="size-3.5" />
            Guardar corte
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
