"use client";

import { useEffect, useMemo, useState } from "react";
import {
  Plus,
  Trash2,
  Pencil,
  Eye,
  EyeOff,
  Clock,
  Film,
  CalendarClock,
  GripVertical,
  Scissors,
  X,
  Save,
  Check,
  AlertTriangle,
  Clapperboard,
  Waves,
  FileVideo,
  CheckCircle2,
  Loader2,
  AlertCircle,
  RefreshCw,
} from "lucide-react";
import {
  DndContext,
  closestCenter,
  PointerSensor,
  useSensor,
  useSensors,
  type DragEndEvent,
} from "@dnd-kit/core";
import {
  arrayMove,
  SortableContext,
  useSortable,
  verticalListSortingStrategy,
} from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import {
  useAsync,
  Thumbnail,
  CategoryBadge,
  Spinner,
  msToHMMSS,
} from "./shared";
import { ClipCutEditor } from "./clip-cut-editor";
import type { Avance, AvanceClip, Asset, RenderedAvance } from "@/lib/types";

// Color options for the Avance chip in the schedule grid.
const COLOR_OPTIONS = [
  { value: "amber", label: "Ámbar", className: "bg-amber-500" },
  { value: "rose", label: "Rosa", className: "bg-rose-500" },
  { value: "violet", label: "Violeta", className: "bg-violet-500" },
  { value: "emerald", label: "Esmeralda", className: "bg-emerald-500" },
  { value: "sky", label: "Cielo", className: "bg-sky-500" },
];

function colorDot(color: string) {
  const found = COLOR_OPTIONS.find((c) => c.value === color);
  return found?.className ?? "bg-amber-500";
}

// Format ms as MM:SS or HH:MM:SS
function fmtCut(ms: number): string {
  const total = Math.floor(ms / 1000);
  const h = Math.floor(total / 3600);
  const m = Math.floor((total % 3600) / 60);
  const s = total % 60;
  if (h > 0) return `${h}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
  return `${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
}

// Format YYYY-MM-DD from an ISO date for the date input value.
function isoToDateInput(iso: string | null): string {
  if (!iso) return "";
  try {
    const d = new Date(iso);
    return d.toISOString().slice(0, 10);
  } catch {
    return "";
  }
}

// =====================================================================
// Avance list (top-level view)
// =====================================================================
// Helper: format bytes to human-readable.
function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / 1024 / 1024).toFixed(1)} MB`;
}

// Render status badge — shows the current state of the rendered MP4 cache.
function RenderStatusBadge({ render }: { render?: RenderedAvance | null }) {
  if (!render) {
    return (
      <span className="inline-flex items-center gap-1 rounded-md border border-zinc-700 bg-zinc-800/40 px-1.5 py-0.5 text-[10px] font-medium text-zinc-500">
        <FileVideo className="size-2.5" />
        Sin render
      </span>
    );
  }
  switch (render.status) {
    case "completed":
      return (
        <span className="inline-flex items-center gap-1 rounded-md border border-emerald-500/40 bg-emerald-500/15 px-1.5 py-0.5 text-[10px] font-medium text-emerald-300" title={`MP4 · ${formatBytes(render.fileSizeBytes)} · ${msToHMMSS(render.durationMs)}`}>
          <CheckCircle2 className="size-2.5" />
          Renderizado · {formatBytes(render.fileSizeBytes)}
        </span>
      );
    case "rendering":
      return (
        <span className="inline-flex items-center gap-1 rounded-md border border-sky-500/40 bg-sky-500/15 px-1.5 py-0.5 text-[10px] font-medium text-sky-300">
          <Loader2 className="size-2.5 animate-spin" />
          Renderizando {render.progress}%
        </span>
      );
    case "pending":
      return (
        <span className="inline-flex items-center gap-1 rounded-md border border-zinc-600 bg-zinc-800/60 px-1.5 py-0.5 text-[10px] font-medium text-zinc-400">
          <Loader2 className="size-2.5 animate-spin" />
          En cola…
        </span>
      );
    case "failed":
      return (
        <span
          className="inline-flex items-center gap-1 rounded-md border border-rose-500/40 bg-rose-500/15 px-1.5 py-0.5 text-[10px] font-medium text-rose-300"
          title={render.error || "Error desconocido"}
        >
          <AlertCircle className="size-2.5" />
          Falló
        </span>
      );
    case "stale":
      return (
        <span className="inline-flex items-center gap-1 rounded-md border border-amber-500/40 bg-amber-500/15 px-1.5 py-0.5 text-[10px] font-medium text-amber-300">
          <RefreshCw className="size-2.5" />
          Obsoleto
        </span>
      );
    default:
      return null;
  }
}

function AvanceRow({
  avance,
  render,
  onEdit,
  onDelete,
  onRender,
  rendering,
}: {
  avance: Avance;
  render?: RenderedAvance | null;
  onEdit: () => void;
  onDelete: () => void;
  onRender: () => void;
  rendering: boolean;
}) {
  // Show a thin progress bar when rendering.
  const showProgress = render?.status === "rendering" || render?.status === "pending";

  return (
    <Card
      className={cn(
        "group flex items-center gap-3 border-zinc-800 bg-zinc-900/60 p-3 transition-colors hover:border-amber-500/40",
        avance.hideFromEpg && "border-dashed"
      )}
    >
      <div className={cn("size-2.5 shrink-0 rounded-full", colorDot(avance.color))} />
      <div className="min-w-0 flex-1">
        <div className="flex flex-wrap items-center gap-2">
          <h3 className="truncate text-sm font-semibold text-zinc-100">
            {avance.title}
          </h3>
          {avance.hideFromEpg ? (
            <span className="inline-flex items-center gap-1 rounded-md border border-violet-500/40 bg-violet-500/15 px-1.5 py-0.5 text-[10px] font-medium text-violet-300">
              <EyeOff className="size-2.5" />
              Oculto en EPG
            </span>
          ) : (
            <span className="inline-flex items-center gap-1 rounded-md border border-emerald-500/40 bg-emerald-500/15 px-1.5 py-0.5 text-[10px] font-medium text-emerald-300">
              <Eye className="size-2.5" />
              Visible
            </span>
          )}
          <RenderStatusBadge render={render} />
        </div>
        <div className="mt-0.5 flex flex-wrap items-center gap-3 text-[11px] text-zinc-500">
          <span className="flex items-center gap-1">
            <Film className="size-3" />
            {avance.clips.length} clip{avance.clips.length === 1 ? "" : "s"}
          </span>
          <span className="flex items-center gap-1">
            <Clock className="size-3" />
            {msToHMMSS(avance.totalDurationMs)}
          </span>
          {(avance.validFrom || avance.validUntil) && (
            <span className="flex items-center gap-1">
              <CalendarClock className="size-3" />
              {isoToDateInput(avance.validFrom) || "∞"} → {isoToDateInput(avance.validUntil) || "∞"}
            </span>
          )}
          {avance.fadeEnabled && (
            <span className="flex items-center gap-1 text-sky-400">
              <Waves className="size-3" />
              Fade {avance.fadeInMs}ms/{avance.fadeOutMs}ms
            </span>
          )}
        </div>
        {/* Progress bar while rendering */}
        {showProgress && (
          <div className="mt-1.5 h-1 w-full max-w-xs overflow-hidden rounded-full bg-zinc-800">
            <div
              className="h-full rounded-full bg-sky-500 transition-all duration-500"
              style={{ width: `${render?.progress ?? 0}%` }}
            />
          </div>
        )}
      </div>
      <div className="flex shrink-0 items-center gap-1">
        {/* Render button */}
        <Button
          variant="ghost"
          size="sm"
          className={cn(
            "h-8 gap-1.5 px-2 text-[11px] transition-opacity",
            render?.status === "completed"
              ? "text-zinc-500 hover:bg-zinc-800 hover:text-amber-300"
              : "text-sky-300 hover:bg-sky-950 hover:text-sky-200",
            !showProgress && "opacity-0 group-hover:opacity-100"
          )}
          onClick={onRender}
          disabled={rendering || showProgress || avance.clips.length === 0}
          title={
            render?.status === "completed"
              ? "Re-renderizar (regenera el MP4)"
              : "Renderizar a MP4 (une todos los clips en un solo video)"
          }
        >
          {rendering || showProgress ? (
            <Loader2 className="size-3.5 animate-spin" />
          ) : render?.status === "completed" ? (
            <RefreshCw className="size-3.5" />
          ) : (
            <FileVideo className="size-3.5" />
          )}
          {render?.status === "completed" ? "Re-render" : "Render"}
        </Button>
        <Button
          variant="ghost"
          size="icon"
          className="size-8 text-zinc-400 opacity-0 transition-opacity hover:bg-zinc-800 hover:text-amber-300 group-hover:opacity-100"
          onClick={onEdit}
          aria-label="Editar"
        >
          <Pencil className="size-3.5" />
        </Button>
        <Button
          variant="ghost"
          size="icon"
          className="size-8 text-zinc-400 opacity-0 transition-opacity hover:bg-rose-950 hover:text-rose-300 group-hover:opacity-100"
          onClick={onDelete}
          aria-label="Eliminar"
        >
          <Trash2 className="size-3.5" />
        </Button>
      </div>
    </Card>
  );
}

// =====================================================================
// Sortable clip row inside the editor
// =====================================================================
function SortableClipRow({
  clip,
  index,
  onEditCut,
  onRemove,
}: {
  clip: AvanceClip;
  index: number;
  onEditCut: () => void;
  onRemove: () => void;
}) {
  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
    isDragging,
  } = useSortable({ id: clip.id });

  const assetDur = Math.max(clip.asset.durationMs, 1);
  const cutIn = clip.inMs;
  const cutOut = clip.outMs > 0 ? clip.outMs : assetDur;
  const cutDur = cutOut - cutIn;
  const isFullClip = cutIn === 0 && cutOut >= assetDur;

  return (
    <div
      ref={setNodeRef}
      style={{
        transform: CSS.Transform.toString(transform),
        transition,
      }}
      className={cn(
        "flex items-center gap-2 rounded-md border border-zinc-800 bg-zinc-900/80 px-2 py-2",
        isDragging && "z-10 border-amber-500/50 opacity-90 shadow-lg"
      )}
    >
      <button
        {...attributes}
        {...listeners}
        className="cursor-grab text-zinc-500 hover:text-zinc-300 active:cursor-grabbing"
        aria-label="Reordenar"
      >
        <GripVertical className="size-4" />
      </button>
      <span className="w-5 shrink-0 text-center text-[11px] font-mono tabular-nums text-zinc-500">
        {index + 1}
      </span>
      <Thumbnail
        url={clip.asset.thumbnailUrl}
        className="size-10"
        title={clip.asset.title}
      />
      <div className="min-w-0 flex-1">
        <div className="flex items-center gap-2">
          <span className="truncate text-sm font-medium text-zinc-100">
            {clip.asset.title}
          </span>
          <CategoryBadge category={clip.asset.category} />
        </div>
        <div className="mt-0.5 flex items-center gap-2 text-[11px] text-zinc-500">
          {isFullClip ? (
            <span>Completo · {fmtCut(cutDur)}</span>
          ) : (
            <span className="flex items-center gap-1">
              <Scissors className="size-2.5" />
              <span className="font-mono tabular-nums">
                {fmtCut(cutIn)} → {fmtCut(cutOut)}
              </span>
              <span className="text-zinc-600">·</span>
              <span>{fmtCut(cutDur)}</span>
            </span>
          )}
        </div>
      </div>
      <Button
        variant="outline"
        size="sm"
        className="h-7 gap-1 border-zinc-700 bg-transparent px-2 text-[11px] text-zinc-300 hover:bg-zinc-800 hover:text-amber-300"
        onClick={onEditCut}
      >
        <Scissors className="size-3" />
        Corte
      </Button>
      <Button
        variant="ghost"
        size="icon"
        className="size-7 text-zinc-500 hover:bg-rose-950 hover:text-rose-300"
        onClick={onRemove}
        aria-label="Quitar clip"
      >
        <X className="size-3.5" />
      </Button>
    </div>
  );
}

// =====================================================================
// Editor dialog (create / edit Avance)
// =====================================================================
function AvanceEditor({
  avance,
  open,
  onClose,
  onSaved,
}: {
  avance: Avance | null; // null = create mode
  open: boolean;
  onClose: () => void;
  onSaved: () => void;
}) {
  const { toast } = useToast();
  const isEdit = !!avance;

  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [hideFromEpg, setHideFromEpg] = useState(false);
  const [validFrom, setValidFrom] = useState("");
  const [validUntil, setValidUntil] = useState("");
  const [color, setColor] = useState("amber");
  // Fade in/out state — defaults match the schema (fadeEnabled=false, 500ms each).
  const [fadeEnabled, setFadeEnabled] = useState(false);
  const [fadeInMs, setFadeInMs] = useState(500);
  const [fadeOutMs, setFadeOutMs] = useState(500);

  // Clips list — local working copy until save.
  const [clips, setClips] = useState<AvanceClip[]>([]);
  const [assets, setAssets] = useState<Asset[]>([]);
  const [selectedAssetId, setSelectedAssetId] = useState<string>("");
  const [saving, setSaving] = useState(false);

  // Clip cut editor state
  const [cutClip, setCutClip] = useState<AvanceClip | null>(null);
  const [cutOpen, setCutOpen] = useState(false);

  // Sync form state when opening.
  useEffect(() => {
    if (!open) return;
    if (avance) {
      setTitle(avance.title);
      setDescription(avance.description ?? "");
      setHideFromEpg(avance.hideFromEpg);
      setValidFrom(isoToDateInput(avance.validFrom));
      setValidUntil(isoToDateInput(avance.validUntil));
      setColor(avance.color);
      setFadeEnabled(avance.fadeEnabled);
      setFadeInMs(avance.fadeInMs);
      setFadeOutMs(avance.fadeOutMs);
      setClips(avance.clips);
    } else {
      setTitle("");
      setDescription("");
      setHideFromEpg(false);
      setValidFrom("");
      setValidUntil("");
      setColor("amber");
      setFadeEnabled(false);
      setFadeInMs(500);
      setFadeOutMs(500);
      setClips([]);
    }
  }, [avance, open]);

  // Fetch all assets for the "add clip" picker.
  useEffect(() => {
    if (!open) return;
    fetch("/api/assets")
      .then((r) => r.json())
      .then((a: Asset[]) => setAssets(a))
      .catch(() => setAssets([]));
  }, [open]);

  const sensors = useSensors(
    useSensor(PointerSensor, { activationConstraint: { distance: 4 } })
  );

  const totalDuration = useMemo(
    () => clips.reduce((sum, c) => {
      const dur = Math.max(c.asset.durationMs, 1);
      const inMs = Math.max(0, Math.min(c.inMs, dur - 1));
      const outMs = Math.max(inMs + 1, Math.min(c.outMs > 0 ? c.outMs : dur, dur));
      return sum + (outMs - inMs);
    }, 0),
    [clips]
  );

  function handleDragEnd(e: DragEndEvent) {
    const { active, over } = e;
    if (!over || active.id === over.id) return;
    setClips((prev) => {
      const oldIdx = prev.findIndex((c) => c.id === active.id);
      const newIdx = prev.findIndex((c) => c.id === over.id);
      if (oldIdx < 0 || newIdx < 0) return prev;
      return arrayMove(prev, oldIdx, newIdx);
    });
  }

  function addClip() {
    if (!selectedAssetId) return;
    const asset = assets.find((a) => a.id === selectedAssetId);
    if (!asset) return;
    // Create a temporary AvanceClip (id = "tmp-<n>"). The real one is persisted on save.
    const tempClip: AvanceClip = {
      id: `tmp-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
      avanceId: avance?.id ?? "tmp",
      assetId: asset.id,
      asset,
      orderIndex: clips.length,
      inMs: 0,
      outMs: 0, // 0 = full clip
      createdAt: new Date().toISOString(),
    };
    setClips((prev) => [...prev, tempClip]);
    setSelectedAssetId("");
  }

  function removeClip(clipId: string) {
    setClips((prev) => prev.filter((c) => c.id !== clipId));
  }

  function updateClipCut(clipId: string, inMs: number, outMs: number) {
    setClips((prev) =>
      prev.map((c) => (c.id === clipId ? { ...c, inMs, outMs } : c))
    );
  }

  async function handleSave() {
    if (!title.trim()) {
      toast({ title: "Título obligatorio", variant: "destructive" });
      return;
    }
    if (clips.length === 0) {
      toast({ title: "Agrega al menos un clip", variant: "destructive" });
      return;
    }
    setSaving(true);
    try {
      // 1. Upsert the Avance container.
      const method = isEdit ? "PATCH" : "POST";
      const url = isEdit ? `/api/avances/${avance!.id}` : "/api/avances";
      const body = {
        title: title.trim(),
        description: description.trim() || null,
        hideFromEpg,
        validFrom: validFrom ? new Date(validFrom).toISOString() : null,
        validUntil: validUntil ? new Date(validUntil).toISOString() : null,
        color,
        fadeEnabled,
        fadeInMs,
        fadeOutMs,
      };
      const r = await fetch(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });
      if (!r.ok) {
        const err = await r.json().catch(() => ({}));
        throw new Error(err.error || `HTTP ${r.status}`);
      }
      const saved: Avance = await r.json();

      // 2. For edit mode: diff clips (delete removed, add new, update cuts, reorder).
      // Simpler approach: delete all existing clips, re-create in the right order.
      if (isEdit) {
        // Delete all existing clips (use the API for proper cascade + recompute).
        for (const oldClip of avance!.clips) {
          await fetch(`/api/avances/${avance!.id}/clips/${oldClip.id}`, {
            method: "DELETE",
          });
        }
      }
      // Re-create all clips in order.
      for (let i = 0; i < clips.length; i++) {
        const c = clips[i];
        const r2 = await fetch(`/api/avances/${saved.id}/clips`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            assetId: c.assetId,
            inMs: c.inMs,
            outMs: c.outMs,
          }),
        });
        if (!r2.ok) {
          const err = await r2.json().catch(() => ({}));
          throw new Error(err.error || `clip ${i + 1} failed`);
        }
        // If we have a clip-level cut override, apply it now (the POST auto-clamps).
        const created = await r2.json();
        if (c.inMs !== 0 || c.outMs !== 0) {
          await fetch(`/api/avances/${saved.id}/clips/${created.id}`, {
            method: "PATCH",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ inMs: c.inMs, outMs: c.outMs }),
          });
        }
      }

      // 3. Persist the new order (in case POST appended out of order).
      // The POSTs above already set orderIndex = existingCount which matches our local order.
      // So no extra reorder needed.

      toast({
        title: isEdit ? "Avance actualizado" : "Avance creado",
        description: `${clips.length} clips · ${msToHMMSS(totalDuration)}`,
      });
      onSaved();
      onClose();
    } catch (e) {
      toast({
        title: "Error al guardar",
        description: e instanceof Error ? e.message : "internal error",
        variant: "destructive",
      });
    } finally {
      setSaving(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-3xl gap-0 border-zinc-800 bg-zinc-950 p-0 sm:rounded-xl">
        <DialogHeader className="border-b border-zinc-800 px-5 py-3">
          <DialogTitle className="flex items-center gap-2 text-base text-zinc-100">
            <Clapperboard className="size-4 text-amber-400" />
            {isEdit ? "Editar Avance" : "Nuevo Avance"}
          </DialogTitle>
          <DialogDescription className="text-[11px] text-zinc-500">
            Contenedor multiprograma — los clips se reproducen secuencialmente al aire.
          </DialogDescription>
        </DialogHeader>

        <div className="max-h-[70vh] overflow-y-auto custom-scrollbar px-5 py-4">
          {/* Header fields */}
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            <div className="sm:col-span-2">
              <Label className="text-[11px] uppercase tracking-wider text-zinc-500">
                Título del Avance
              </Label>
              <Input
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="Ej: Avance Especial Nocturno"
                className="mt-1 border-zinc-700 bg-zinc-900 text-zinc-100"
              />
            </div>

            <div className="sm:col-span-2">
              <Label className="text-[11px] uppercase tracking-wider text-zinc-500">
                Descripción (opcional)
              </Label>
              <Textarea
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Notas internas sobre este bloque…"
                className="mt-1 border-zinc-700 bg-zinc-900 text-zinc-100"
                rows={2}
              />
            </div>

            <div className="flex items-center gap-2.5 rounded-md border border-zinc-800 bg-zinc-900/60 p-3">
              <Switch
                checked={hideFromEpg}
                onCheckedChange={setHideFromEpg}
              />
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-1.5 text-xs font-medium text-zinc-200">
                  {hideFromEpg ? (
                    <>
                      <EyeOff className="size-3.5 text-violet-400" />
                      Oculto en EPG
                    </>
                  ) : (
                    <>
                      <Eye className="size-3.5 text-emerald-400" />
                      Visible en EPG
                    </>
                  )}
                </div>
                <div className="mt-0.5 text-[10px] text-zinc-500">
                  {hideFromEpg
                    ? "Fantasma con peso: no aparece en la guía, pero su duración empuja al siguiente programa."
                    : "Se comporta como un programa normal en la guía."}
                </div>
              </div>
            </div>

            <div className="rounded-md border border-zinc-800 bg-zinc-900/60 p-3">
              <Label className="text-[10px] uppercase tracking-wider text-zinc-500">
                Color
              </Label>
              <div className="mt-1.5 flex items-center gap-1.5">
                {COLOR_OPTIONS.map((c) => (
                  <button
                    key={c.value}
                    type="button"
                    onClick={() => setColor(c.value)}
                    className={cn(
                      "size-5 rounded-full ring-2 transition-all",
                      c.className,
                      color === c.value
                        ? "ring-white scale-110"
                        : "ring-transparent opacity-60 hover:opacity-100"
                    )}
                    aria-label={c.label}
                    title={c.label}
                  />
                ))}
              </div>
            </div>

            {/* ---- Fade in/out ----
                 Default: disabled (fadeEnabled=false). When enabled, defaults to 500ms
                 with a range of 0-1000ms. Applied at the very start (fade-in) and
                 very end (fade-out) of the Avance container. */}
            <div className="sm:col-span-2 rounded-md border border-zinc-800 bg-zinc-900/60 p-3">
              <div className="flex items-center gap-2.5">
                <Switch
                  checked={fadeEnabled}
                  onCheckedChange={setFadeEnabled}
                />
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-1.5 text-xs font-medium text-zinc-200">
                    <Waves className={cn("size-3.5", fadeEnabled ? "text-sky-400" : "text-zinc-500")} />
                    Fade In / Fade Out
                    {fadeEnabled ? (
                      <span className="rounded bg-sky-500/15 px-1.5 py-0.5 text-[9px] font-medium text-sky-300">
                        Activado
                      </span>
                    ) : (
                      <span className="rounded bg-zinc-700/40 px-1.5 py-0.5 text-[9px] font-medium text-zinc-400">
                        Desactivado
                      </span>
                    )}
                  </div>
                  <div className="mt-0.5 text-[10px] text-zinc-500">
                    Transición suave de audio/video al inicio y fin del Avance.
                  </div>
                </div>
              </div>

              {fadeEnabled && (
                <div className="mt-3 grid grid-cols-2 gap-4">
                  {/* Fade In slider */}
                  <div>
                    <div className="mb-1 flex items-center justify-between">
                      <Label className="text-[10px] uppercase tracking-wider text-zinc-500">
                        Fade In
                      </Label>
                      <span className="font-mono text-[11px] tabular-nums text-sky-300">
                        {fadeInMs}ms · {(fadeInMs / 1000).toFixed(2)}s
                      </span>
                    </div>
                    <input
                      type="range"
                      min={0}
                      max={1000}
                      step={50}
                      value={fadeInMs}
                      onChange={(e) => setFadeInMs(Number(e.target.value))}
                      className="h-2 w-full cursor-pointer appearance-none rounded-full bg-zinc-800 accent-sky-500"
                      aria-label="Duración del fade in (milisegundos)"
                    />
                    <div className="mt-1 flex justify-between text-[9px] text-zinc-600">
                      <span>0ms</span>
                      <span>500ms (default)</span>
                      <span>1000ms</span>
                    </div>
                  </div>
                  {/* Fade Out slider */}
                  <div>
                    <div className="mb-1 flex items-center justify-between">
                      <Label className="text-[10px] uppercase tracking-wider text-zinc-500">
                        Fade Out
                      </Label>
                      <span className="font-mono text-[11px] tabular-nums text-sky-300">
                        {fadeOutMs}ms · {(fadeOutMs / 1000).toFixed(2)}s
                      </span>
                    </div>
                    <input
                      type="range"
                      min={0}
                      max={1000}
                      step={50}
                      value={fadeOutMs}
                      onChange={(e) => setFadeOutMs(Number(e.target.value))}
                      className="h-2 w-full cursor-pointer appearance-none rounded-full bg-zinc-800 accent-sky-500"
                      aria-label="Duración del fade out (milisegundos)"
                    />
                    <div className="mt-1 flex justify-between text-[9px] text-zinc-600">
                      <span>0ms</span>
                      <span>500ms (default)</span>
                      <span>1000ms</span>
                    </div>
                  </div>
                </div>
              )}
            </div>

            <div>
              <Label className="text-[11px] uppercase tracking-wider text-zinc-500">
                Vigente desde
              </Label>
              <Input
                type="date"
                value={validFrom}
                onChange={(e) => setValidFrom(e.target.value)}
                className="mt-1 border-zinc-700 bg-zinc-900 text-zinc-100"
              />
            </div>
            <div>
              <Label className="text-[11px] uppercase tracking-wider text-zinc-500">
                Vigente hasta
              </Label>
              <Input
                type="date"
                value={validUntil}
                onChange={(e) => setValidUntil(e.target.value)}
                className="mt-1 border-zinc-700 bg-zinc-900 text-zinc-100"
              />
            </div>
          </div>

          {/* Clips list */}
          <div className="mt-5">
            <div className="mb-2 flex items-center gap-2">
              <span className="text-[11px] font-semibold uppercase tracking-wider text-zinc-500">
                Videos en este contenedor
              </span>
              <span className="h-px flex-1 bg-zinc-800" />
              <span className="text-[11px] text-zinc-500">
                {clips.length} clip{clips.length === 1 ? "" : "s"} · {msToHMMSS(totalDuration)}
              </span>
            </div>

            <DndContext
              sensors={sensors}
              collisionDetection={closestCenter}
              onDragEnd={handleDragEnd}
            >
              <SortableContext
                items={clips.map((c) => c.id)}
                strategy={verticalListSortingStrategy}
              >
                <div className="space-y-1.5">
                  {clips.map((clip, idx) => (
                    <SortableClipRow
                      key={clip.id}
                      clip={clip}
                      index={idx}
                      onEditCut={() => {
                        setCutClip(clip);
                        setCutOpen(true);
                      }}
                      onRemove={() => removeClip(clip.id)}
                    />
                  ))}
                </div>
              </SortableContext>
            </DndContext>

            {/* Add clip */}
            <div className="mt-2 flex items-center gap-2 rounded-md border border-dashed border-zinc-700 bg-zinc-900/40 p-2">
              <Film className="size-4 shrink-0 text-zinc-500" />
              <Select value={selectedAssetId} onValueChange={setSelectedAssetId}>
                <SelectTrigger className="h-8 flex-1 border-zinc-700 bg-zinc-900 text-xs text-zinc-200">
                  <SelectValue placeholder="Seleccionar video para agregar…" />
                </SelectTrigger>
                <SelectContent className="max-h-72 border-zinc-800 bg-zinc-950">
                  {assets.map((a) => (
                    <SelectItem
                      key={a.id}
                      value={a.id}
                      className="text-xs text-zinc-200 focus:bg-zinc-800"
                    >
                      <span className="flex items-center gap-2">
                        <span className={cn(
                          "size-1.5 rounded-full",
                          a.category === "PROGRAM" && "bg-amber-500",
                          a.category === "FILLER" && "bg-zinc-400",
                          a.category === "SPOT" && "bg-rose-500",
                          a.category === "BUMPER" && "bg-sky-500"
                        )} />
                        <span className="truncate">{a.title}</span>
                        <span className="ml-auto text-[10px] text-zinc-500">
                          {msToHMMSS(a.durationMs)}
                        </span>
                      </span>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Button
                type="button"
                size="sm"
                variant="default"
                className="h-8 gap-1 bg-amber-500 text-zinc-950 hover:bg-amber-400"
                onClick={addClip}
                disabled={!selectedAssetId}
              >
                <Plus className="size-3.5" />
                Agregar
              </Button>
            </div>
          </div>

          {/* Cut editor dialog */}
          {cutClip && (
            <ClipCutEditor
              clip={cutClip}
              open={cutOpen}
              onClose={() => {
                setCutOpen(false);
                setCutClip(null);
              }}
              onSave={(inMs, outMs, clamped) => {
                updateClipCut(cutClip.id, inMs, outMs);
                if (clamped.inMs || clamped.outMs) {
                  toast({
                    title: "Corte ajustado",
                    description:
                      "El marcador superaba la duración del video y fue recortado automáticamente.",
                  });
                }
                setCutOpen(false);
                setCutClip(null);
              }}
            />
          )}
        </div>

        <DialogFooter className="border-t border-zinc-800 px-5 py-3">
          <div className="mr-auto flex items-center gap-2 text-[11px] text-zinc-500">
            <Clock className="size-3" />
            Duración total: <span className="font-mono tabular-nums text-zinc-300">{msToHMMSS(totalDuration)}</span>
            <span className="text-zinc-700">(auto-calculada)</span>
          </div>
          <Button
            variant="ghost"
            size="sm"
            className="text-zinc-400 hover:bg-zinc-800 hover:text-zinc-100"
            onClick={onClose}
            disabled={saving}
          >
            Cancelar
          </Button>
          <Button
            size="sm"
            className="gap-1.5 bg-amber-500 text-zinc-950 hover:bg-amber-400"
            onClick={handleSave}
            disabled={saving || !title.trim() || clips.length === 0}
          >
            {saving ? <Spinner /> : <Save className="size-3.5" />}
            {isEdit ? "Guardar cambios" : "Crear Avance"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// =====================================================================
// Main module export
// =====================================================================
export function AvancesModule() {
  const { toast } = useToast();
  const avancesAsync = useAsync<Avance[]>("/api/avances");
  // Fetch active renders (non-expired). We poll faster when there are renders in progress.
  const rendersAsync = useAsync<RenderedAvance[]>("/api/renders?active=true");
  const [editorOpen, setEditorOpen] = useState(false);
  const [editingAvance, setEditingAvance] = useState<Avance | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<Avance | null>(null);
  // Track which Avances are currently being rendered (for button disabled state).
  const [renderingAvanceIds, setRenderingAvanceIds] = useState<Set<string>>(new Set());

  // Build a map of avanceId → most recent active render.
  const rendersByAvanceId = useMemo(() => {
    const map = new Map<string, RenderedAvance>();
    for (const r of rendersAsync.data ?? []) {
      // Keep only the most recent render per avanceId.
      const existing = map.get(r.avanceId);
      if (!existing || new Date(r.createdAt) > new Date(existing.createdAt)) {
        map.set(r.avanceId, r);
      }
    }
    return map;
  }, [rendersAsync.data]);

  // Check if any renders are in progress → poll faster.
  const hasRenderingInProgress = useMemo(() => {
    return Array.from(rendersByAvanceId.values()).some(
      (r) => r.status === "rendering" || r.status === "pending"
    );
  }, [rendersByAvanceId]);

  // Auto-poll renders every 2s while something is rendering, otherwise every 30s.
  useEffect(() => {
    if (!hasRenderingInProgress) return;
    const interval = setInterval(() => {
      rendersAsync.refresh();
    }, 2000);
    return () => clearInterval(interval);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [hasRenderingInProgress]);

  // Clean up renderingAvanceIds when renders complete.
  useEffect(() => {
    setRenderingAvanceIds((prev) => {
      const next = new Set(prev);
      for (const id of next) {
        const render = rendersByAvanceId.get(id);
        if (render && (render.status === "completed" || render.status === "failed")) {
          next.delete(id);
        }
      }
      return next.size === prev.size ? prev : next;
    });
  }, [rendersByAvanceId]);

  const refreshAll = async () => {
    await Promise.all([avancesAsync.refresh(), rendersAsync.refresh()]);
  };

  function openCreate() {
    setEditingAvance(null);
    setEditorOpen(true);
  }
  function openEdit(a: Avance) {
    setEditingAvance(a);
    setEditorOpen(true);
  }

  // Trigger a render for an Avance.
  async function handleRender(avance: Avance) {
    // Compute today's date in Venezuela timezone.
    const now = new Date();
    const caracas = new Date(now.getTime() - 4 * 3600 * 1000);
    const date = caracas.toISOString().slice(0, 10);

    setRenderingAvanceIds((prev) => new Set(prev).add(avance.id));
    try {
      const r = await fetch(`/api/avances/${avance.id}/render`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ date, force: true }),
      });
      if (!r.ok) {
        const err = await r.json().catch(() => null);
        throw new Error(err?.error || `HTTP ${r.status}`);
      }
      const data = await r.json();
      toast({
        title: "Render iniciado",
        description: `"${avance.title}" se está procesando…`,
      });
      // Immediately refresh renders to pick up the "pending" status.
      rendersAsync.refresh();
    } catch (e) {
      toast({
        title: "Error al iniciar render",
        description: e instanceof Error ? e.message : "internal error",
        variant: "destructive",
      });
      setRenderingAvanceIds((prev) => {
        const next = new Set(prev);
        next.delete(avance.id);
        return next;
      });
    }
  }

  async function confirmDelete() {
    if (!deleteTarget) return;
    try {
      const r = await fetch(`/api/avances/${deleteTarget.id}`, { method: "DELETE" });
      if (!r.ok) throw new Error(`HTTP ${r.status}`);
      toast({
        title: "Avance eliminado",
        description: `"${deleteTarget.title}" fue borrado.`,
      });
      avancesAsync.refresh();
    } catch (e) {
      toast({
        title: "Error al eliminar",
        description: e instanceof Error ? e.message : "internal error",
        variant: "destructive",
      });
    } finally {
      setDeleteTarget(null);
    }
  }

  const avances = avancesAsync.data ?? [];
  const totalClips = avances.reduce((s, a) => s + a.clips.length, 0);
  const totalDur = avances.reduce((s, a) => s + a.totalDurationMs, 0);
  const hiddenCount = avances.filter((a) => a.hideFromEpg).length;

  return (
    <div className="flex h-full min-h-0 flex-col gap-3">
      {/* Header */}
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h2 className="text-sm font-semibold text-zinc-100">
            Bloques Avance
            <span className="ml-2 text-[11px] font-normal text-zinc-500">
              Avance Programático
            </span>
          </h2>
          <p className="mt-0.5 text-[11px] text-zinc-500">
            Contenedores multiprograma con cortes I/O por clip. Independientes de los spots.
          </p>
        </div>
        <div className="flex items-center gap-2">
          {/* Stats */}
          <div className="hidden items-center gap-3 rounded-md border border-zinc-800 bg-zinc-900/60 px-3 py-1.5 text-[11px] text-zinc-400 sm:flex">
            <span>{avances.length} avances</span>
            <span className="text-zinc-700">·</span>
            <span>{totalClips} clips</span>
            <span className="text-zinc-700">·</span>
            <span>{hiddenCount} ocultos</span>
            <span className="text-zinc-700">·</span>
            <span className="font-mono tabular-nums">{msToHMMSS(totalDur)}</span>
          </div>
          <Button
            size="sm"
            className="gap-1.5 bg-amber-500 text-zinc-950 hover:bg-amber-400"
            onClick={openCreate}
          >
            <Plus className="size-3.5" />
            Nuevo Avance
          </Button>
        </div>
      </div>

      {/* List */}
      <div className="min-h-0 flex-1 overflow-y-auto custom-scrollbar pr-1">
        {avancesAsync.loading && avances.length === 0 && (
          <div className="flex h-full items-center justify-center">
            <Spinner className="size-6" />
          </div>
        )}
        {!avancesAsync.loading && avances.length === 0 && (
          <Card className="flex flex-col items-center justify-center gap-2 border-dashed border-zinc-800 bg-zinc-900/30 p-8 text-center">
            <Clapperboard className="size-8 text-zinc-700" />
            <p className="text-sm font-medium text-zinc-400">No hay Avances creados</p>
            <p className="text-[11px] text-zinc-600">
              Crea tu primer Bloque Avance para empezar a programarlo en la parrilla.
            </p>
            <Button
              size="sm"
              className="mt-2 gap-1.5 bg-amber-500 text-zinc-950 hover:bg-amber-400"
              onClick={openCreate}
            >
              <Plus className="size-3.5" />
              Crear primer Avance
            </Button>
          </Card>
        )}
        <div className="space-y-2">
          {avances.map((a) => (
            <AvanceRow
              key={a.id}
              avance={a}
              render={rendersByAvanceId.get(a.id)}
              onEdit={() => openEdit(a)}
              onDelete={() => setDeleteTarget(a)}
              onRender={() => handleRender(a)}
              rendering={renderingAvanceIds.has(a.id)}
            />
          ))}
        </div>
      </div>

      {/* Editor */}
      <AvanceEditor
        avance={editingAvance}
        open={editorOpen}
        onClose={() => setEditorOpen(false)}
        onSaved={refreshAll}
      />

      {/* Delete confirm */}
      <AlertDialog open={!!deleteTarget} onOpenChange={(o) => !o && setDeleteTarget(null)}>
        <AlertDialogContent className="border-zinc-800 bg-zinc-950">
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2 text-zinc-100">
              <AlertTriangle className="size-4 text-rose-400" />
              Eliminar Avance
            </AlertDialogTitle>
            <AlertDialogDescription className="text-zinc-400">
              ¿Seguro que quieres eliminar <strong className="text-zinc-200">{deleteTarget?.title}</strong>?
              Se borrarán los {deleteTarget?.clips.length ?? 0} clips internos. Los slots de la parrilla
              que lo referencian quedarán como programa vacío (no se borran).
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="border-zinc-700 bg-transparent text-zinc-300 hover:bg-zinc-800">
              Cancelar
            </AlertDialogCancel>
            <AlertDialogAction
              className="bg-rose-600 text-white hover:bg-rose-500"
              onClick={confirmDelete}
            >
              Eliminar
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
