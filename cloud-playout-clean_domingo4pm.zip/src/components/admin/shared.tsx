"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { cn } from "@/lib/utils";
import { msToHMMSS, msToWallclock } from "@/lib/playout";

// ---- Small shared UI helpers used across all admin modules ----

export function Thumbnail({
  url,
  className,
  title,
}: {
  url: string | null;
  className?: string;
  title?: string;
}) {
  // Determine if url is an image path (starts with /api/media/ or is a URL).
  const isImage = url && (url.startsWith("/api/media/") || url.startsWith("http") || url.startsWith("/uploads"));

  if (isImage) {
    return (
      <div
        title={title}
        className={cn(
          "shrink-0 overflow-hidden rounded-md border border-zinc-700 bg-zinc-800/80",
          className
        )}
      >
        <img
          src={url || undefined}
          alt={title || "thumbnail"}
          className="h-full w-full object-cover"
          loading="lazy"
          onError={(e) => {
            // If image fails to load, hide it and show fallback emoji.
            (e.currentTarget as HTMLImageElement).style.display = "none";
            const parent = (e.currentTarget as HTMLImageElement).parentElement;
            if (parent) {
              parent.classList.add("flex", "items-center", "justify-center");
              parent.innerHTML = '<span aria-hidden>🎬</span>';
            }
          }}
        />
      </div>
    );
  }

  // Fallback: emoji thumbnail (for legacy assets with emoji thumbnails).
  return (
    <div
      title={title}
      className={cn(
        "flex size-9 shrink-0 items-center justify-center rounded-md border border-zinc-700 bg-zinc-800/80 text-base leading-none",
        className
      )}
    >
      <span aria-hidden>{url || "🎬"}</span>
    </div>
  );
}

export function Spinner({ className }: { className?: string }) {
  return (
    <span
      className={cn(
        "inline-block size-4 animate-spin rounded-full border-2 border-zinc-600 border-t-amber-400",
        className
      )}
      aria-hidden
    />
  );
}

// Category → badge styling (broadcast palette: amber=program, zinc=filler, rose=spot, sky=bumper)
export function CategoryBadge({ category }: { category: string }) {
  if (category === "PROGRAM")
    return (
      <span className="inline-flex items-center rounded-md border border-amber-500/40 bg-amber-500/15 px-1.5 py-0.5 text-[11px] font-medium text-amber-300">
        Programa
      </span>
    );
  if (category === "FILLER")
    return (
      <span className="inline-flex items-center rounded-md border border-zinc-600/60 bg-zinc-700/40 px-1.5 py-0.5 text-[11px] font-medium text-zinc-300">
        Planta
      </span>
    );
  if (category === "BUMPER")
    return (
      <span className="inline-flex items-center rounded-md border border-sky-500/40 bg-sky-500/15 px-1.5 py-0.5 text-[11px] font-medium text-sky-300">
        Bumper
      </span>
    );
  return (
    <span className="inline-flex items-center rounded-md border border-rose-500/40 bg-rose-500/15 px-1.5 py-0.5 text-[11px] font-medium text-rose-300">
      Spot
    </span>
  );
}

// Convert seconds (user input) to milliseconds.
export function secondsToMs(s: number | string): number {
  const n = typeof s === "string" ? parseFloat(s) : s;
  if (!isFinite(n) || n < 0) return 0;
  return Math.round(n * 1000);
}

// Shift a YYYY-MM-DD by N days (UTC math, no tz surprises).
export function shiftDate(dateKey: string, days: number): string {
  const [y, m, d] = dateKey.split("-").map(Number);
  const dt = new Date(Date.UTC(y, m - 1, d));
  dt.setUTCDate(dt.getUTCDate() + days);
  const yy = dt.getUTCFullYear();
  const mm = String(dt.getUTCMonth() + 1).padStart(2, "0");
  const dd = String(dt.getUTCDate()).padStart(2, "0");
  return `${yy}-${mm}-${dd}`;
}

// Tiny async-data hook with manual refresh.
export function useAsync<T>(url: string | null, opts?: { intervalMs?: number }) {
  const [data, setData] = useState<T | null>(null);
  const [loading, setLoading] = useState<boolean>(!!url);
  const [error, setError] = useState<string | null>(null);
  const urlRef = useRef(url);
  urlRef.current = url;

  const refresh = useCallback(async () => {
    if (!urlRef.current) return;
    try {
      const r = await fetch(urlRef.current, { cache: "no-store" });
      if (!r.ok) throw new Error(`HTTP ${r.status}`);
      const json = (await r.json()) as T;
      setData(json);
      setError(null);
    } catch (e) {
      setError(e instanceof Error ? e.message : "error");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    let active = true;
    setLoading(true);
    const tick = async () => {
      if (!url) return;
      try {
        const r = await fetch(url, { cache: "no-store" });
        if (!active) return;
        if (!r.ok) throw new Error(`HTTP ${r.status}`);
        const json = (await r.json()) as T;
        setData(json);
        setError(null);
      } catch (e) {
        if (active) setError(e instanceof Error ? e.message : "error");
      } finally {
        if (active) setLoading(false);
      }
    };
    tick();
    const interval = opts?.intervalMs
      ? setInterval(tick, opts.intervalMs)
      : undefined;
    return () => {
      active = false;
      if (interval) clearInterval(interval);
    };
  }, [url, opts?.intervalMs]);

  return { data, loading, error, refresh, setData };
}

// Format helpers re-exported for convenience.
export { msToWallclock, msToHMMSS };

// Format ms-from-midnight as "HH:MM" for compact EPG displays.
export function msToHHMM(ms: number): string {
  return msToWallclock(ms).slice(0, 5);
}
