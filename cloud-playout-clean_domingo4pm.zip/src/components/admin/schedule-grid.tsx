"use client";

import { useEffect, useMemo, useState } from "react";
import {
  ChevronLeft,
  ChevronRight,
  ChevronUp,
  ChevronDown,
  Plus,
  Trash2,
  Clock,
  CalendarClock,
  Megaphone,
  Layers,
  Film,
  Zap,
  X,
  Copy,
  GripVertical,
  Save,
  Clapperboard,
} from "lucide-react";
import {
  DndContext,
  closestCenter,
  KeyboardSensor,
  PointerSensor,
  useSensor,
  useSensors,
  type DragEndEvent,
} from "@dnd-kit/core";
import {
  arrayMove,
  SortableContext,
  sortableKeyboardCoordinates,
  useSortable,
  verticalListSortingStrategy,
} from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { useToast } from "@/hooks/use-toast";
import {
  useAsync,
  Thumbnail,
  CategoryBadge,
  Spinner,
  secondsToMs,
  msToWallclock,
  msToHMMSS,
  shiftDate,
} from "./shared";
import { venezuelaDateKey } from "@/lib/playout";
import { CuePointPreview } from "./cue-point-preview";
import type { Asset, ScheduleSlot, AdBreak, PlayoutState, Avance } from "@/lib/types";

// Helper: extract a friendly Spanish error message from a failed fetch response.
// Avoids dumping raw Prisma stack traces / JSON internals into toasts.
async function extractError(r: Response, fallback: string): Promise<string> {
  try {
    const body = await r.json();
    if (body?.error && typeof body.error === "string") return body.error;
  } catch {
    /* not JSON */
  }
  return `${fallback} (HTTP ${r.status})`;
}

// Snap-to-tail: each slot's start = previous end.
// For Avance slots: end = start + avance.totalDurationMs (sum of clip cuts, no cue points).
// For program slots: end = start + asset.dur + sum(cuePoint ad break durations).
function computeSchedule(slots: ScheduleSlot[]) {
  let cursor = 0;
  return slots.map((slot, idx) => {
    const startMs = cursor;
    const cueAdDur = slot.cuePoints.reduce(
      (sum, cp) =>
        sum +
        cp.adBreak.entries.reduce((s, e) => s + e.asset.durationMs, 0),
      0
    );
    // Avance slots have no cue points — duration is the container's total.
    const slotDur = slot.slotType === "avance" && slot.avance
      ? slot.avance.totalDurationMs
      : slot.asset.durationMs;
    const endMs = startMs + slotDur + cueAdDur;
    cursor = endMs;
    return { slot, idx, startMs, endMs, cueAdDur };
  });
}

function formatHours(ms: number): string {
  return (ms / 3600000).toFixed(1) + "h";
}

export function ScheduleGrid() {
  const { toast } = useToast();
  const today = useMemo(() => venezuelaDateKey(), []);
  const [date, setDate] = useState(today);
  const [expanded, setExpanded] = useState<string | null>(null);

  const scheduleAsync = useAsync<ScheduleSlot[]>(`/api/schedule?date=${date}`);
  // Fetch live playout state to highlight the on-air slot.
  const playoutAsync = useAsync<PlayoutState>("/api/playout", { intervalMs: 2000 });
  const programsAsync = useAsync<Asset[]>(
    `/api/assets?category=PROGRAM`
  );
  const bumpersAsync = useAsync<Asset[]>(
    `/api/assets?category=BUMPER`
  );
  const fillersAsync = useAsync<Asset[]>(`/api/fillers`);
  const breaksAsync = useAsync<AdBreak[]>(`/api/adbreaks`);
  // Avance containers (for the unified "Añadir" picker).
  const avancesAsync = useAsync<Avance[]>(`/api/avances`);

  // --- Local edit mode (drag-drop without immediate save) ---
  // localSlots holds the locally-reordered slots. When null, we use server data.
  const [localSlots, setLocalSlots] = useState<ScheduleSlot[] | null>(null);
  const [dirty, setDirty] = useState(false);
  const [saving, setSaving] = useState(false);

  // Reset local state when date changes.
  useEffect(() => {
    setLocalSlots(null);
    setDirty(false);
  }, [date]);

  // The rows we actually display: local if dirty, else server.
  const displayRows = useMemo(() => {
    const source = localSlots ?? scheduleAsync.data ?? [];
    return computeSchedule(source);
  }, [localSlots, scheduleAsync.data]);
  const totalMs = displayRows.length ? displayRows[displayRows.length - 1].endMs : 0;

  // Determine which slot is currently on-air (from the live playout state).
  // Only relevant when viewing today's schedule.
  const onAirSlotId = useMemo(() => {
    const seg = playoutAsync.data?.currentSegment;
    if (!seg) return null;
    // Only highlight if we're viewing today's schedule.
    if (date !== today) return null;
    return seg.slotId ?? null;
  }, [playoutAsync.data?.currentSegment, date, today]);

  // --- Unified "Añadir" dialog (Programa / Bumper / Avance) ---
  const [addOpen, setAddOpen] = useState(false);
  // Selected type inside the unified picker.
  const [addType, setAddType] = useState<"program" | "bumper" | "avance">("program");
  const [addAssetId, setAddAssetId] = useState("");
  const [addAvanceId, setAddAvanceId] = useState("");
  const [adding, setAdding] = useState(false);

  const openAdd = () => {
    setAddType("program");
    setAddAssetId(programsAsync.data?.[0]?.id ?? "");
    setAddAvanceId(avancesAsync.data?.[0]?.id ?? "");
    setAddOpen(true);
  };

  // When the user switches type inside the dialog, reset the corresponding selection.
  const switchAddType = (t: "program" | "bumper" | "avance") => {
    setAddType(t);
    if (t === "program") setAddAssetId(programsAsync.data?.[0]?.id ?? "");
    if (t === "bumper") setAddAssetId(bumpersAsync.data?.[0]?.id ?? "");
    if (t === "avance") setAddAvanceId(avancesAsync.data?.[0]?.id ?? "");
  };

  const submitAdd = async () => {
    // Guard: don't allow adding while there are unsaved local reorders.
    // The local reorder changes orderIndex values; if we POST a new slot now,
    // the backend doesn't know about the new local order and may compute a
    // colliding orderIndex → "Unique constraint failed on (date, orderIndex)".
    if (dirty) {
      toast({
        title: "Tienes cambios sin guardar",
        description:
          "Guarda o descarta los cambios pendientes en la parrilla antes de añadir un nuevo ítem.",
        variant: "destructive",
      });
      return;
    }

    if (addType === "avance") {
      if (!addAvanceId) {
        toast({ title: "Selecciona un Avance", variant: "destructive" });
        return;
      }
      setAdding(true);
      try {
        const r = await fetch(`/api/schedule`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ date, slotType: "avance", avanceId: addAvanceId }),
        });
        if (!r.ok) {
          const err = await r.json().catch(() => null);
          throw new Error(
            err?.error ||
              `No se pudo añadir el Avance (HTTP ${r.status}). Inténtalo de nuevo.`
          );
        }
        toast({ title: "Avance añadido", description: "Añadido al final de la parrilla." });
        await scheduleAsync.refresh();
        setAddOpen(false);
      } catch (e) {
        toast({
          title: "No se pudo añadir el Avance",
          description: e instanceof Error ? e.message : "internal error",
          variant: "destructive",
        });
      } finally {
        setAdding(false);
      }
      return;
    }

    // program / bumper share the same payload shape (assetId only).
    if (!addAssetId) {
      toast({
        title: addType === "bumper" ? "Selecciona un bumper" : "Selecciona un programa",
        variant: "destructive",
      });
      return;
    }
    setAdding(true);
    try {
      const r = await fetch(`/api/schedule`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ date, assetId: addAssetId }),
      });
      if (!r.ok) {
        const err = await r.json().catch(() => null);
        throw new Error(
          err?.error ||
            `No se pudo añadir el ${addType === "bumper" ? "bumper" : "programa"} (HTTP ${r.status}). Inténtalo de nuevo.`
        );
      }
      toast({
        title: addType === "bumper" ? "Bumper añadido" : "Programa añadido",
        description: "Añadido al final de la parrilla.",
      });
      await scheduleAsync.refresh();
      setAddOpen(false);
    } catch (e) {
      toast({
        title: addType === "bumper" ? "No se pudo añadir el bumper" : "No se pudo añadir el programa",
        description: e instanceof Error ? e.message : "internal error",
        variant: "destructive",
      });
    } finally {
      setAdding(false);
    }
  };

  // Legacy alias kept for the empty-state "Añadir el primer programa" button.
  const submitAddProgram = submitAdd;

  // --- Add filler (planta) dialog ---
  const [fillerOpen, setFillerOpen] = useState(false);
  const [fillerAssetId, setFillerAssetId] = useState("");
  const [addingFiller, setAddingFiller] = useState(false);

  const openFiller = () => {
    setFillerAssetId(fillersAsync.data?.[0]?.id ?? "");
    setFillerOpen(true);
  };

  const submitAddFiller = async () => {
    if (!fillerAssetId) {
      toast({ title: "No hay activos de planta", variant: "destructive" });
      return;
    }
    setAddingFiller(true);
    try {
      const r = await fetch(`/api/schedule`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ date, assetId: fillerAssetId, fillerLoop: true }),
      });
      if (!r.ok) throw new Error(await extractError(r, "No se pudo añadir el bloque de planta"));
      toast({ title: "Bloque de planta añadido" });
      await scheduleAsync.refresh();
      setFillerOpen(false);
    } catch (e) {
      toast({
        title: "Error",
        description: e instanceof Error ? e.message : "internal error",
        variant: "destructive",
      });
    } finally {
      setAddingFiller(false);
    }
  };

  // --- Add bumper dialog (legacy — now unified into the "Añadir" picker) ---
  // Bumper submission now flows through submitAdd() with addType === "bumper".
  // Keeping openBumper() as a thin wrapper that opens the unified picker on the bumper tab.
  const openBumper = () => {
    switchAddType("bumper");
    setAddOpen(true);
  };

  // --- Move slot up/down (local edit — no HTTP until "Guardar cambios") ---
  const moveSlot = (idx: number, dir: -1 | 1) => {
    const target = idx + dir;
    if (target < 0 || target >= displayRows.length) return;
    const source = localSlots ?? scheduleAsync.data ?? [];
    const newSlots = arrayMove(source, idx, target);
    setLocalSlots(newSlots);
    setDirty(true);
  };

  // --- Drag and drop reorder (local edit — no HTTP until "Guardar cambios") ---
  const sensors = useSensors(
    useSensor(PointerSensor, { activationConstraint: { distance: 5 } }),
    useSensor(KeyboardSensor, { coordinateGetter: sortableKeyboardCoordinates })
  );

  const handleDragEnd = (event: DragEndEvent) => {
    const { active, over } = event;
    if (!over || active.id === over.id) return;
    const source = localSlots ?? scheduleAsync.data ?? [];
    const oldIndex = source.findIndex((s) => s.id === active.id);
    const newIndex = source.findIndex((s) => s.id === over.id);
    if (oldIndex === -1 || newIndex === -1) return;

    const newSlots = arrayMove(source, oldIndex, newIndex);
    setLocalSlots(newSlots);
    setDirty(true);
  };

  // --- Save all changes to the server in a single batch request ---
  const saveChanges = async () => {
    if (!dirty || !localSlots) return;
    setSaving(true);
    try {
      const slotIds = localSlots.map((s) => s.id);
      const r = await fetch(`/api/schedule/reorder`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ date, slotIds }),
      });
      if (!r.ok) {
        const err = await r.json();
        throw new Error(err.error || "Error al guardar");
      }
      toast({
        title: "Cambios guardados",
        description: `${slotIds.length} slots reordenados correctamente.`,
      });
      setDirty(false);
      setLocalSlots(null);
      await scheduleAsync.refresh();
    } catch (e) {
      toast({
        title: "Error al guardar",
        description: e instanceof Error ? e.message : "internal error",
        variant: "destructive",
      });
    } finally {
      setSaving(false);
    }
  };

  // --- Discard local changes ---
  const discardChanges = () => {
    setLocalSlots(null);
    setDirty(false);
  };

  // --- Delete slot ---
  const [deleting, setDeleting] = useState<ScheduleSlot | null>(null);
  const confirmDelete = async () => {
    if (!deleting) return;
    try {
      const r = await fetch(`/api/schedule/${deleting.id}`, {
        method: "DELETE",
      });
      if (!r.ok) throw new Error(await extractError(r, "No se pudo eliminar el slot"));
      toast({ title: "Slot eliminado" });
      await scheduleAsync.refresh();
    } catch (e) {
      toast({
        title: "Error",
        description: e instanceof Error ? e.message : "internal error",
        variant: "destructive",
      });
    } finally {
      setDeleting(null);
    }
  };

  // --- Cue point editor ---
  const [cueOpen, setCueOpen] = useState<string | null>(null);
  const [cueOffsetMs, setCueOffsetMs] = useState<number>(0);
  const [cueBreakId, setCueBreakId] = useState("");
  const [addingCue, setAddingCue] = useState(false);

  const openCueDialog = (slotId: string) => {
    const slot = displayRows.find((r) => r.slot.id === slotId)?.slot;
    setCueOpen(slotId);
    // Default offset: middle of program (so the admin sees a sensible starting point).
    const mid = slot ? Math.floor(slot.asset.durationMs / 2) : 0;
    setCueOffsetMs(mid);
    setCueBreakId(breaksAsync.data?.[0]?.id ?? "");
  };

  const cueSlot = displayRows.find((r) => r.slot.id === cueOpen)?.slot ?? null;
  const cueExistingOffsets = useMemo(
    () => (cueSlot ? cueSlot.cuePoints.map((c) => c.offsetMs) : []),
    [cueSlot]
  );

  const submitCue = async () => {
    if (!cueOpen) return;
    if (!cueBreakId || cueOffsetMs <= 0) {
      toast({ title: "Faltan datos", variant: "destructive" });
      return;
    }
    setAddingCue(true);
    try {
      const r = await fetch(`/api/cuepoints`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          scheduleSlotId: cueOpen,
          offsetMs: cueOffsetMs,
          adBreakId: cueBreakId,
        }),
      });
      if (!r.ok) throw new Error(await extractError(r, "No se pudo añadir el corte comercial"));
      toast({ title: "Corte comercial añadido" });
      await scheduleAsync.refresh();
      setCueOpen(null);
    } catch (e) {
      toast({
        title: "Error",
        description: e instanceof Error ? e.message : "internal error",
        variant: "destructive",
      });
    } finally {
      setAddingCue(false);
    }
  };

  const deleteCue = async (slotId: string, cueId: string) => {
    try {
      const r = await fetch(`/api/cuepoints/${cueId}`, { method: "DELETE" });
      if (!r.ok) throw new Error(await extractError(r, "No se pudo eliminar el corte"));
      toast({ title: "Corte eliminado" });
      await scheduleAsync.refresh();
    } catch (e) {
      toast({
        title: "Error",
        description: e instanceof Error ? e.message : "internal error",
        variant: "destructive",
      });
    }
  };

  // --- Copy day dialog ---
  const [copyOpen, setCopyOpen] = useState(false);
  const [copyTargetDate, setCopyTargetDate] = useState<string>(shiftDate(today, 1));
  const [copyIncludeCues, setCopyIncludeCues] = useState(true);
  const [copyReplaceTarget, setCopyReplaceTarget] = useState(false);
  const [copying, setCopying] = useState(false);

  const openCopyDialog = () => {
    setCopyTargetDate(shiftDate(date, 1));
    setCopyIncludeCues(true);
    setCopyOpen(true);
  };

  const submitCopyDay = async () => {
    if (!copyTargetDate) {
      toast({ title: "Selecciona una fecha destino", variant: "destructive" });
      return;
    }
    if (copyTargetDate === date) {
      toast({
        title: "La fecha destino debe ser distinta a la origen",
        variant: "destructive",
      });
      return;
    }
    setCopying(true);
    try {
      const r = await fetch(`/api/schedule/copy`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          sourceDate: date,
          targetDate: copyTargetDate,
          includeCuePoints: copyIncludeCues,
          replaceTarget: copyReplaceTarget,
        }),
      });
      const json = await r.json();
      if (!r.ok) throw new Error(json.error || "error");
      toast({
        title: "Programación copiada",
        description: `${json.copied} slots${json.cuePoints ? ` · ${json.cuePoints} cortes` : ""} → ${copyTargetDate}`,
      });
      setCopyOpen(false);
    } catch (e) {
      toast({
        title: "Error al copiar",
        description: e instanceof Error ? e.message : "internal error",
        variant: "destructive",
      });
    } finally {
      setCopying(false);
    }
  };

  return (
    <div className="flex h-full min-h-0 flex-col gap-3">
      {/* Toolbar */}
      <div className="flex flex-wrap items-center gap-2">
        <div className="flex items-center gap-1 rounded-md border border-zinc-800 bg-zinc-900/80 p-1">
          <Button
            variant="ghost"
            size="icon"
            className="size-7 text-zinc-400 hover:bg-zinc-800 hover:text-zinc-100"
            onClick={() => setDate(shiftDate(date, -1))}
            aria-label="Día anterior"
          >
            <ChevronLeft className="size-4" />
          </Button>
          <input
            type="date"
            value={date}
            onChange={(e) => e.target.value && setDate(e.target.value)}
            className="bg-transparent px-1 font-mono text-xs tabular-nums text-zinc-100 [color-scheme:dark]"
          />
          <Button
            variant="ghost"
            size="icon"
            className="size-7 text-zinc-400 hover:bg-zinc-800 hover:text-zinc-100"
            onClick={() => setDate(shiftDate(date, 1))}
            aria-label="Día siguiente"
          >
            <ChevronRight className="size-4" />
          </Button>
        </div>
        <Button
          variant="outline"
          size="sm"
          className="h-8 gap-1.5 border-zinc-700 bg-transparent text-xs text-zinc-300 hover:bg-zinc-800"
          onClick={() => setDate(today)}
        >
          <CalendarClock className="size-3.5" />
          Hoy
        </Button>

        <div className="ml-auto flex items-center gap-2">
          <div className="hidden items-center gap-1.5 rounded-md border border-zinc-800 bg-zinc-900/80 px-3 py-1.5 text-xs text-zinc-400 sm:flex">
            <Clock className="size-3.5 text-amber-400" />
            <span className="font-mono tabular-nums text-zinc-200">
              {formatHours(displayRows.length ? displayRows[displayRows.length - 1].endMs : 0)}
            </span>
            <span className="text-zinc-500">/ 24h</span>
          </div>
          <Button
            variant="outline"
            size="sm"
            className="h-8 gap-1.5 border-zinc-700 bg-transparent text-xs text-zinc-300 hover:bg-zinc-800"
            onClick={openFiller}
          >
            <Layers className="size-3.5" />
            Rellenar con Planta
          </Button>
          <Button
            variant="outline"
            size="sm"
            className="h-8 gap-1.5 border-zinc-700 bg-transparent text-xs text-zinc-300 hover:bg-zinc-800"
            onClick={openCopyDialog}
            disabled={displayRows.length === 0}
            title="Copiar toda la programación de este día a otra fecha"
          >
            <Copy className="size-3.5" />
            Copiar día
          </Button>
          {/* Unified "Añadir" button — opens a picker with Programa / Bumper / Avance. */}
          <Button
            size="sm"
            className="h-8 gap-1.5 bg-amber-500 text-zinc-950 hover:bg-amber-400"
            onClick={openAdd}
            title="Añadir un programa, bumper o avance al final de la parrilla"
          >
            <Plus className="size-3.5" />
            Añadir
          </Button>
        </div>
      </div>

      {/* Unsaved changes bar */}
      {dirty && (
        <div className="flex items-center gap-3 rounded-md border border-amber-500/40 bg-amber-500/10 px-3 py-2">
          <span className="size-2 animate-pulse rounded-full bg-amber-400" />
          <span className="text-xs font-medium text-amber-300">
            Tienes cambios sin guardar. Arrastra más slots o guarda ahora.
          </span>
          <div className="ml-auto flex items-center gap-2">
            <Button
              variant="ghost"
              size="sm"
              className="h-7 gap-1.5 text-xs text-zinc-400 hover:bg-zinc-800 hover:text-zinc-100"
              onClick={discardChanges}
              disabled={saving}
            >
              Descartar
            </Button>
            <Button
              size="sm"
              className="h-7 gap-1.5 bg-amber-500 text-zinc-950 hover:bg-amber-400"
              onClick={saveChanges}
              disabled={saving}
            >
              {saving ? (
                <>
                  <Spinner className="border-zinc-950 border-t-transparent" />
                  Guardando…
                </>
              ) : (
                <>
                  <Save className="size-3.5" />
                  Guardar cambios
                </>
              )}
            </Button>
          </div>
        </div>
      )}

      {/* Slot list */}
      <Card className="flex min-h-0 flex-1 flex-col border-zinc-800 bg-zinc-900/60 p-0">
        <div className="flex items-center justify-between border-b border-zinc-800 px-3 py-2">
          <div className="flex items-center gap-2">
            <div className="text-[11px] font-medium uppercase tracking-wider text-zinc-500">
              Parrilla del día · {displayRows.length} slots
            </div>
            {dirty && (
              <span className="rounded bg-amber-500/20 px-1.5 py-0.5 text-[10px] font-bold uppercase tracking-wider text-amber-300">
                Sin guardar
              </span>
            )}
          </div>
          <div className="text-[11px] text-zinc-500">
            <span className="font-mono tabular-nums text-amber-400">
              {formatHours(displayRows.length ? displayRows[displayRows.length - 1].endMs : 0)}
            </span>{" "}
            programadas
          </div>
        </div>

        {/* Color-coded legend for slot types */}
        <div className="flex flex-wrap items-center gap-3 border-b border-zinc-800/60 bg-zinc-950/30 px-3 py-1.5 text-[10px] text-zinc-500">
          <span className="flex items-center gap-1">
            <span className="h-3 w-0.5 rounded-full bg-amber-500" /> Programa
          </span>
          <span className="flex items-center gap-1">
            <span className="h-3 w-0.5 rounded-full bg-zinc-500" /> Planta
          </span>
          <span className="flex items-center gap-1">
            <span className="h-3 w-0.5 rounded-full bg-rose-500" /> Spot
          </span>
          <span className="flex items-center gap-1">
            <span className="h-3 w-0.5 rounded-full bg-sky-500" /> Bumper
          </span>
          <span className="flex items-center gap-1">
            <span className="h-3 w-0.5 rounded-full bg-violet-500" /> Avance
          </span>
        </div>

        <div className="min-h-0 flex-1 overflow-y-auto custom-scrollbar">
          {scheduleAsync.loading && (
            <div className="flex items-center justify-center gap-2 py-10 text-zinc-500">
              <Spinner /> Cargando parrilla…
            </div>
          )}
          {!scheduleAsync.loading && displayRows.length === 0 && (
            <div className="flex flex-col items-center justify-center gap-2 py-12 text-zinc-500">
              <CalendarClock className="size-6 text-zinc-700" />
              <div className="text-sm">No hay programación para este día.</div>
              <Button
                size="sm"
                variant="outline"
                className="mt-2 gap-1.5 border-zinc-700 bg-transparent text-zinc-300"
                onClick={openAdd}
              >
                <Plus className="size-3.5" /> Añadir el primer ítem
              </Button>
            </div>
          )}

          <DndContext
            sensors={sensors}
            collisionDetection={closestCenter}
            onDragEnd={handleDragEnd}
          >
            <SortableContext items={displayRows.map((r) => r.slot.id)} strategy={verticalListSortingStrategy}>
              <ul className="divide-y divide-zinc-800/70">
                {displayRows.map(({ slot, idx, startMs, endMs, cueAdDur }) => (
                  <SortableSlotItem
                    key={slot.id}
                    slot={slot}
                    idx={idx}
                    startMs={startMs}
                    endMs={endMs}
                    cueAdDur={cueAdDur}
                    isExpanded={expanded === slot.id}
                    isFirst={idx === 0}
                    isLast={idx === displayRows.length - 1}
                    isOnAir={onAirSlotId === slot.id}
                    onToggleExpand={() => setExpanded(expanded === slot.id ? null : slot.id)}
                    onMoveUp={() => moveSlot(idx, -1)}
                    onMoveDown={() => moveSlot(idx, 1)}
                    onOpenCue={() => openCueDialog(slot.id)}
                    onDelete={() => setDeleting(slot)}
                    onDeleteCue={(cueId) => deleteCue(slot.id, cueId)}
                  />
                ))}
              </ul>
            </SortableContext>
          </DndContext>
        </div>
      </Card>

      {/* Unified Add dialog (Programa / Bumper / Avance) */}
      <Dialog open={addOpen} onOpenChange={(o) => !o && setAddOpen(false)}>
        <DialogContent className="gap-0 border-zinc-800 bg-zinc-900 p-0 sm:max-w-md">
          <DialogHeader className="border-b border-zinc-800 px-5 py-4">
            <DialogTitle className="flex items-center gap-2 text-base text-zinc-100">
              <Plus className="size-4 text-amber-400" />
              Añadir a la parrilla
            </DialogTitle>
            <DialogDescription className="text-xs text-zinc-500">
              Elige el tipo de ítem. Se añade al final de la parrilla con snap-to-tail.
            </DialogDescription>
          </DialogHeader>

          {/* Type picker */}
          <div className="grid grid-cols-3 gap-2 border-b border-zinc-800 px-5 py-3">
            <button
              type="button"
              onClick={() => switchAddType("program")}
              className={cn(
                "flex flex-col items-center gap-1 rounded-md border px-2 py-2.5 text-center transition-all",
                addType === "program"
                  ? "border-amber-500/60 bg-amber-500/10 text-amber-300"
                  : "border-zinc-800 bg-zinc-950/40 text-zinc-400 hover:border-zinc-700 hover:text-zinc-200"
              )}
            >
              <Film className="size-4" />
              <span className="text-[11px] font-medium">Programa</span>
            </button>
            <button
              type="button"
              onClick={() => switchAddType("bumper")}
              className={cn(
                "flex flex-col items-center gap-1 rounded-md border px-2 py-2.5 text-center transition-all",
                addType === "bumper"
                  ? "border-sky-500/60 bg-sky-500/10 text-sky-300"
                  : "border-zinc-800 bg-zinc-950/40 text-zinc-400 hover:border-zinc-700 hover:text-zinc-200"
              )}
            >
              <Zap className="size-4" />
              <span className="text-[11px] font-medium">Bumper</span>
            </button>
            <button
              type="button"
              onClick={() => switchAddType("avance")}
              className={cn(
                "flex flex-col items-center gap-1 rounded-md border px-2 py-2.5 text-center transition-all",
                addType === "avance"
                  ? "border-violet-500/60 bg-violet-500/10 text-violet-300"
                  : "border-zinc-800 bg-zinc-950/40 text-zinc-400 hover:border-zinc-700 hover:text-zinc-200"
              )}
            >
              <Clapperboard className="size-4" />
              <span className="text-[11px] font-medium">Avance</span>
            </button>
          </div>

          {/* Body — changes based on selected type */}
          <div className="grid gap-3 px-5 py-4">
            {addType === "program" && (
              <div className="grid gap-1.5">
                <Label className="text-xs text-zinc-400">Programa</Label>
                <Select value={addAssetId} onValueChange={setAddAssetId}>
                  <SelectTrigger className="h-9 border-zinc-700 bg-zinc-950 text-sm text-zinc-100">
                    <SelectValue placeholder="Selecciona un programa…" />
                  </SelectTrigger>
                  <SelectContent className="max-h-72 border-zinc-700 bg-zinc-900 text-zinc-100">
                    {(programsAsync.data ?? []).map((p) => (
                      <SelectItem key={p.id} value={p.id}>
                        🎬 {p.title} ·{" "}
                        <span className="text-zinc-500">
                          {msToHMMSS(p.durationMs)}
                        </span>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                {!programsAsync.data?.length && (
                  <div className="rounded-md border border-amber-500/30 bg-amber-500/5 px-3 py-2 text-xs text-amber-300">
                    No hay programas en la biblioteca. Sube videos con categoría PROGRAM desde Medios (MAM).
                  </div>
                )}
              </div>
            )}

            {addType === "bumper" && (
              <div className="grid gap-1.5">
                <Label className="text-xs text-zinc-400">Bumper</Label>
                <Select value={addAssetId} onValueChange={setAddAssetId}>
                  <SelectTrigger className="h-9 border-zinc-700 bg-zinc-950 text-sm text-zinc-100">
                    <SelectValue placeholder="Selecciona un bumper…" />
                  </SelectTrigger>
                  <SelectContent className="max-h-72 border-zinc-700 bg-zinc-900 text-zinc-100">
                    {(bumpersAsync.data ?? []).map((p) => (
                      <SelectItem key={p.id} value={p.id}>
                        🎬 {p.title} ·{" "}
                        <span className="text-zinc-500">
                          {msToHMMSS(p.durationMs)}
                        </span>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                {!bumpersAsync.data?.length && (
                  <div className="rounded-md border border-amber-500/30 bg-amber-500/5 px-3 py-2 text-xs text-amber-300">
                    No hay bumpers en la biblioteca. Sube videos cortos con categoría BUMPER desde Medios (MAM).
                  </div>
                )}
                <p className="text-[10px] text-zinc-500">
                  Un bumper es un clip corto (2-15s) que separa contenido de publicidad.
                </p>
              </div>
            )}

            {addType === "avance" && (
              <div className="grid gap-1.5">
                <Label className="text-xs text-zinc-400">Avance (contenedor multiprograma)</Label>
                <Select value={addAvanceId} onValueChange={setAddAvanceId}>
                  <SelectTrigger className="h-9 border-zinc-700 bg-zinc-950 text-sm text-zinc-100">
                    <SelectValue placeholder="Selecciona un Avance…" />
                  </SelectTrigger>
                  <SelectContent className="max-h-72 border-zinc-700 bg-zinc-900 text-zinc-100">
                    {(avancesAsync.data ?? []).map((a) => (
                      <SelectItem key={a.id} value={a.id}>
                        <span className="flex items-center gap-1.5">
                          <Clapperboard className="size-3 text-violet-400" />
                          <span className="truncate">{a.title}</span>
                          <span className="text-zinc-500">
                            · {a.clips.length} clip{a.clips.length === 1 ? "" : "s"} · {msToHMMSS(a.totalDurationMs)}
                            {a.hideFromEpg ? " · oculto" : ""}
                          </span>
                        </span>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                {!avancesAsync.data?.length && (
                  <div className="rounded-md border border-amber-500/30 bg-amber-500/5 px-3 py-2 text-xs text-amber-300">
                    No hay Avances creados. Crea uno primero desde la sección “Avances” del menú lateral.
                  </div>
                )}
                {/* Show details of the selected Avance */}
                {addAvanceId && (() => {
                  const a = (avancesAsync.data ?? []).find((x) => x.id === addAvanceId);
                  if (!a) return null;
                  return (
                    <div className="rounded-md border border-zinc-800 bg-zinc-950/60 p-2.5">
                      <div className="flex flex-wrap items-center gap-1.5">
                        <span className={cn(
                          "inline-flex items-center gap-1 rounded px-1.5 py-0.5 text-[10px] font-medium",
                          a.hideFromEpg
                            ? "bg-violet-500/15 text-violet-300"
                            : "bg-emerald-500/15 text-emerald-300"
                        )}>
                          {a.hideFromEpg ? "Oculto en EPG" : "Visible"}
                        </span>
                        <span className="text-[10px] text-zinc-500">
                          {a.clips.length} clips · duración total {msToHMMSS(a.totalDurationMs)}
                        </span>
                      </div>
                      <ul className="mt-2 space-y-0.5 text-[11px] text-zinc-400">
                        {a.clips.map((c, i) => {
                          const dur = Math.max(c.asset.durationMs, 1);
                          const inMs = Math.max(0, Math.min(c.inMs, dur - 1));
                          const outMs = Math.max(inMs + 1, Math.min(c.outMs > 0 ? c.outMs : dur, dur));
                          const isFull = inMs === 0 && outMs >= dur;
                          return (
                            <li key={c.id} className="flex items-center gap-1.5 truncate">
                              <span className="font-mono text-zinc-600">{i + 1}.</span>
                              <span className="truncate text-zinc-300">{c.asset.title}</span>
                              <span className="ml-auto shrink-0 text-zinc-500">
                                {isFull
                                  ? msToHMMSS(outMs - inMs)
                                  : `${msToHMMSS(inMs)}→${msToHMMSS(outMs)}`}
                              </span>
                            </li>
                          );
                        })}
                      </ul>
                    </div>
                  );
                })()}
              </div>
            )}
          </div>

          <DialogFooter className="border-t border-zinc-800 px-5 py-3">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setAddOpen(false)}
              className="text-zinc-400 hover:bg-zinc-800 hover:text-zinc-100"
            >
              Cancelar
            </Button>
            <Button
              size="sm"
              onClick={submitAdd}
              disabled={
                adding ||
                (addType === "program" && !programsAsync.data?.length) ||
                (addType === "bumper" && !bumpersAsync.data?.length) ||
                (addType === "avance" && !avancesAsync.data?.length)
              }
              className={cn(
                "gap-1.5",
                addType === "bumper"
                  ? "bg-sky-600 text-white hover:bg-sky-500"
                  : addType === "avance"
                  ? "bg-violet-600 text-white hover:bg-violet-500"
                  : "bg-amber-500 text-zinc-950 hover:bg-amber-400"
              )}
            >
              {adding && <Spinner className="border-zinc-950 border-t-transparent" />}
              Añadir {addType === "program" ? "programa" : addType === "bumper" ? "bumper" : "avance"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Add filler dialog */}
      <Dialog open={fillerOpen} onOpenChange={(o) => !o && setFillerOpen(false)}>
        <DialogContent className="gap-0 border-zinc-800 bg-zinc-900 p-0 sm:max-w-md">
          <DialogHeader className="border-b border-zinc-800 px-5 py-4">
            <DialogTitle className="text-base text-zinc-100">
              Rellenar con Planta
            </DialogTitle>
            <DialogDescription className="text-xs text-zinc-500">
              Añade un bloque de planta (loop) al final de la parrilla.
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-3 px-5 py-4">
            <div className="grid gap-1.5">
              <Label className="text-xs text-zinc-400">Activo de planta</Label>
              <Select value={fillerAssetId} onValueChange={setFillerAssetId}>
                <SelectTrigger className="h-9 border-zinc-700 bg-zinc-950 text-sm text-zinc-100">
                  <SelectValue placeholder="Selecciona…" />
                </SelectTrigger>
                <SelectContent className="max-h-72 border-zinc-700 bg-zinc-900 text-zinc-100">
                  {(fillersAsync.data ?? []).map((p) => (
                    <SelectItem key={p.id} value={p.id}>
                      🎬 {p.title} ·{" "}
                      <span className="text-zinc-500">
                        {msToHMMSS(p.durationMs)}
                      </span>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter className="border-t border-zinc-800 px-5 py-3">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setFillerOpen(false)}
              className="text-zinc-400 hover:bg-zinc-800 hover:text-zinc-100"
            >
              Cancelar
            </Button>
            <Button
              size="sm"
              onClick={submitAddFiller}
              disabled={addingFiller}
              className="gap-1.5 bg-amber-500 text-zinc-950 hover:bg-amber-400"
            >
              {addingFiller && (
                <Spinner className="border-zinc-950 border-t-transparent" />
              )}
              Añadir bloque
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>


      {/* Add cue point dialog */}
      <Dialog
        open={!!cueOpen}
        onOpenChange={(o) => !o && setCueOpen(null)}
      >
        <DialogContent className="gap-0 border-zinc-800 bg-zinc-900 p-0 sm:max-w-2xl">
          <DialogHeader className="border-b border-zinc-800 px-5 py-4">
            <DialogTitle className="text-base text-zinc-100">
              Añadir corte comercial
            </DialogTitle>
            <DialogDescription className="text-xs text-zinc-500">
              Usa el reproductor para marcar el momento exacto del corte (no
              cortes diálogos). El offset es relativo al inicio del programa.
            </DialogDescription>
          </DialogHeader>

          <div className="grid gap-3 px-5 py-4">
            {/* Video preview player */}
            {cueSlot && (
              <CuePointPreview
                hlsUrl={cueSlot.asset.hlsUrl}
                durationMs={cueSlot.asset.durationMs}
                existingCueOffsetsMs={cueExistingOffsets}
                selectedOffsetMs={cueOffsetMs}
                onOffsetChange={setCueOffsetMs}
              />
            )}

            {/* Selected offset display + manual override */}
            <div className="grid grid-cols-2 gap-3">
              <div className="grid gap-1.5">
                <Label className="text-xs text-zinc-400">
                  Offset seleccionado (ms)
                </Label>
                <Input
                  type="number"
                  step="100"
                  min="0"
                  value={cueOffsetMs}
                  onChange={(e) =>
                    setCueOffsetMs(Math.max(0, parseInt(e.target.value) || 0))
                  }
                  className="h-9 border-zinc-700 bg-zinc-950 font-mono text-sm text-zinc-100"
                />
                <span className="text-[11px] text-amber-300">
                  = {msToWallclock(cueOffsetMs)} desde el inicio del programa
                </span>
              </div>
              <div className="grid gap-1.5">
                <Label className="text-xs text-zinc-400">
                  Bloque publicitario
                </Label>
                <Select value={cueBreakId} onValueChange={setCueBreakId}>
                  <SelectTrigger className="h-9 border-zinc-700 bg-zinc-950 text-sm text-zinc-100">
                    <SelectValue placeholder="Selecciona un bloque…" />
                  </SelectTrigger>
                  <SelectContent className="max-h-72 border-zinc-700 bg-zinc-900 text-zinc-100">
                    {(breaksAsync.data ?? []).map((b) => (
                      <SelectItem key={b.id} value={b.id}>
                        {b.name} ·{" "}
                        <span className="text-zinc-500">
                          {b.entries.length} spots
                        </span>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <span className="text-[11px] text-zinc-500">
                  Duración del bloque:{" "}
                  <span className="font-mono text-zinc-300">
                    {msToHMMSS(
                      breaksAsync.data?.find((b) => b.id === cueBreakId)?.entries.reduce(
                        (s, e) => s + e.asset.durationMs,
                        0
                      ) ?? 0
                    )}
                  </span>
                </span>
              </div>
            </div>
          </div>

          <DialogFooter className="border-t border-zinc-800 px-5 py-3">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setCueOpen(null)}
              className="text-zinc-400 hover:bg-zinc-800 hover:text-zinc-100"
            >
              Cancelar
            </Button>
            <Button
              size="sm"
              onClick={submitCue}
              disabled={addingCue}
              className="gap-1.5 bg-amber-500 text-zinc-950 hover:bg-amber-400"
            >
              {addingCue && (
                <Spinner className="border-zinc-950 border-t-transparent" />
              )}
              Insertar corte
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Copy day dialog */}
      <Dialog open={copyOpen} onOpenChange={(o) => !o && setCopyOpen(false)}>
        <DialogContent className="gap-0 border-zinc-800 bg-zinc-900 p-0 sm:max-w-md">
          <DialogHeader className="border-b border-zinc-800 px-5 py-4">
            <DialogTitle className="text-base text-zinc-100">
              Copiar programación del día
            </DialogTitle>
            <DialogDescription className="text-xs text-zinc-500">
              Duplica todos los slots de{" "}
              <span className="font-mono text-amber-300">{date}</span> en otra
              fecha. Los slots se añaden al final de la parrilla destino (modo
              append). Las horas de inicio se recalculan por snap-to-tail.
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 px-5 py-4">
            <div className="grid gap-1.5">
              <Label className="text-xs text-zinc-400">
                Fecha destino (YYYY-MM-DD)
              </Label>
              <Input
                type="date"
                value={copyTargetDate}
                onChange={(e) => e.target.value && setCopyTargetDate(e.target.value)}
                className="h-9 border-zinc-700 bg-zinc-950 font-mono text-sm text-zinc-100 [color-scheme:dark]"
              />
              <div className="flex gap-1.5 pt-1">
                <Button
                  variant="ghost"
                  size="sm"
                  className="h-7 px-2 text-[11px] text-zinc-400 hover:bg-zinc-800 hover:text-zinc-200"
                  onClick={() => setCopyTargetDate(shiftDate(date, 1))}
                >
                  +1 día
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  className="h-7 px-2 text-[11px] text-zinc-400 hover:bg-zinc-800 hover:text-zinc-200"
                  onClick={() => setCopyTargetDate(shiftDate(date, 7))}
                >
                  +1 semana
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  className="h-7 px-2 text-[11px] text-zinc-400 hover:bg-zinc-800 hover:text-zinc-200"
                  onClick={() => setCopyTargetDate(shiftDate(date, -1))}
                >
                  Día anterior
                </Button>
              </div>
            </div>

            <label className="flex cursor-pointer items-center justify-between rounded-md border border-zinc-800 bg-zinc-950/60 px-3 py-2.5">
              <div>
                <div className="text-xs font-medium text-zinc-200">
                  Copiar también cortes comerciales
                </div>
                <div className="text-[11px] text-zinc-500">
                  Reproduce los cue points y sus bloques publicitarios asociados.
                </div>
              </div>
              <Switch
                checked={copyIncludeCues}
                onCheckedChange={setCopyIncludeCues}
              />
            </label>

            <label className="flex cursor-pointer items-center justify-between rounded-md border border-zinc-800 bg-zinc-950/60 px-3 py-2.5">
              <div>
                <div className="text-xs font-medium text-zinc-200">
                  Reemplazar programación destino
                </div>
                <div className="text-[11px] text-zinc-500">
                  Borra los slots existentes en la fecha destino antes de copiar.
                </div>
              </div>
              <Switch
                checked={copyReplaceTarget}
                onCheckedChange={setCopyReplaceTarget}
              />
            </label>

            <div className="rounded-md border border-amber-500/20 bg-amber-500/5 px-3 py-2 text-[11px] text-amber-300">
              <span className="font-semibold">Resumen:</span>{" "}
              {displayRows.length} slots
              {copyIncludeCues && (
                <span>
                  {" "}
                  · {displayRows.reduce((acc, r) => acc + r.slot.cuePoints.length, 0)}{" "}
                  cortes
                </span>
              )}{" "}
              → fecha destino{" "}
              <span className="font-mono">{copyTargetDate}</span>
              {copyReplaceTarget && (
                <span className="ml-1 text-rose-300">(reemplaza existentes)</span>
              )}
            </div>
          </div>
          <DialogFooter className="border-t border-zinc-800 px-5 py-3">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setCopyOpen(false)}
              className="text-zinc-400 hover:bg-zinc-800 hover:text-zinc-100"
            >
              Cancelar
            </Button>
            <Button
              size="sm"
              onClick={submitCopyDay}
              disabled={copying}
              className="gap-1.5 bg-amber-500 text-zinc-950 hover:bg-amber-400"
            >
              {copying && <Spinner className="border-zinc-950 border-t-transparent" />}
              <Copy className="size-3.5" />
              Copiar programación
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete slot confirmation */}
      <AlertDialog
        open={!!deleting}
        onOpenChange={(o) => !o && setDeleting(null)}
      >
        <AlertDialogContent className="border-zinc-800 bg-zinc-900 text-zinc-100">
          <AlertDialogHeader>
            <AlertDialogTitle className="text-base">
              Eliminar slot
            </AlertDialogTitle>
            <AlertDialogDescription className="text-zinc-400">
              ¿Eliminar{" "}
              <span className="font-semibold text-zinc-200">
                {deleting?.asset.title}
              </span>{" "}
              de la parrilla? Los slots posteriores se reordenan por
              encadenamiento.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="border-zinc-700 bg-transparent text-zinc-300 hover:bg-zinc-800 hover:text-zinc-100">
              Cancelar
            </AlertDialogCancel>
            <AlertDialogAction
              onClick={confirmDelete}
              className="bg-rose-600 text-white hover:bg-rose-500"
            >
              Eliminar
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

// ---- Sortable Slot Item (drag-and-drop wrapper) ----

interface SortableSlotItemProps {
  slot: ScheduleSlot;
  idx: number;
  startMs: number;
  endMs: number;
  cueAdDur: number;
  isExpanded: boolean;
  isFirst: boolean;
  isLast: boolean;
  isOnAir?: boolean;
  onToggleExpand: () => void;
  onMoveUp: () => void;
  onMoveDown: () => void;
  onOpenCue: () => void;
  onDelete: () => void;
  onDeleteCue: (cueId: string) => void;
}

function SortableSlotItem({
  slot,
  idx,
  startMs,
  endMs,
  cueAdDur,
  isExpanded,
  isFirst,
  isLast,
  isOnAir,
  onToggleExpand,
  onMoveUp,
  onMoveDown,
  onOpenCue,
  onDelete,
  onDeleteCue,
}: SortableSlotItemProps) {
  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
    isDragging,
  } = useSortable({ id: slot.id });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
    opacity: isDragging ? 0.5 : 1,
  };

  const isFillerLoop = slot.fillerLoop;
  const isAvance = slot.slotType === "avance" && !!slot.avance;

  // Color-code slots by type for at-a-glance distinction in the grid.
  // PROGRAM = amber, FILLER/filler-loop = zinc, SPOT = rose, BUMPER = sky, AVANCE = violet.
  const slotAccent = isAvance
    ? "border-l-violet-500"
    : isFillerLoop
      ? "border-l-zinc-500"
      : slot.asset.category === "SPOT"
        ? "border-l-rose-500"
        : slot.asset.category === "FILLER"
          ? "border-l-zinc-500"
          : slot.asset.category === "BUMPER"
            ? "border-l-sky-500"
            : "border-l-amber-500";
  const SlotIcon = isAvance
    ? Clapperboard
    : isFillerLoop
      ? Layers
      : slot.asset.category === "SPOT"
        ? Megaphone
        : slot.asset.category === "FILLER"
          ? Layers
          : slot.asset.category === "BUMPER"
            ? Zap
            : Film;
  const slotIconColor = isAvance
    ? "text-violet-400"
    : isFillerLoop
      ? "text-zinc-400"
      : slot.asset.category === "SPOT"
        ? "text-rose-400"
        : slot.asset.category === "FILLER"
          ? "text-zinc-400"
          : slot.asset.category === "BUMPER"
            ? "text-sky-400"
            : "text-amber-400";

  // Display title + duration for the slot row.
  // For Avance slots, show the Avance title + totalDurationMs (sum of clip cuts).
  // For other slots, fall back to the asset title + asset duration.
  const displayTitle = isAvance && slot.avance
    ? slot.avance.title
    : slot.asset.title;
  const displayDurationMs = isAvance && slot.avance
    ? slot.avance.totalDurationMs
    : slot.asset.durationMs;
  const displayThumbnail = isAvance && slot.avance
    ? slot.asset.thumbnailUrl // first clip's thumbnail as fallback
    : slot.asset.thumbnailUrl;

  return (
    <li ref={setNodeRef} style={style} className="text-sm">
      <div
        className={cn(
          "relative flex items-center gap-2 border-l-2 px-3 py-2.5 transition-colors",
          slotAccent,
          isOnAir
            ? "bg-emerald-500/10 ring-1 ring-inset ring-emerald-500/30"
            : isExpanded
              ? "bg-zinc-800/40"
              : "hover:bg-zinc-800/30",
          isDragging && "bg-zinc-800/60 shadow-lg ring-1 ring-amber-500/40"
        )}
      >
        {/* On-air badge — pulsing "Al aire" label on the right edge */}
        {isOnAir && (
          <span className="absolute right-2 top-1/2 z-10 flex -translate-y-1/2 items-center gap-1 rounded-full bg-emerald-500/20 px-2 py-0.5 text-[9px] font-bold uppercase tracking-wider text-emerald-300 ring-1 ring-emerald-500/40">
            <span className="relative flex size-1.5">
              <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-400 opacity-75" />
              <span className="relative inline-flex size-1.5 rounded-full bg-emerald-400" />
            </span>
            Al aire
          </span>
        )}
        {/* Drag handle */}
        <button
          {...attributes}
          {...listeners}
          className="flex size-6 shrink-0 cursor-grab items-center justify-center rounded text-zinc-500 hover:bg-zinc-800 hover:text-zinc-200 active:cursor-grabbing"
          aria-label="Arrastrar para reordenar"
          title="Arrastra para cambiar el orden"
        >
          <GripVertical className="size-3.5" />
        </button>

        <button
          onClick={onToggleExpand}
          className="flex size-6 shrink-0 items-center justify-center rounded font-mono text-[11px] tabular-nums text-zinc-500 hover:bg-zinc-800 hover:text-zinc-200"
          aria-label="Expandir"
        >
          {isExpanded ? "−" : "+"}
        </button>
        <span className="w-6 shrink-0 text-center font-mono text-[11px] tabular-nums text-zinc-600">
          {idx + 1}
        </span>
        <div className="flex shrink-0 items-center gap-2 font-mono text-xs tabular-nums">
          <span className="text-amber-300">{msToWallclock(startMs)}</span>
          <span className="text-zinc-600">→</span>
          <span className="text-zinc-300">{msToWallclock(endMs)}</span>
        </div>
        <Thumbnail
          url={displayThumbnail}
          className="size-8 text-sm"
        />
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-2">
            <SlotIcon className={cn("size-3.5 shrink-0", slotIconColor)} aria-hidden />
            <span className="truncate font-medium text-zinc-100">
              {displayTitle}
            </span>
            {isAvance ? (
              <span className="flex shrink-0 items-center gap-1 rounded border border-violet-500/40 bg-violet-500/15 px-1.5 py-0.5 text-[10px] font-medium text-violet-300">
                <Clapperboard className="size-2.5" />
                Avance
                {slot.avance?.hideFromEpg && (
                  <span className="text-[9px] text-violet-400/70">· oculto</span>
                )}
              </span>
            ) : isFillerLoop ? (
              <span className="shrink-0 rounded border border-zinc-600/60 bg-zinc-700/40 px-1.5 py-0.5 text-[10px] font-medium text-zinc-300">
                Planta (loop)
              </span>
            ) : (
              <CategoryBadge category={slot.asset.category} />
            )}
          </div>
          <div className="mt-0.5 font-mono text-[10px] tabular-nums text-zinc-500">
            {isAvance && slot.avance ? (
              <>
                Dur: {msToHMMSS(slot.avance.totalDurationMs)}
                <span className="ml-2 text-violet-400">
                  · {slot.avance.clips.length} clip{slot.avance.clips.length === 1 ? "" : "s"}
                </span>
              </>
            ) : (
              <>
                Dur: {msToHMMSS(slot.asset.durationMs)}
                {cueAdDur > 0 && (
                  <span className="ml-2 text-rose-400">
                    + {msToHMMSS(cueAdDur)} pub
                  </span>
                )}
                <span className="ml-2">
                  Cortes: {slot.cuePoints.length}
                </span>
              </>
            )}
          </div>
        </div>

        <div className="flex shrink-0 items-center gap-0.5">
          <Button
            variant="ghost"
            size="icon"
            className="size-7 text-zinc-500 hover:bg-zinc-800 hover:text-zinc-200 disabled:opacity-30"
            onClick={onMoveUp}
            disabled={isFirst}
            aria-label="Subir"
          >
            <ChevronUp className="size-3.5" />
          </Button>
          <Button
            variant="ghost"
            size="icon"
            className="size-7 text-zinc-500 hover:bg-zinc-800 hover:text-zinc-200 disabled:opacity-30"
            onClick={onMoveDown}
            disabled={isLast}
            aria-label="Bajar"
          >
            <ChevronDown className="size-3.5" />
          </Button>
          {!isFillerLoop && (
            <Button
              variant="ghost"
              size="sm"
              className="h-7 gap-1 px-2 text-xs text-amber-300 hover:bg-amber-500/10 hover:text-amber-200"
              onClick={onOpenCue}
            >
              <Megaphone className="size-3.5" />
              Corte
            </Button>
          )}
          <Button
            variant="ghost"
            size="icon"
            className="size-7 text-zinc-500 hover:bg-zinc-800 hover:text-rose-400"
            onClick={onDelete}
            aria-label="Eliminar"
          >
            <Trash2 className="size-3.5" />
          </Button>
        </div>
      </div>

      {/* Cue points panel */}
      {isExpanded && (
        <div className="border-t border-zinc-800/70 bg-zinc-950/40 px-3 py-2.5">
          <div className="mb-1.5 flex items-center justify-between">
            <span className="text-[10px] font-semibold uppercase tracking-wider text-zinc-500">
              Cortes comerciales ({slot.cuePoints.length})
            </span>
            {!isFillerLoop && (
              <Button
                variant="ghost"
                size="sm"
                className="h-6 gap-1 px-2 text-[11px] text-amber-300 hover:bg-amber-500/10"
                onClick={onOpenCue}
              >
                <Plus className="size-3" /> Añadir corte
              </Button>
            )}
          </div>
          {slot.cuePoints.length === 0 ? (
            <div className="text-xs text-zinc-600">
              Sin cortes comerciales. El programa se reproduce
              completo sin inserciones.
            </div>
          ) : (
            <div className="flex flex-wrap gap-1.5">
              {[...slot.cuePoints]
                .sort((a, b) => a.offsetMs - b.offsetMs)
                .map((cp) => (
                  <div
                    key={cp.id}
                    className="group flex items-center gap-1.5 rounded-md border border-rose-500/30 bg-rose-500/10 px-2 py-1 text-[11px]"
                  >
                    <span className="font-mono tabular-nums text-rose-300">
                      @{msToWallclock(cp.offsetMs)}
                    </span>
                    <span className="text-zinc-300">
                      {cp.adBreak.name}
                    </span>
                    <span className="text-zinc-500">
                      ({cp.adBreak.entries.length})
                    </span>
                    <button
                      onClick={() => onDeleteCue(cp.id)}
                      className="ml-0.5 text-zinc-500 opacity-0 transition-opacity hover:text-rose-300 group-hover:opacity-100"
                      aria-label="Eliminar corte"
                    >
                      <X className="size-3" />
                    </button>
                  </div>
                ))}
            </div>
          )}
        </div>
      )}
    </li>
  );
}
