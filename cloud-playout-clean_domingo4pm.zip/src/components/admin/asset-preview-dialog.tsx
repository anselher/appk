"use client";

import { useEffect, useRef, useState, useCallback } from "react";
import Hls from "hls.js";
import {
  Play,
  Pause,
  Volume2,
  VolumeX,
  Maximize,
  Minimize,
  SkipBack,
  SkipForward,
  Rewind,
  FastForward,
  Gauge,
  ChevronDown,
  AlertTriangle,
  RefreshCw,
  Cloud,
  HardDrive,
  X,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
} from "@/components/ui/select";
import { CategoryBadge, Spinner } from "./shared";
import type { Asset } from "@/lib/types";

interface AssetPreviewDialogProps {
  asset: Asset | null;
  open: boolean;
  onClose: () => void;
}

function fmtTime(ms: number): string {
  const total = Math.floor(ms / 1000);
  const h = Math.floor(total / 3600);
  const m = Math.floor((total % 3600) / 60);
  const s = total % 60;
  if (h > 0) return `${h}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
  return `${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
}

function isRemoteHls(url: string): boolean {
  return url.startsWith("http://") || url.startsWith("https://");
}

const LOAD_TIMEOUT_MS = 8000;

export function AssetPreviewDialog({ asset, open, onClose }: AssetPreviewDialogProps) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const hlsRef = useRef<Hls | null>(null);
  const loadTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const timelineRef = useRef<HTMLDivElement>(null);
  const dragRef = useRef<boolean>(false);
  const [retryNonce, setRetryNonce] = useState(0);

  const [duration, setDuration] = useState(asset ? asset.durationMs : 0);
  const [current, setCurrent] = useState(0);
  const [playing, setPlaying] = useState(false);
  const [loadState, setLoadState] = useState<"loading" | "ready" | "timeout" | "error">("loading");
  const [loadErrorMsg, setLoadErrorMsg] = useState<string | null>(null);

  // Player controls state
  const [volume, setVolume] = useState(80);
  const [muted, setMuted] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [skipStepSec, setSkipStepSec] = useState(10);
  const [playbackRate, setPlaybackRate] = useState(1);
  const [rateMenuOpen, setRateMenuOpen] = useState(false);
  const [showControls, setShowControls] = useState(true);
  const hideControlsTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const isRemote = asset ? isRemoteHls(asset.hlsUrl) : false;

  // Reset state when asset changes.
  useEffect(() => {
    if (!open || !asset) return;
    setDuration(asset.durationMs);
    setCurrent(0);
    setPlaying(false);
    setLoadState("loading");
    setLoadErrorMsg(null);
    setVolume(80);
    setMuted(false);
    setPlaybackRate(1);
  }, [asset, open]);

  // Load HLS source when opening or retrying.
  useEffect(() => {
    if (!open || !asset) return;
    let cancelled = false;
    let rafId: number | null = null;

    const startLoading = () => {
      if (cancelled) return;
      const video = videoRef.current;
      if (!video) {
        rafId = requestAnimationFrame(startLoading);
        return;
      }

      setLoadState("loading");
      setLoadErrorMsg(null);
      if (hlsRef.current) {
        hlsRef.current.destroy();
        hlsRef.current = null;
      }
      if (loadTimerRef.current) {
        clearTimeout(loadTimerRef.current);
        loadTimerRef.current = null;
      }

      const url = asset.hlsUrl;
      loadTimerRef.current = setTimeout(() => {
        setLoadState((prev) => (prev === "loading" ? "timeout" : prev));
      }, LOAD_TIMEOUT_MS);

      const onReady = () => {
        if (loadTimerRef.current) {
          clearTimeout(loadTimerRef.current);
          loadTimerRef.current = null;
        }
        setLoadState("ready");
        if (Number.isFinite(video.duration) && video.duration > 0) {
          setDuration(Math.floor(video.duration * 1000));
        }
      };

      if (Hls.isSupported()) {
        const hls = new Hls({
          enableWorker: true,
          lowLatencyMode: false,
          startLevel: 0,
          maxBufferLength: 10,
          manifestLoadingTimeOut: 10000,
          manifestLoadingMaxRetry: 2,
        });
        hlsRef.current = hls;
        hls.loadSource(url);
        hls.attachMedia(video);
        hls.on(Hls.Events.MANIFEST_PARSED, onReady);
        hls.on(Hls.Events.ERROR, (_e, data) => {
          if (data.fatal) {
            if (data.type === Hls.ErrorTypes.NETWORK_ERROR) {
              if (loadTimerRef.current) {
                clearTimeout(loadTimerRef.current);
                loadTimerRef.current = null;
              }
              setLoadState("error");
              setLoadErrorMsg(
                `Error de red: ${data.details || "network error"}. ` +
                (isRemote
                  ? "El stream remoto puede estar saturado."
                  : "Verifica que el archivo exista en el servidor.")
              );
            } else if (data.type === Hls.ErrorTypes.MEDIA_ERROR) {
              hls.recoverMediaError();
            } else {
              setLoadState("error");
              setLoadErrorMsg(`Error: ${data.details || data.type}`);
            }
          }
        });
      } else if (video.canPlayType("application/vnd.apple.mpegurl")) {
        video.src = url;
        video.addEventListener("loadedmetadata", onReady, { once: true });
        video.addEventListener("error", () => {
          if (loadTimerRef.current) {
            clearTimeout(loadTimerRef.current);
            loadTimerRef.current = null;
          }
          setLoadState("error");
          setLoadErrorMsg("El navegador no pudo cargar el video.");
        }, { once: true });
      }
    };

    rafId = requestAnimationFrame(startLoading);

    return () => {
      cancelled = true;
      if (rafId !== null) cancelAnimationFrame(rafId);
      if (loadTimerRef.current) {
        clearTimeout(loadTimerRef.current);
        loadTimerRef.current = null;
      }
      if (hlsRef.current) {
        hlsRef.current.destroy();
        hlsRef.current = null;
      }
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [asset?.id, open, retryNonce]);

  // Track playback position + apply volume + playbackRate.
  // IMPORTANT: this effect depends on `loadState` because the <video> element
  // is mounted inside a Radix Dialog (portal + animation), so videoRef.current
  // is null on the first render. When loadState changes to "ready", the video
  // is finally available and we can attach the event listeners.
  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;
    const onTime = () => setCurrent(Math.floor(video.currentTime * 1000));
    const onPlay = () => setPlaying(true);
    const onPause = () => setPlaying(false);
    const onLoaded = () => {
      if (Number.isFinite(video.duration) && video.duration > 0) {
        setDuration(Math.floor(video.duration * 1000));
      }
    };
    video.addEventListener("timeupdate", onTime);
    video.addEventListener("play", onPlay);
    video.addEventListener("pause", onPause);
    video.addEventListener("loadedmetadata", onLoaded);
    // Also fire onTime once immediately so the seekbar shows the current position.
    onTime();
    return () => {
      video.removeEventListener("timeupdate", onTime);
      video.removeEventListener("play", onPlay);
      video.removeEventListener("pause", onPause);
      video.removeEventListener("loadedmetadata", onLoaded);
    };
  }, [loadState]);

  // Apply volume + muted to the video.
  // Also re-apply when loadState changes (the <video> element may not be ready
  // on the first render — Radix Dialog animates in, so the ref can be null).
  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;
    video.volume = muted ? 0 : volume / 100;
    video.muted = muted;
  }, [volume, muted, loadState]);

  useEffect(() => {
    const video = videoRef.current;
    if (video) video.playbackRate = playbackRate;
  }, [playbackRate, loadState]);

  // Fullscreen handling.
  useEffect(() => {
    const onFs = () => setIsFullscreen(!!document.fullscreenElement);
    document.addEventListener("fullscreenchange", onFs);
    return () => document.removeEventListener("fullscreenchange", onFs);
  }, []);

  // Close rate menu on outside click.
  useEffect(() => {
    if (!rateMenuOpen) return;
    const handler = (e: MouseEvent) => {
      const target = e.target as HTMLElement;
      if (!target.closest("[data-rate-menu]")) setRateMenuOpen(false);
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, [rateMenuOpen]);

  // Auto-hide controls after 3s of inactivity when playing.
  const triggerControls = useCallback(() => {
    setShowControls(true);
    if (hideControlsTimerRef.current) clearTimeout(hideControlsTimerRef.current);
    hideControlsTimerRef.current = setTimeout(() => {
      if (videoRef.current && !videoRef.current.paused) setShowControls(false);
    }, 3000);
  }, []);

  const togglePlay = useCallback(() => {
    const video = videoRef.current;
    if (!video) return;
    if (video.paused) {
      void video.play().catch(() => {});
    } else {
      video.pause();
    }
  }, []);

  const seekTo = useCallback((ms: number) => {
    const video = videoRef.current;
    if (!video) return;
    try {
      video.currentTime = ms / 1000;
      setCurrent(ms);
    } catch { /* noop */ }
  }, []);

  const skipBackward = useCallback(() => {
    const video = videoRef.current;
    if (!video) return;
    seekTo(Math.max(0, Math.floor(video.currentTime * 1000) - skipStepSec * 1000));
  }, [skipStepSec, seekTo]);

  const skipForward = useCallback(() => {
    const video = videoRef.current;
    if (!video) return;
    seekTo(Math.min(duration, Math.floor(video.currentTime * 1000) + skipStepSec * 1000));
  }, [skipStepSec, duration, seekTo]);

  const toggleFullscreen = useCallback(() => {
    const el = containerRef.current;
    if (!el) return;
    if (document.fullscreenElement) {
      void document.exitFullscreen();
    } else {
      void el.requestFullscreen();
    }
  }, []);

  // Keyboard shortcuts.
  useEffect(() => {
    if (!open) return;
    const handler = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement;
      if (target.tagName === "INPUT" || target.tagName === "TEXTAREA") return;
      switch (e.key) {
        case " ":
          e.preventDefault();
          togglePlay();
          break;
        case "ArrowLeft":
          e.preventDefault();
          skipBackward();
          break;
        case "ArrowRight":
          e.preventDefault();
          skipForward();
          break;
        case "m":
        case "M":
          e.preventDefault();
          setMuted((m) => !m);
          break;
        case "f":
        case "F":
          e.preventDefault();
          toggleFullscreen();
          break;
      }
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [open, togglePlay, skipBackward, skipForward, toggleFullscreen]);

  const playPct = duration > 0 ? (current / duration) * 100 : 0;

  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-4xl gap-0 border-zinc-800 bg-zinc-950 p-0 sm:rounded-xl">
        <DialogHeader className="border-b border-zinc-800 px-5 py-3">
          <DialogTitle className="flex items-center gap-2 text-sm text-zinc-100">
            <Play className="size-4 text-amber-400" />
            Previsualizar
          </DialogTitle>
          <DialogDescription className="flex items-center gap-2 text-[11px] text-zinc-500">
            {asset && (
              <>
                <span className="truncate font-medium text-zinc-300">{asset.title}</span>
                <CategoryBadge category={asset.category} />
                <span className="font-mono text-zinc-500">{msTime(asset.durationMs)}</span>
              </>
            )}
          </DialogDescription>
        </DialogHeader>

        <div className="px-5 py-4">
          {/* Video container */}
          <div
            ref={containerRef}
            className="relative aspect-video w-full overflow-hidden rounded-lg border border-zinc-800 bg-black"
            onMouseMove={triggerControls}
            onMouseLeave={() => playing && setShowControls(false)}
          >
            <video
              ref={videoRef}
              className="h-full w-full"
              playsInline
              onClick={togglePlay}
            />

            {/* Loading state */}
            {loadState === "loading" && (
              <div className="absolute inset-0 flex flex-col items-center justify-center gap-3 bg-black/70 p-4 text-center">
                <Spinner className="size-7" />
                <div className="text-xs text-zinc-300">Cargando video…</div>
                <div className="flex items-center gap-1.5 rounded-full border border-zinc-700 bg-zinc-900/80 px-2.5 py-0.5 text-[10px] text-zinc-400">
                  {isRemote ? (
                    <>
                      <Cloud className="size-2.5" />
                      Stream remoto (puede tardar)
                    </>
                  ) : (
                    <>
                      <HardDrive className="size-2.5" />
                      Servidor local (rápido)
                    </>
                  )}
                </div>
              </div>
            )}

            {/* Timeout state */}
            {loadState === "timeout" && (
              <div className="absolute inset-0 flex flex-col items-center justify-center gap-3 bg-black/85 p-4 text-center">
                <AlertTriangle className="size-8 text-amber-400" />
                <div className="max-w-sm text-xs text-zinc-200">
                  El video está tardando más de lo normal en cargar.
                </div>
                {isRemote && (
                  <div className="max-w-sm text-[11px] text-zinc-400">
                    Este asset usa un stream HLS remoto que puede estar saturado.
                  </div>
                )}
                <Button
                  size="sm"
                  variant="outline"
                  className="h-7 gap-1.5 border-zinc-700 bg-transparent text-[11px] text-zinc-200 hover:bg-zinc-800"
                  onClick={() => setRetryNonce((n) => n + 1)}
                >
                  <RefreshCw className="size-3" />
                  Reintentar
                </Button>
              </div>
            )}

            {/* Error state */}
            {loadState === "error" && (
              <div className="absolute inset-0 flex flex-col items-center justify-center gap-3 bg-black/85 p-4 text-center">
                <AlertTriangle className="size-8 text-rose-400" />
                <div className="max-w-sm text-xs text-zinc-200">
                  No se pudo cargar el video
                </div>
                {loadErrorMsg && (
                  <div className="max-w-sm text-[11px] text-zinc-400">{loadErrorMsg}</div>
                )}
                <Button
                  size="sm"
                  variant="outline"
                  className="h-7 gap-1.5 border-zinc-700 bg-transparent text-[11px] text-zinc-200 hover:bg-zinc-800"
                  onClick={() => setRetryNonce((n) => n + 1)}
                >
                  <RefreshCw className="size-3" />
                  Reintentar
                </Button>
              </div>
            )}

            {/* Big play button overlay (when paused + ready) */}
            {loadState === "ready" && !playing && (
              <button
                onClick={togglePlay}
                className="absolute inset-0 z-10 flex items-center justify-center transition-opacity hover:bg-black/20"
                aria-label="Reproducir"
              >
                <span className="flex size-16 items-center justify-center rounded-full bg-black/70 text-white transition-all hover:scale-110">
                  <Play className="size-7 translate-x-0.5" />
                </span>
              </button>
            )}

            {/* Source badge (top-left) */}
            {asset && (
              <div
                className={cn(
                  "absolute left-2 top-2 flex items-center gap-1 rounded px-1.5 py-0.5 text-[9px] font-medium",
                  isRemote
                    ? "bg-amber-950/80 text-amber-300"
                    : "bg-emerald-950/80 text-emerald-300"
                )}
              >
                {isRemote ? (
                  <>
                    <Cloud className="size-2.5" />
                    Remoto
                  </>
                ) : (
                  <>
                    <HardDrive className="size-2.5" />
                    Local
                  </>
                )}
              </div>
            )}

            {/* Time badge (top-right) */}
            <div className="absolute right-2 top-2 rounded bg-black/70 px-2 py-0.5 font-mono text-[10px] tabular-nums text-zinc-200">
              {fmtTime(current)} / {fmtTime(duration)}
            </div>

            {/* ---- Bottom controls bar (auto-hide when playing) ---- */}
            {loadState === "ready" && (
              <div
                className={cn(
                  "absolute inset-x-0 bottom-0 z-20 flex items-center gap-2 bg-gradient-to-t from-black/90 to-transparent px-3 pb-2 pt-8 transition-opacity duration-300",
                  showControls ? "opacity-100" : "opacity-0 pointer-events-none"
                )}
              >
                {/* Seekbar */}
                <div
                  ref={timelineRef}
                  className="group/seek relative h-1.5 flex-1 cursor-pointer rounded-full bg-white/20"
                  onPointerDown={(e) => {
                    const tl = timelineRef.current;
                    if (!tl || duration <= 0) return;
                    const rect = tl.getBoundingClientRect();
                    const x = e.clientX - rect.left;
                    const pct = Math.max(0, Math.min(100, (x / rect.width) * 100));
                    const ms = Math.round((pct / 100) * duration);
                    seekTo(ms);
                    dragRef.current = true;
                    tl.setPointerCapture(e.pointerId);
                  }}
                  onPointerMove={(e) => {
                    if (!dragRef.current) return;
                    const tl = timelineRef.current;
                    if (!tl || duration <= 0) return;
                    const rect = tl.getBoundingClientRect();
                    const x = e.clientX - rect.left;
                    const pct = Math.max(0, Math.min(100, (x / rect.width) * 100));
                    const ms = Math.round((pct / 100) * duration);
                    seekTo(ms);
                  }}
                  onPointerUp={(e) => {
                    dragRef.current = false;
                    const tl = timelineRef.current;
                    if (tl) {
                      try { tl.releasePointerCapture(e.pointerId); } catch { /* noop */ }
                    }
                  }}
                >
                  {/* Played portion */}
                  <div
                    className="absolute inset-y-0 left-0 rounded-full bg-amber-500"
                    style={{ width: `${playPct}%` }}
                  />
                  {/* Playhead handle */}
                  <div
                    className="absolute top-1/2 size-3 -translate-x-1/2 -translate-y-1/2 rounded-full bg-white shadow ring-2 ring-amber-500/50 transition-transform group-hover/seek:scale-125"
                    style={{ left: `${playPct}%` }}
                  />
                </div>

                {/* Time display (compact) */}
                <div className="hidden font-mono text-[10px] tabular-nums text-zinc-300 sm:block">
                  {fmtTime(current)} / {fmtTime(duration)}
                </div>
              </div>
            )}
          </div>

          {/* ---- Transport bar (below video) ---- */}
          {loadState === "ready" && (
            <div className="mt-3 flex flex-wrap items-center gap-2 rounded-md border border-zinc-800 bg-zinc-900/60 px-3 py-2">
              {/* Skip to start */}
              <Button
                variant="ghost"
                size="icon"
                className="size-8 text-zinc-300 hover:bg-zinc-800 hover:text-white"
                onClick={() => seekTo(0)}
                title="Saltar al inicio"
                aria-label="Saltar al inicio"
              >
                <SkipBack className="size-4" />
              </Button>
              {/* Skip backward */}
              <div className="relative">
                <Button
                  variant="ghost"
                  size="sm"
                  className="h-8 gap-1 px-2 text-zinc-300 hover:bg-zinc-800 hover:text-white"
                  onClick={skipBackward}
                  title={`Retroceder ${skipStepSec}s`}
                >
                  <Rewind className="size-4" />
                  <span className="text-[10px] font-mono tabular-nums">{skipStepSec}s</span>
                </Button>
                <Select value={String(skipStepSec)} onValueChange={(v) => setSkipStepSec(Number(v))}>
                  <SelectTrigger className="absolute -bottom-1 -right-1 size-3.5 border-zinc-700 bg-zinc-800 p-0 opacity-70 hover:opacity-100" />
                  <SelectContent className="border-zinc-700 bg-zinc-900">
                    <SelectItem value="5">5s</SelectItem>
                    <SelectItem value="10">10s</SelectItem>
                    <SelectItem value="30">30s</SelectItem>
                    <SelectItem value="60">1min</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              {/* Play/Pause */}
              <Button
                variant="default"
                size="icon"
                className="size-9 bg-amber-500 text-zinc-950 hover:bg-amber-400"
                onClick={togglePlay}
                title={playing ? "Pausar (Espacio)" : "Reproducir (Espacio)"}
              >
                {playing ? <Pause className="size-4" /> : <Play className="size-4 translate-x-0.5" />}
              </Button>
              {/* Skip forward */}
              <div className="relative">
                <Button
                  variant="ghost"
                  size="sm"
                  className="h-8 gap-1 px-2 text-zinc-300 hover:bg-zinc-800 hover:text-white"
                  onClick={skipForward}
                  title={`Avanzar ${skipStepSec}s`}
                >
                  <span className="text-[10px] font-mono tabular-nums">{skipStepSec}s</span>
                  <FastForward className="size-4" />
                </Button>
                <Select value={String(skipStepSec)} onValueChange={(v) => setSkipStepSec(Number(v))}>
                  <SelectTrigger className="absolute -bottom-1 -left-1 size-3.5 border-zinc-700 bg-zinc-800 p-0 opacity-70 hover:opacity-100" />
                  <SelectContent className="border-zinc-700 bg-zinc-900">
                    <SelectItem value="5">5s</SelectItem>
                    <SelectItem value="10">10s</SelectItem>
                    <SelectItem value="30">30s</SelectItem>
                    <SelectItem value="60">1min</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              {/* Skip to end */}
              <Button
                variant="ghost"
                size="icon"
                className="size-8 text-zinc-300 hover:bg-zinc-800 hover:text-white"
                onClick={() => seekTo(Math.max(0, duration - 100))}
                title="Saltar al final"
                aria-label="Saltar al final"
              >
                <SkipForward className="size-4" />
              </Button>

              {/* Volume control */}
              <div className="flex items-center gap-1.5">
                <Button
                  variant="ghost"
                  size="icon"
                  className="size-8 text-zinc-300 hover:bg-zinc-800 hover:text-white"
                  onClick={() => setMuted((m) => !m)}
                  title={muted ? "Activar sonido (M)" : "Silenciar (M)"}
                  aria-label={muted ? "Activar sonido" : "Silenciar"}
                >
                  {muted || volume === 0 ? (
                    <VolumeX className="size-4" />
                  ) : (
                    <Volume2 className="size-4" />
                  )}
                </Button>
                <input
                  type="range"
                  min={0}
                  max={100}
                  value={muted ? 0 : volume}
                  onChange={(e) => {
                    const v = Number(e.target.value);
                    setVolume(v);
                    if (v > 0) setMuted(false);
                  }}
                  className="h-1.5 w-20 cursor-pointer appearance-none rounded-full bg-zinc-800 accent-amber-500"
                  aria-label="Volumen"
                />
                <span className="w-7 text-[10px] font-mono tabular-nums text-zinc-400">
                  {muted ? "0" : volume}%
                </span>
              </div>

              {/* Spacer */}
              <div className="ml-auto flex items-center gap-2">
                {/* Playback rate */}
                <div data-rate-menu className="relative">
                  <Button
                    variant="ghost"
                    size="sm"
                    className="h-8 gap-1 px-2 text-zinc-300 hover:bg-zinc-800 hover:text-white"
                    onClick={() => setRateMenuOpen((v) => !v)}
                    title="Velocidad de reproducción"
                  >
                    <Gauge className="size-3.5" />
                    <span className="text-[11px] font-mono tabular-nums">{playbackRate}x</span>
                    <ChevronDown className="size-3 opacity-60" />
                  </Button>
                  {rateMenuOpen && (
                    <div className="absolute right-0 top-full z-30 mt-1 w-24 rounded-md border border-zinc-700 bg-zinc-900 py-1 shadow-xl">
                      {[0.25, 0.5, 1, 1.5, 2].map((rate) => (
                        <button
                          key={rate}
                          onClick={() => {
                            setPlaybackRate(rate);
                            setRateMenuOpen(false);
                          }}
                          className={cn(
                            "flex w-full items-center justify-between px-3 py-1.5 text-[11px] font-mono tabular-nums transition-colors",
                            playbackRate === rate
                              ? "bg-amber-500/15 text-amber-300"
                              : "text-zinc-300 hover:bg-zinc-800 hover:text-white"
                          )}
                        >
                          {rate}x
                          {playbackRate === rate && <span>✓</span>}
                        </button>
                      ))}
                    </div>
                  )}
                </div>

                {/* Fullscreen */}
                <Button
                  variant="ghost"
                  size="icon"
                  className="size-8 text-zinc-300 hover:bg-zinc-800 hover:text-white"
                  onClick={toggleFullscreen}
                  title={isFullscreen ? "Salir de pantalla completa (F)" : "Pantalla completa (F)"}
                  aria-label="Pantalla completa"
                >
                  {isFullscreen ? <Minimize className="size-4" /> : <Maximize className="size-4" />}
                </Button>
              </div>
            </div>
          )}

          {/* Keyboard shortcuts hint */}
          {loadState === "ready" && (
            <div className="mt-2 flex flex-wrap items-center gap-x-3 gap-y-1 text-[9px] text-zinc-600">
              <span><kbd className="rounded border border-zinc-700 bg-zinc-900 px-1 py-0.5 font-mono">Space</kbd> play/pause</span>
              <span><kbd className="rounded border border-zinc-700 bg-zinc-900 px-1 py-0.5 font-mono">←→</kbd> ±{skipStepSec}s</span>
              <span><kbd className="rounded border border-zinc-700 bg-zinc-900 px-1 py-0.5 font-mono">M</kbd> mute</span>
              <span><kbd className="rounded border border-zinc-700 bg-zinc-900 px-1 py-0.5 font-mono">F</kbd> fullscreen</span>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="flex items-center justify-end gap-2 border-t border-zinc-800 px-5 py-3">
          <Button
            variant="ghost"
            size="sm"
            className="text-zinc-400 hover:bg-zinc-800 hover:text-zinc-100"
            onClick={onClose}
          >
            <X className="size-3.5" />
            Cerrar
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

// Helper for msTime display in the header (mm:ss or h:mm:ss).
function msTime(ms: number): string {
  return fmtTime(ms);
}
