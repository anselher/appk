"use client";

import { useEffect, useState } from "react";

interface ShortcutsOverlayProps {
  // Mount with a key to remount; or control via the open prop.
  open: boolean;
  onClose: () => void;
}

interface Shortcut {
  key: string;
  description: string;
}

const SHORTCUTS: { group: string; items: Shortcut[] }[] = [
  {
    group: "Reproducción",
    items: [
      { key: "Espacio / K", description: "Reproducir / Pausar" },
      { key: "M", description: "Silenciar / Activar sonido" },
      { key: "F", description: "Pantalla completa" },
      { key: "P", description: "Picture-in-Picture (ventana flotante)" },
      { key: "↑ / ↓", description: "Subir / Bajar volumen" },
    ],
  },
  {
    group: "Calidad",
    items: [
      { key: "Q", description: "Cambiar/fijar nivel de calidad (Auto → más alta → … → más baja → Auto)" },
    ],
  },
  {
    group: "Navegación (solo DVR)",
    items: [
      { key: "← / →", description: "Retroceder / Avanzar 5s (solo con sincronización en vivo desactivada)" },
    ],
  },
  {
    group: "Ayuda",
    items: [
      { key: "?", description: "Mostrar/ocultar esta ayuda" },
      { key: "Esc", description: "Cerrar esta ventana" },
    ],
  },
];

/**
 * Keyboard shortcuts overlay for the viewer. Toggled with "?".
 * Shows all available shortcuts grouped by category. Close with Esc or click.
 */
export function ShortcutsOverlay({ open, onClose }: ShortcutsOverlayProps) {
  // Esc closes the overlay.
  useEffect(() => {
    if (!open) return;
    const handler = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        e.preventDefault();
        onClose();
      }
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [open, onClose]);

  if (!open) return null;

  return (
    <div
      className="fixed inset-0 z-[100] flex items-center justify-center bg-black/70 p-4 backdrop-blur-sm"
      onClick={onClose}
      role="dialog"
      aria-modal="true"
      aria-label="Atajos de teclado"
    >
      <div
        className="w-full max-w-lg overflow-hidden rounded-2xl border border-amber-500/30 bg-zinc-900/95 shadow-2xl ring-1 ring-amber-500/20"
        onClick={(e) => e.stopPropagation()}
        style={{ animation: "shortcutsIn 220ms cubic-bezier(0.16, 1, 0.3, 1)" }}
      >
        {/* Header */}
        <div className="flex items-center justify-between border-b border-zinc-800 bg-gradient-to-r from-amber-500/10 to-transparent px-5 py-3.5">
          <div className="flex items-center gap-2.5">
            <div className="flex size-7 items-center justify-center rounded-md bg-amber-500/15 text-amber-400">
              <svg className="size-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden>
                <rect width="18" height="11" x="3" y="3" rx="2" />
                <path d="M7 16h10M9 20h6M12 14v6" />
              </svg>
            </div>
            <div>
              <div className="text-sm font-semibold text-zinc-100">Atajos de teclado</div>
              <div className="text-[11px] text-zinc-500">Reproductor Canal Nova</div>
            </div>
          </div>
          <button
            onClick={onClose}
            className="flex size-7 items-center justify-center rounded-md text-zinc-500 transition-colors hover:bg-zinc-800 hover:text-zinc-200"
            aria-label="Cerrar"
          >
            <svg className="size-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><path d="M18 6 6 18M6 6l12 12" /></svg>
          </button>
        </div>

        {/* Body — shortcut groups */}
        <div className="max-h-[70vh] overflow-y-auto custom-scrollbar p-5">
          <div className="space-y-5">
            {SHORTCUTS.map((group) => (
              <div key={group.group}>
                <div className="mb-2 text-[10px] font-bold uppercase tracking-wider text-amber-400/80">
                  {group.group}
                </div>
                <ul className="space-y-1.5">
                  {group.items.map((item) => (
                    <li key={item.key} className="flex items-center gap-3">
                      <kbd className="inline-flex h-6 min-w-[2.5rem] shrink-0 items-center justify-center rounded-md border border-zinc-700 bg-zinc-950 px-2 font-mono text-[10px] font-semibold text-amber-300 shadow-sm">
                        {item.key}
                      </kbd>
                      <span className="text-xs text-zinc-300">{item.description}</span>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>

        {/* Footer */}
        <div className="border-t border-zinc-800 px-5 py-2.5 text-center text-[10px] text-zinc-500">
          Pulsa <kbd className="rounded border border-zinc-700 bg-zinc-950 px-1 font-mono text-amber-300">?</kbd> o <kbd className="rounded border border-zinc-700 bg-zinc-950 px-1 font-mono text-amber-300">Esc</kbd> para cerrar
        </div>
      </div>
      <style>{`
        @keyframes shortcutsIn {
          from { opacity: 0; transform: scale(0.95) translateY(8px); }
          to { opacity: 1; transform: scale(1) translateY(0); }
        }
      `}</style>
    </div>
  );
}

/**
 * Hook that manages the open/closed state of the shortcuts overlay and a
 * keyboard listener for "?" to toggle it. Returns [open, close] for the parent
 * to pass to <ShortcutsOverlay />.
 */
export function useShortcutsOverlay() {
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      const tag = (e.target as HTMLElement)?.tagName;
      if (tag === "INPUT" || tag === "TEXTAREA" || tag === "SELECT") return;
      if (e.key === "?") {
        e.preventDefault();
        setOpen((v) => !v);
      }
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, []);

  return { open, close: () => setOpen(false) } as const;
}
