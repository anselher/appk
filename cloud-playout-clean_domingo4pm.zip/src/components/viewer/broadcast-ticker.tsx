"use client";

import { Radio, ChevronRight } from "lucide-react";
import { msToWallclock, msToWallclock12h, msToHMMSS } from "@/lib/playout";
import type { EpgEntry } from "@/lib/types";

interface BroadcastTickerProps {
  current: EpgEntry | null;
  next: EpgEntry | null;
  elapsedMs: number;
  channelLogo: string;
  channelName: string;
}

/**
 * Broadcast-style lower-third "bug" overlay for the linear TV viewer.
 *
 * Emulates a real TV channel on-screen graphic:
 *  - Channel logo chip + channel name on the left
 *  - "AHORA" program title with a live progress bar and elapsed/remaining
 *  - "SIGUIENTE" next program title + start time
 *
 * Always visible in a compact form; expands to show the full progress bar and
 * next program on hover. Keyboard-focusable for accessibility.
 */
export function BroadcastTicker({
  current,
  next,
  elapsedMs,
  channelLogo,
  channelName,
}: BroadcastTickerProps) {
  if (!current) return null;

  const progress =
    current.endMs > current.startMs
      ? Math.min(100, Math.max(0, ((elapsedMs - current.startMs) / (current.endMs - current.startMs)) * 100))
      : 0;
  const remainingMs = Math.max(0, current.endMs - elapsedMs);

  return (
    <div
      className="pointer-events-none absolute inset-x-0 bottom-0 z-20 flex justify-center px-3 pb-3"
      aria-live="polite"
    >
      <div
        className="group pointer-events-auto w-full max-w-2xl overflow-hidden rounded-xl border border-white/10 bg-zinc-950/80 shadow-2xl shadow-black/50 backdrop-blur-md transition-all duration-300 hover:border-amber-500/30 focus-within:border-amber-500/30"
        tabIndex={0}
        role="region"
        aria-label="Programación actual"
      >
        {/* Top row: channel chip + now/next */}
        <div className="flex items-stretch gap-0">
          {/* Channel chip */}
          <div className="flex items-center gap-2 border-r border-white/10 bg-gradient-to-br from-amber-500/15 to-orange-600/10 px-3 py-2">
            <div className="flex size-7 items-center justify-center rounded-md bg-gradient-to-br from-amber-500 to-orange-600 text-xs font-black text-zinc-950 shadow">
              {channelLogo || channelName.slice(0, 2).toUpperCase()}
            </div>
            <div className="hidden flex-col leading-tight sm:flex">
              <span className="text-[11px] font-bold tracking-wide text-zinc-100">{channelName}</span>
              <span className="flex items-center gap-1 text-[9px] font-medium uppercase tracking-wider text-rose-400">
                <Radio className="size-2.5 animate-pulse" />
                En Vivo
              </span>
            </div>
          </div>

          {/* Now / Next content */}
          <div className="flex min-w-0 flex-1 items-center gap-2 px-3 py-2">
            <div className="min-w-0 flex-1">
              <div className="flex items-center gap-1.5">
                <span className="rounded bg-rose-600 px-1 text-[8px] font-bold uppercase tracking-wider text-white">
                  Ahora
                </span>
                <span className="truncate text-xs font-semibold text-zinc-100">
                  {current.title}
                </span>
              </div>
              {/* Progress bar — expands on hover/focus */}
              <div className="grid grid-rows-[0fr] opacity-0 transition-all duration-300 group-hover:grid-rows-[1fr] group-hover:opacity-100 group-focus-within:grid-rows-[1fr] group-focus-within:opacity-100">
                <div className="overflow-hidden">
                  <div className="mt-1.5 flex items-center gap-2">
                    <span className="font-mono text-[9px] tabular-nums text-zinc-400">
                      {msToWallclock12h(current.startMs)}
                    </span>
                    <div className="relative h-1 flex-1 overflow-hidden rounded-full bg-white/10">
                      <div
                        className="absolute inset-y-0 left-0 rounded-full bg-gradient-to-r from-amber-500 to-orange-400 transition-[width] duration-1000"
                        style={{ width: `${progress}%` }}
                      />
                      <div
                        className="absolute top-1/2 size-2 -translate-y-1/2 rounded-full bg-white shadow ring-2 ring-amber-500 transition-[left] duration-1000"
                        style={{ left: `calc(${progress}% - 4px)` }}
                      />
                    </div>
                    <span className="font-mono text-[9px] tabular-nums text-zinc-400">
                      {msToWallclock12h(current.endMs)}
                    </span>
                  </div>
                </div>
              </div>
            </div>

            {/* Next */}
            {next && (
              <div className="hidden min-w-0 border-l border-white/10 pl-2 sm:block sm:w-40 md:w-48">
                <div className="flex items-center gap-1">
                  <ChevronRight className="size-2.5 shrink-0 text-amber-400" />
                  <span className="text-[8px] font-bold uppercase tracking-wider text-amber-400">
                    Siguiente
                  </span>
                </div>
                <div className="truncate text-[11px] font-medium text-zinc-300">
                  {next.title}
                </div>
                <div className="font-mono text-[9px] tabular-nums text-zinc-500">
                  {msToWallclock12h(next.startMs)} · {msToHMMSS(remainingMs)} restante
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Slim progress line at the very bottom edge (always visible) */}
        <div className="h-0.5 w-full bg-white/5">
          <div
            className="h-full bg-gradient-to-r from-amber-500 to-orange-400 transition-[width] duration-1000"
            style={{ width: `${progress}%` }}
          />
        </div>
      </div>
    </div>
  );
}
