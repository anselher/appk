"use client";

import { useEffect, useRef, useState, useCallback } from "react";
import Hls from "hls.js";
import { Slider } from "@/components/ui/slider";
import { Maximize, Minimize } from "lucide-react";
import { cn } from "@/lib/utils";
import type { PlayoutSegment } from "@/lib/types";

interface VideoPlayerProps {
  segment: PlayoutSegment | null;
  elapsedMs: number; // ms from midnight (Venezuela)
  liveSync: boolean;
  slate: { message: string; secondsLeft: number } | null;
  disablePause?: boolean; // when true, single-click won't pause; double-click = fullscreen
}

/**
 * Linear TV video player with live-sync and full volume control.
 *
 * Live-sync strategy (NON-INTERRUPTING):
 * - Seek ONCE when connecting (initial load) to sync to server time.
 * - Seek ONCE when the segment changes (program/ad boundary).
 * - Let the video play NATURALLY at 1x between seeks (no periodic re-seeking).
 * - Safety net: every 30s, only correct if drift > 30s (buffering stall recovery).
 * - On user pause: allowed. On resume: jump to current live position.
 *
 * The source loops (modulo) if shorter than its broadcast slot.
 */
export function VideoPlayer({ segment, elapsedMs, liveSync, slate, disablePause }: VideoPlayerProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const hlsRef = useRef<Hls | null>(null);
  const currentAssetIdRef = useRef<string | null>(null);
  const lastSeekSegRef = useRef<string | null>(null);
  const elapsedMsRef = useRef(elapsedMs);
  const segmentRef = useRef<PlayoutSegment | null>(segment);

  const [loading, setLoading] = useState(true);
  const [volume, setVolume] = useState(60); // 0-100
  const [muted, setMuted] = useState(true); // start muted for autoplay
  const [paused, setPaused] = useState(false);
  const [showControls, setShowControls] = useState(true);
  const [showStartOverlay, setShowStartOverlay] = useState(true);
  const [isFullscreen, setIsFullscreen] = useState(false);
  // Picture-in-Picture state — tracks whether the video is in a floating PiP window.
  const [isPip, setIsPip] = useState(false);
  // Adaptive Bitrate (ABR) quality tracking — shows the current HLS level
  // (resolution + bitrate) the viewer is receiving. Updated on LEVEL_SWITCHED.
  const [qualityLabel, setQualityLabel] = useState<string | null>(null);
  // Locked HLS level: -1 = auto (ABR), >=0 = a specific level index the user
  // pinned via the "Q" shortcut. When locked, hls.currentLevel is set manually
  // and the ABR controller won't switch.
  const [lockedLevel, setLockedLevel] = useState<number>(-1);
  const [flashQuality, setFlashQuality] = useState(false);

  // Keep refs in sync without triggering re-renders / re-seeks.
  useEffect(() => {
    elapsedMsRef.current = elapsedMs;
  }, [elapsedMs]);
  useEffect(() => {
    segmentRef.current = segment;
  }, [segment]);

  // Compute the target playback position for the current segment at a given elapsed time.
  const computeTarget = useCallback((seg: PlayoutSegment | null, now: number): number => {
    if (!seg) return 0;
    const segmentLocalOffset = now - seg.startMs;
    let targetPos = (seg.seekOffsetMs + segmentLocalOffset) / 1000;
    const video = videoRef.current;
    const dur = video?.duration;
    if (Number.isFinite(dur) && dur > 0) {
      targetPos = targetPos % dur;
    }
    return Math.max(0, targetPos);
  }, []);

  // Seek the video to the exact live position (used on connect + segment change).
  const seekToLive = useCallback(() => {
    const video = videoRef.current;
    const seg = segmentRef.current;
    if (!video || !seg) return;
    const target = computeTarget(seg, elapsedMsRef.current);
    if (Number.isFinite(target)) {
      try {
        video.currentTime = target;
      } catch {
        /* duration not ready */
      }
    }
  }, [computeTarget]);

  // ---- Source loading + initial seek (only when asset changes) ----
  useEffect(() => {
    const video = videoRef.current;
    if (!video || !segment) return;

    const assetChanged = currentAssetIdRef.current !== segment.assetId;
    const segKey = `${segment.assetId}:${segment.startMs}`;
    const segChanged = lastSeekSegRef.current !== segKey;

    if (assetChanged) {
      currentAssetIdRef.current = segment.assetId;
      lastSeekSegRef.current = segKey;
      // The quality label is refreshed by the new stream's MANIFEST_PARSED /
      // FRAG_PARSED handlers (see below). No synchronous reset here to avoid
      // a setState-in-effect lint violation.
      // loading state is set by the video's onLoadStart event.

      if (hlsRef.current) {
        hlsRef.current.destroy();
        hlsRef.current = null;
      }

      const url = segment.asset.hlsUrl;
      // Detect if this is a raw MP4 (e.g. a rendered Avance) vs an HLS stream.
      // MP4 files are loaded natively by the browser (no HLS.js needed) — the
      // browser handles range requests, seeking, and buffering automatically.
      const isMp4 = url.endsWith(".mp4") || url.includes(".mp4?");

      if (isMp4) {
        // ---- Native MP4 playback (rendered Avance) ----
        // The render is a single MP4 with +faststart, so the browser can
        // start playing immediately and seek to any position via Range requests.
        video.src = url;
        setQualityLabel("MP4 · Render");
        const onMeta = () => {
          seekToLive();
          if (!paused) void video.play().catch(() => {});
        };
        video.addEventListener("loadedmetadata", onMeta, { once: true });
      } else if (Hls.isSupported()) {
        const hls = new Hls({
          enableWorker: true,
          lowLatencyMode: false,
          startLevel: -1,
          maxBufferLength: 30,
          maxMaxBufferLength: 60,
        });
        hlsRef.current = hls;
        hls.loadSource(url);
        hls.attachMedia(video);
        hls.on(Hls.Events.MANIFEST_PARSED, () => {
          seekToLive();
          if (!paused) void video.play().catch(() => {});
        });
        // Track the active ABR level for the on-screen quality indicator.
        const updateQuality = () => {
          const level = hls.currentLevel;
          if (level && level.height && level.bitrate) {
            const heightP = `${level.height}p`;
            const mbps = (level.bitrate / 1_000_000).toFixed(1);
            setQualityLabel(`${heightP} · ${mbps} Mbps`);
          } else if (level && level.height) {
            setQualityLabel(`${level.height}p`);
          } else if (hls.levels && hls.levels.length > 0) {
            // currentLevel may be -1 (auto) before first switch; infer from
            // the video element dimensions or the first level.
            const v = videoRef.current;
            if (v && v.videoHeight) {
              setQualityLabel(`${v.videoHeight}p`);
            } else {
              const first = hls.levels[0];
              setQualityLabel(first?.height ? `${first.height}p` : "AUTO");
            }
          } else {
            setQualityLabel(null);
          }
        };
        hls.on(Hls.Events.LEVEL_SWITCHED, updateQuality);
        hls.on(Hls.Events.MANIFEST_PARSED, updateQuality);
        hls.on(Hls.Events.FRAG_PARSED, updateQuality);
        hls.on(Hls.Events.ERROR, (_e, data) => {
          if (data.fatal) {
            if (data.type === Hls.ErrorTypes.NETWORK_ERROR) hls.startLoad();
            else if (data.type === Hls.ErrorTypes.MEDIA_ERROR) hls.recoverMediaError();
          }
        });
      } else if (video.canPlayType("application/vnd.apple.mpegurl")) {
        video.src = url;
        const onMeta = () => {
          seekToLive();
          if (!paused) void video.play().catch(() => {});
        };
        video.addEventListener("loadedmetadata", onMeta, { once: true });
      }
    } else if (segChanged) {
      // Same asset, new segment (e.g. returning from ad break to program).
      lastSeekSegRef.current = segKey;
      seekToLive();
    }
    // else: same segment — do nothing, let it play naturally.
  }, [segment, seekToLive, paused]);

  // ---- Drift safety net: every 30s, only correct if drift > 30s ----
  useEffect(() => {
    if (!liveSync) return;
    const interval = setInterval(() => {
      const video = videoRef.current;
      const seg = segmentRef.current;
      if (!video || !seg || video.paused) return;
      const target = computeTarget(seg, elapsedMsRef.current);
      const drift = Math.abs(video.currentTime - target);
      // Only correct large drift (e.g. after a long buffering stall).
      if (drift > 30) {
        try {
          video.currentTime = target;
        } catch {
          /* noop */
        }
      }
    }, 30000);
    return () => clearInterval(interval);
  }, [liveSync, computeTarget]);

  // ---- Fullscreen handling ----
  const toggleFullscreen = useCallback(() => {
    const el = containerRef.current;
    if (!el) return;
    if (!document.fullscreenElement) {
      void el.requestFullscreen?.().catch(() => {});
    } else {
      void document.exitFullscreen?.().catch(() => {});
    }
  }, []);

  useEffect(() => {
    const onFs = () => setIsFullscreen(!!document.fullscreenElement);
    document.addEventListener("fullscreenchange", onFs);
    return () => document.removeEventListener("fullscreenchange", onFs);
  }, []);

  // ---- Picture-in-Picture handling ----
  const togglePip = useCallback(async () => {
    const video = videoRef.current;
    if (!video) return;
    try {
      if (document.pictureInPictureElement) {
        await document.exitPictureInPicture();
      } else if (document.pictureInPictureEnabled && !video.disablePictureInPicture) {
        await video.requestPictureInPicture();
      }
    } catch {
      /* PiP not available or blocked (e.g. user gesture required) */
    }
  }, []);

  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;
    const onEnter = () => setIsPip(true);
    const onLeave = () => setIsPip(false);
    video.addEventListener("enterpictureinpicture", onEnter);
    video.addEventListener("leavepictureinpicture", onLeave);
    return () => {
      video.removeEventListener("enterpictureinpicture", onEnter);
      video.removeEventListener("leavepictureinpicture", onLeave);
    };
  }, []);

  useEffect(() => {
    const video = videoRef.current;
    if (video) {
      video.volume = volume / 100;
      video.muted = muted;
    }
  }, [volume, muted]);

  // ---- Avance fade in/out overlay ----
  // When the current segment is an Avance clip with avanceFadeIn or avanceFadeOut,
  // we overlay a black div whose opacity we animate via requestAnimationFrame.
  // We also duck the video volume during the fade.
  //
  // Smoothness: we capture the server's elapsedMs at the moment the segment becomes
  // active, plus the local performance.now() at that same moment. On each rAF tick
  // we compute "serverElapsedNow = baseElapsed + (performance.now() - basePerfNow)"
  // to interpolate smoothly between server polls (which only arrive every 1s).
  const [fadeOpacity, setFadeOpacity] = useState(0);
  const fadeRafRef = useRef<number | null>(null);
  const fadeBaseElapsedRef = useRef(0);
  const fadeBasePerfRef = useRef(0);

  useEffect(() => {
    // Cancel any previous animation frame.
    if (fadeRafRef.current !== null) {
      cancelAnimationFrame(fadeRafRef.current);
      fadeRafRef.current = null;
    }

    const seg = segment;
    if (!seg || seg.kind !== "avance") {
      setFadeOpacity(0);
      return;
    }

    // Anchor: at this moment, the server clock reads elapsedMsRef.current.
    // We'll interpolate forward using performance.now() between server polls.
    fadeBaseElapsedRef.current = elapsedMsRef.current;
    fadeBasePerfRef.current = performance.now();

    const tick = () => {
      // Interpolated "now" in server time (ms from midnight).
      const interpElapsed =
        fadeBaseElapsedRef.current + (performance.now() - fadeBasePerfRef.current);
      const segStart = seg.startMs;
      const segEnd = seg.endMs;
      let opacity = 0;

      if (seg.avanceFadeIn && seg.avanceFadeIn.ms > 0) {
        const fadeMs = seg.avanceFadeIn.ms;
        const intoFade = interpElapsed - segStart;
        if (intoFade < fadeMs) {
          // Fade-in: opacity 1 → 0 over fadeMs.
          opacity = Math.max(opacity, 1 - Math.max(0, intoFade) / fadeMs);
        }
      }
      if (seg.avanceFadeOut && seg.avanceFadeOut.ms > 0) {
        const fadeMs = seg.avanceFadeOut.ms;
        const intoOut = segEnd - interpElapsed;
        if (intoOut < fadeMs) {
          // Fade-out: opacity 0 → 1 over fadeMs.
          opacity = Math.max(opacity, 1 - Math.max(0, intoOut) / fadeMs);
        }
      }
      const clampedOpacity = Math.max(0, Math.min(1, opacity));
      setFadeOpacity(clampedOpacity);

      // Duck the volume during fades.
      const video = videoRef.current;
      if (video && !muted) {
        const baseVol = volume / 100;
        video.volume = baseVol * (1 - clampedOpacity);
      }

      fadeRafRef.current = requestAnimationFrame(tick);
    };
    fadeRafRef.current = requestAnimationFrame(tick);

    return () => {
      if (fadeRafRef.current !== null) {
        cancelAnimationFrame(fadeRafRef.current);
        fadeRafRef.current = null;
      }
      // Restore volume on unmount/segment-change.
      const video = videoRef.current;
      if (video && !muted) {
        video.volume = volume / 100;
      }
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [segment]);

  // ---- Derived: slate overlay during ad breaks / fillers ----
  const showSlate = !!(
    slate &&
    segment &&
    (segment.kind === "ad" || segment.kind === "filler")
  );

  // ---- Controls ----
  const handlePlayPause = useCallback(() => {
    const video = videoRef.current;
    if (!video) return;
    if (video.paused) {
      // Resuming → jump to live position first (live TV behavior).
      if (liveSync) seekToLive();
      void video.play().catch(() => {});
      setPaused(false);
    } else {
      video.pause();
      setPaused(true);
    }
  }, [liveSync, seekToLive]);

  // Click handler for the video element: distinguishes single-click from double-click.
  // - disablePause=true: single-click does nothing, double-click = fullscreen.
  // - disablePause=false: single-click = play/pause (original behavior).
  const clickTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const handleVideoClick = useCallback(() => {
    if (disablePause) {
      // Only double-click triggers fullscreen; single-click is a no-op.
      return;
    }
    // Distinguish single vs double click: wait 250ms; if a second click arrives,
    // it's a double-click (let the browser's dblclick handle fullscreen).
    if (clickTimerRef.current) {
      clearTimeout(clickTimerRef.current);
      clickTimerRef.current = null;
      return; // double-click — let the dblclick handler fire
    }
    clickTimerRef.current = setTimeout(() => {
      clickTimerRef.current = null;
      handlePlayPause();
    }, 250);
  }, [disablePause, handlePlayPause]);

  // Double-click handler: always toggles fullscreen (regardless of disablePause).
  const handleVideoDoubleClick = useCallback(() => {
    // Cancel any pending single-click.
    if (clickTimerRef.current) {
      clearTimeout(clickTimerRef.current);
      clickTimerRef.current = null;
    }
    toggleFullscreen();
  }, [toggleFullscreen]);

  const handleToggleMute = useCallback(() => {
    setMuted((m) => {
      const next = !m;
      if (next === false) setShowStartOverlay(false);
      return next;
    });
  }, []);

  // Cycle through available HLS quality levels: auto → highest → ... → lowest → auto.
  // When a level is locked, hls.currentLevel is pinned (ABR won't switch).
  const handleCycleQuality = useCallback(() => {
    const hls = hlsRef.current;
    if (!hls || !hls.levels || hls.levels.length === 0) return;
    // hls.levels are ordered lowest → highest by convention.
    // Cycle order: auto (-1) → highest (last index) → ... → lowest (0) → auto.
    let next: number;
    if (lockedLevel === -1) {
      // Currently auto → lock to highest.
      next = hls.levels.length - 1;
    } else if (lockedLevel === 0) {
      // Currently lowest → back to auto.
      next = -1;
    } else {
      // Currently locked at some index → step down one level.
      next = lockedLevel - 1;
    }
    hls.currentLevel = next;
    setLockedLevel(next);
    // Briefly flash the badge to confirm the change.
    setFlashQuality(true);
    window.setTimeout(() => setFlashQuality(false), 1200);
  }, [lockedLevel]);

  // ---- Keyboard shortcuts ----
  // Space/K = play-pause, M = mute, F = fullscreen, ArrowUp/Down = volume, ArrowLeft/Right = seek ±5s (only when liveSync off)
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      // Ignore when typing in inputs.
      const tag = (e.target as HTMLElement)?.tagName;
      if (tag === "INPUT" || tag === "TEXTAREA" || tag === "SELECT") return;
      const el = containerRef.current;
      if (!el) return;
      // Only react when this player is currently hovered/focused.
      if (!el.dataset.kbActive) return;

      switch (e.key) {
        case " ":
        case "k":
          // Space/K = play/pause — blocked when disablePause is on.
          if (!disablePause) {
            e.preventDefault();
            handlePlayPause();
          }
          break;
        case "m":
        case "M":
          e.preventDefault();
          handleToggleMute();
          break;
        case "f":
        case "F":
          e.preventDefault();
          toggleFullscreen();
          break;
        case "ArrowUp":
          e.preventDefault();
          setVolume((v) => {
            const nv = Math.min(100, v + 5);
            if (nv > 0) setMuted(false);
            return nv;
          });
          break;
        case "ArrowDown":
          e.preventDefault();
          setVolume((v) => Math.max(0, v - 5));
          break;
        case "ArrowLeft":
        case "ArrowRight": {
          // Seek only allowed when liveSync is OFF (otherwise we must stay at live edge).
          if (liveSync) return;
          e.preventDefault();
          const v = videoRef.current;
          if (!v) return;
          const delta = e.key === "ArrowRight" ? 5 : -5;
          v.currentTime = Math.max(0, Math.min((v.duration || 0) - 0.5, v.currentTime + delta));
          break;
        }
        case "q":
        case "Q":
          e.preventDefault();
          handleCycleQuality();
          break;
        case "p":
        case "P":
          e.preventDefault();
          void togglePip();
          break;
      }
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [handlePlayPause, handleToggleMute, toggleFullscreen, liveSync, handleCycleQuality, togglePip, disablePause]);

  const handleVolumeChange = useCallback((val: number[]) => {
    const v = val[0] ?? 0;
    setVolume(v);
    if (v > 0 && muted) setMuted(false);
    setShowStartOverlay(false);
  }, [muted]);

  const handleStart = useCallback(() => {
    const video = videoRef.current;
    if (!video) return;
    setMuted(false);
    setShowStartOverlay(false);
    if (liveSync) seekToLive();
    void video.play().catch(() => {});
  }, [liveSync, seekToLive]);

  // Auto-hide controls after inactivity.
  const hideTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const pausedRef = useRef(paused);
  useEffect(() => { pausedRef.current = paused; }, [paused]);
  const triggerControls = useCallback(() => {
    setShowControls(true);
    if (hideTimerRef.current) clearTimeout(hideTimerRef.current);
    hideTimerRef.current = setTimeout(() => {
      if (!pausedRef.current) setShowControls(false);
    }, 3500);
  }, []);

  useEffect(() => {
    return () => {
      if (hideTimerRef.current) clearTimeout(hideTimerRef.current);
    };
  }, []);

  // Cleanup HLS on unmount.
  useEffect(() => {
    return () => {
      if (hlsRef.current) {
        hlsRef.current.destroy();
        hlsRef.current = null;
      }
    };
  }, []);

  // Volume icon based on level.
  const VolumeIcon = muted || volume === 0
    ? <VolMutedIcon />
    : volume < 40
    ? <VolLowIcon />
    : volume < 70
    ? <VolMidIcon />
    : <VolHighIcon />;

  return (
    <div
      ref={containerRef}
      className="relative h-full w-full bg-black"
      onMouseMove={(e) => {
        triggerControls();
        // Mark this player as the active one for keyboard shortcuts.
        (e.currentTarget as HTMLElement).dataset.kbActive = "1";
      }}
      onMouseEnter={(e) => {
        (e.currentTarget as HTMLElement).dataset.kbActive = "1";
      }}
      onMouseLeave={(e) => {
        delete (e.currentTarget as HTMLElement).dataset.kbActive;
        if (!paused) setShowControls(false);
      }}
    >
      <video
        ref={videoRef}
        className="h-full w-full object-contain"
        playsInline
        loop
        onClick={handleVideoClick}
        onDoubleClick={handleVideoDoubleClick}
        onCanPlay={() => setLoading(false)}
        onLoadStart={() => setLoading(true)}
        onWaiting={() => setLoading(true)}
        onPlaying={() => { setLoading(false); setPaused(false); }}
        onPause={() => setPaused(true)}
        onEnded={() => {
          // loop attribute handles this, but as fallback:
          const video = videoRef.current;
          if (video) { video.currentTime = 0; void video.play().catch(() => {}); }
        }}
      />
      {/* Avance fade in/out overlay — black div whose opacity animates via rAF.
          Pointer-events-none so it never blocks the video controls. */}
      {fadeOpacity > 0.001 && (
        <div
          className="pointer-events-none absolute inset-0 z-30 bg-black transition-none"
          style={{ opacity: fadeOpacity }}
          aria-hidden
        />
      )}

      {/* Loading spinner */}
      {loading && !paused && (
        <div className="absolute inset-0 flex items-center justify-center bg-black/40 pointer-events-none">
          <div className="h-12 w-12 rounded-full border-4 border-white/20 border-t-white animate-spin" />
        </div>
      )}

      {/* Slate overlay during ad breaks / fillers */}
      {showSlate && slate && (
        <div className="pointer-events-none absolute inset-x-0 bottom-16 flex justify-center">
          <div className="m-4 rounded-lg bg-black/80 px-5 py-3 text-center backdrop-blur">
            <p className="text-sm font-medium text-amber-300">{slate.message}</p>
          </div>
        </div>
      )}

      {/* EN VIVO badge */}
      <div className={`absolute top-3 left-3 flex items-center gap-2 rounded-md bg-red-600 px-2.5 py-1 text-xs font-bold text-white shadow-lg transition-opacity duration-300 ${showControls ? "opacity-100" : "opacity-0"}`}>
        <span className="relative flex h-2 w-2">
          <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-white opacity-75" />
          <span className="relative inline-flex h-2 w-2 rounded-full bg-white" />
        </span>
        EN VIVO
      </div>

      {/* Start overlay (first load — click to start with sound) */}
      {showStartOverlay && (
        <button
          onClick={handleStart}
          className="absolute inset-0 z-30 flex items-center justify-center bg-black/50 backdrop-blur-sm"
        >
          <div className="flex flex-col items-center gap-3 rounded-2xl bg-black/80 px-8 py-6">
            <div className="flex h-16 w-16 items-center justify-center rounded-full bg-amber-500 text-zinc-950">
              <svg className="ml-1 h-8 w-8" viewBox="0 0 24 24" fill="currentColor"><polygon points="6 4 20 12 6 20 6 4" /></svg>
            </div>
            <span className="text-base font-semibold text-white">Iniciar transmisión</span>
            <span className="text-xs text-zinc-400">Click para ver y escuchar el canal en vivo</span>
          </div>
        </button>
      )}

      {/* Bottom control bar */}
      <div className={`absolute inset-x-0 bottom-0 z-20 bg-gradient-to-t from-black/90 via-black/60 to-transparent px-4 pb-3 pt-10 transition-all duration-300 ${showControls ? "translate-y-0 opacity-100" : "translate-y-2 opacity-0 pointer-events-none"}`}>
        <div className="flex items-center gap-3">
          {/* Play / Pause — hidden when disablePause is on (transmission can't stop) */}
          {!disablePause && (
          <button
            onClick={handlePlayPause}
            className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-white/10 text-white transition-colors hover:bg-white/20"
            aria-label={paused ? "Reproducir" : "Pausar"}
          >
            {paused ? (
              <svg className="ml-0.5 h-5 w-5" viewBox="0 0 24 24" fill="currentColor"><polygon points="6 4 20 12 6 20 6 4" /></svg>
            ) : (
              <svg className="h-5 w-5" viewBox="0 0 24 24" fill="currentColor"><rect x="6" y="4" width="4" height="16" rx="1" /><rect x="14" y="4" width="4" height="16" rx="1" /></svg>
            )}
          </button>
          )}

          {/* Mute toggle */}
          <button
            onClick={handleToggleMute}
            className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-white/10 text-white transition-colors hover:bg-white/20"
            aria-label={muted ? "Activar sonido" : "Silenciar"}
          >
            {VolumeIcon}
          </button>

          {/* Volume slider */}
          <div className="w-28 sm:w-36">
            <Slider
              value={[muted ? 0 : volume]}
              max={100}
              step={1}
              onValueChange={handleVolumeChange}
              className="cursor-pointer"
              aria-label="Volumen"
            />
          </div>

          {/* Volume percentage */}
          <span className="w-9 shrink-0 text-center font-mono text-xs text-white/80 tabular-nums">
            {muted ? "0%" : `${volume}%`}
          </span>

          <div className="flex-1" />

          {/* Now playing label */}
          {segment && (
            <span className="hidden truncate text-xs text-white/70 sm:block max-w-[200px]">
              {segment.asset.title}
            </span>
          )}

          {/* ABR quality indicator — shows current HLS level (resolution + bitrate).
              Click or press "Q" to cycle/lock quality levels. */}
          {qualityLabel && (
            <button
              onClick={handleCycleQuality}
              className={cn(
                "hidden shrink-0 items-center gap-1.5 rounded-md border px-2 py-1 font-mono text-[11px] font-semibold transition-all sm:flex",
                flashQuality
                  ? "scale-110 border-emerald-400 bg-emerald-500/30 text-white"
                  : lockedLevel >= 0
                    ? "border-amber-400/50 bg-amber-500/15 text-amber-300 hover:bg-amber-500/25"
                    : "border-emerald-500/40 bg-emerald-500/10 text-emerald-300 hover:bg-emerald-500/20"
              )}
              title={
                lockedLevel >= 0
                  ? `Calidad fijada en nivel ${lockedLevel} · Pulsa Q para cambiar (Auto → más alta → … → más baja → Auto)`
                  : "Calidad adaptativa automática (ABR) · Pulsa Q para fijar el nivel"
              }
              aria-label="Cambiar calidad (Q)"
            >
              {lockedLevel >= 0 ? (
                // Lock icon — quality is pinned
                <svg className="size-3" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" aria-hidden>
                  <rect width="18" height="11" x="3" y="11" rx="2" ry="2" />
                  <path d="M7 11V7a5 5 0 0 1 10 0v4" />
                </svg>
              ) : (
                // Auto indicator — pulsing dot
                <span className="relative flex size-1.5">
                  <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-400 opacity-75" />
                  <span className="relative inline-flex size-1.5 rounded-full bg-emerald-400" />
                </span>
              )}
              {qualityLabel}
              {lockedLevel < 0 && (
                <span className="text-[8px] font-bold uppercase tracking-wider opacity-60">Auto</span>
              )}
            </button>
          )}

          {/* Picture-in-Picture toggle */}
          <button
            onClick={togglePip}
            className={cn(
              "flex h-9 w-9 shrink-0 items-center justify-center rounded-full transition-colors",
              isPip
                ? "bg-amber-500 text-zinc-950 hover:bg-amber-400"
                : "bg-white/10 text-white hover:bg-white/20"
            )}
            aria-label={isPip ? "Salir de Picture-in-Picture" : "Picture-in-Picture"}
            title={isPip ? "Salir de Picture-in-Picture (P)" : "Picture-in-Picture (P)"}
          >
            <svg className="size-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden>
              <path d="M2 4a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2z" />
              <rect width="8" height="6" x="13" y="11" rx="1" fill="currentColor" stroke="none" />
            </svg>
          </button>

          {/* Fullscreen toggle */}
          <button
            onClick={toggleFullscreen}
            className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-white/10 text-white transition-colors hover:bg-white/20"
            aria-label={isFullscreen ? "Salir de pantalla completa" : "Pantalla completa"}
            title={isFullscreen ? "Salir de pantalla completa (F)" : "Pantalla completa (F)"}
          >
            {isFullscreen ? (
              <Minimize className="size-4" />
            ) : (
              <Maximize className="size-4" />
            )}
          </button>
        </div>
      </div>

      {/* Keyboard shortcuts hint (small, bottom-left) */}
      <div
        className={`pointer-events-none absolute bottom-3 left-3 z-10 hidden text-[10px] text-white/40 transition-opacity duration-300 sm:block ${showControls ? "opacity-100" : "opacity-0"}`}
      >
        <kbd className="rounded border border-white/20 bg-black/40 px-1">Espacio</kbd> play/pause
        · <kbd className="rounded border border-white/20 bg-black/40 px-1">M</kbd> mute
        · <kbd className="rounded border border-white/20 bg-black/40 px-1">F</kbd> pantalla completa
        · <kbd className="rounded border border-white/20 bg-black/40 px-1">P</kbd> picture-in-picture
        · <kbd className="rounded border border-white/20 bg-black/40 px-1">Q</kbd> calidad
        · <kbd className="rounded border border-white/20 bg-black/40 px-1">↑↓</kbd> volumen
      </div>
    </div>
  );
}

// ---- Volume icons ----
function VolMutedIcon() {
  return (
    <svg className="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5" />
      <line x1="23" y1="9" x2="17" y2="15" />
      <line x1="17" y1="9" x2="23" y2="15" />
    </svg>
  );
}
function VolLowIcon() {
  return (
    <svg className="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5" />
      <path d="M15.54 8.46a5 5 0 0 1 0 7.07" />
    </svg>
  );
}
function VolMidIcon() {
  return (
    <svg className="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5" />
      <path d="M15.54 8.46a5 5 0 0 1 0 7.07" />
      <path d="M19.07 4.93a10 10 0 0 1 0 14.14" />
    </svg>
  );
}
function VolHighIcon() {
  return (
    <svg className="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5" />
      <path d="M15.54 8.46a5 5 0 0 1 0 7.07" />
      <path d="M19.07 4.93a10 10 0 0 1 0 14.14" />
      <path d="M22 2a16 16 0 0 1 0 20" />
    </svg>
  );
}
