"use client";

import { useEffect, useState } from "react";
import { Radio } from "lucide-react";
import { msToWallclock } from "@/lib/playout";
import type { EpgEntry } from "@/lib/types";

interface ProgramChangeToastProps {
  entry: EpgEntry;
}

/**
 * "Now Playing" toast that appears when the live program changes.
 *
 * Mounted with a `key={slotId}` by the parent so it remounts on each program
 * change — on mount it is visible and auto-hides after 5s via a setTimeout
 * callback (no synchronous setState in the effect body, so lint-clean).
 *
 * Slide-in from the top, frosted dark glass, shows the program title + time
 * range + a LIVE badge. Clickable to dismiss early.
 */
export function ProgramChangeToast({ entry }: ProgramChangeToastProps) {
  const [visible, setVisible] = useState(true);

  // Auto-hide after 5s. setState is inside a setTimeout callback (not
  // synchronous in the effect body) → satisfies react-hooks/set-state-in-effect.
  useEffect(() => {
    const t = setTimeout(() => setVisible(false), 5000);
    return () => clearTimeout(t);
  }, []);

  if (!visible) return null;

  return (
    <div className="pointer-events-none fixed left-1/2 top-4 z-50 -translate-x-1/2 px-3">
      <div
        className="pointer-events-auto flex items-center gap-3 rounded-xl border border-amber-500/40 bg-zinc-900/95 px-4 py-2.5 shadow-2xl shadow-amber-900/20 ring-1 ring-amber-500/20 backdrop-blur-md"
        style={{
          animation: "programToastIn 320ms cubic-bezier(0.16, 1, 0.3, 1)",
        }}
        onClick={() => setVisible(false)}
        role="status"
        aria-live="polite"
        aria-label={`Ahora: ${entry.title}`}
      >
        {/* LIVE badge */}
        <span className="flex items-center gap-1 rounded-md bg-rose-600 px-1.5 py-0.5 text-[9px] font-bold uppercase tracking-wider text-white">
          <span className="size-1.5 animate-pulse rounded-full bg-white" />
          En Vivo
        </span>
        {/* Now playing label + title */}
        <div className="flex min-w-0 items-center gap-2">
          <Radio className="size-3.5 shrink-0 text-amber-400" />
          <div className="min-w-0">
            <div className="text-[9px] font-bold uppercase tracking-wider text-zinc-500">
              Ahora
            </div>
            <div className="max-w-[280px] truncate text-sm font-semibold text-zinc-100">
              {entry.title}
            </div>
          </div>
        </div>
        {/* Time range */}
        <div className="hidden font-mono text-[10px] tabular-nums text-zinc-400 sm:block">
          {msToWallclock(entry.startMs)} — {msToWallclock(entry.endMs)}
        </div>
      </div>
      {/* Keyframes for the slide-in animation */}
      <style>{`
        @keyframes programToastIn {
          from { opacity: 0; transform: translateY(-12px) scale(0.96); }
          to { opacity: 1; transform: translateY(0) scale(1); }
        }
      `}</style>
    </div>
  );
}
