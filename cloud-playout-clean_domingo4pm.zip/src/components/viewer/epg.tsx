"use client";

import { useMemo } from "react";
import { Radio, Clock, ChevronRight, ImageIcon } from "lucide-react";
import type { EpgEntry, PlayoutState } from "@/lib/types";
import { msToWallclock, msToWallclock12h, msToHMMSS } from "@/lib/playout";

interface EpgProps {
  state: PlayoutState | null;
  previewDate: string | null; // null = today (live), else YYYY-MM-DD preview
  onLoadTomorrow: () => void;
  previewDays: number;
  channelName: string;
  channelLogo: string;
}

function fmtDateLabel(dateStr: string): string {
  const [y, m, d] = dateStr.split("-").map(Number);
  const dt = new Date(Date.UTC(y, m - 1, d));
  const days = ["Domingo", "Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado"];
  const months = ["Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"];
  return `${days[dt.getUTCDay()]} ${d} de ${months[dt.getUTCMonth()]}`;
}

export function Epg({ state, previewDate, onLoadTomorrow, previewDays, channelName, channelLogo }: EpgProps) {
  const elapsedMs = state?.elapsedMs ?? 0;
  const epg = state?.epg ?? [];

  const { nowEntries, nextEntry, futureEntries, pastEntries } = useMemo(() => {
    if (previewDate) {
      return { nowEntries: [], nextEntry: null, futureEntries: epg, pastEntries: [] };
    }
    const now: EpgEntry[] = [];
    let next: EpgEntry | null = null;
    const future: EpgEntry[] = [];
    for (const e of epg) {
      if (elapsedMs >= e.startMs && elapsedMs < e.endMs) {
        now.push(e);
      } else if (e.startMs > elapsedMs && !next && !e.isFiller) {
        next = e;
      } else if (e.startMs > elapsedMs) {
        future.push(e);
      }
    }
    return { nowEntries: now, nextEntry: next, futureEntries: future, pastEntries: [] };
  }, [epg, elapsedMs, previewDate]);

  const current = nowEntries[0] ?? null;
  const currentProgress = current
    ? Math.min(100, Math.max(0, ((elapsedMs - current.startMs) / (current.endMs - current.startMs)) * 100))
    : 0;

  return (
    <div className="flex h-full flex-col bg-zinc-950 text-zinc-100">
      {/* Channel header */}
      <div className="flex items-center gap-3 border-b border-zinc-800 bg-gradient-to-r from-zinc-950 to-zinc-900/40 px-4 py-3">
        <div className="relative flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-amber-500 to-orange-600 text-lg font-black text-zinc-950 shadow-lg shadow-amber-600/20 ring-1 ring-white/10">
          {channelLogo || channelName.slice(0, 2).toUpperCase()}
        </div>
        <div className="min-w-0 flex-1">
          <h1 className="truncate text-base font-bold tracking-tight text-zinc-50">{channelName}</h1>
          <p className="flex items-center gap-1.5 text-xs text-zinc-400">
            <span className="relative flex h-1.5 w-1.5">
              <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-red-500 opacity-75" />
              <span className="relative inline-flex h-1.5 w-1.5 rounded-full bg-red-500" />
            </span>
            Televisión Lineal · Venezuela
          </p>
        </div>
        <div className="text-right">
          <div className="font-mono text-lg font-bold tabular-nums text-amber-400 drop-shadow-[0_0_8px] drop-shadow-amber-500/30">
            {msToWallclock(elapsedMs)}
          </div>
          <div className="text-[10px] font-medium uppercase tracking-wider text-zinc-500">GMT-4</div>
        </div>
      </div>

      {/* Date label */}
      <div className="border-b border-zinc-800/60 bg-zinc-900/50 px-4 py-1.5 text-xs font-medium text-zinc-400">
        {previewDate ? `Programación — ${fmtDateLabel(previewDate)}` : "Programación de Hoy"}
      </div>

      <div className="flex-1 overflow-hidden">
        {previewDate ? (
          /* Preview mode: single scrollable list */
          <div className="h-full overflow-y-auto custom-scrollbar px-3 py-3 space-y-2">
            {epg.length === 0 && (
              <div className="px-3 py-8 text-center text-sm text-zinc-500">
                No hay programación cargada para este día.
              </div>
            )}
            {epg.map((e) => (
              <EpgCard key={e.slotId} entry={e} variant="default" />
            ))}
          </div>
        ) : (
          /* Live mode: Now + Next pinned, future scrollable */
          <div className="flex h-full flex-col">
            {/* Now Playing */}
            <div className="border-b border-zinc-800 px-3 py-3">
              <div className="mb-2 flex items-center gap-2">
                <span className="flex h-2 w-2 rounded-full bg-red-500" />
                <span className="text-xs font-bold uppercase tracking-wider text-red-400">Viendo Ahora</span>
              </div>
              {current ? (
                <div>
                  <EpgCard entry={current} variant="active" />
                  <div className="mt-2 h-1 w-full overflow-hidden rounded-full bg-zinc-800">
                    <div
                      className="h-full bg-gradient-to-r from-amber-500 to-orange-500 transition-all duration-1000"
                      style={{ width: `${currentProgress}%` }}
                    />
                  </div>
                  <div className="mt-1 flex justify-between text-[10px] text-zinc-500">
                    <span>{msToWallclock12h(current.startMs)}</span>
                    <span>{msToHMMSS(current.endMs - elapsedMs)} restante</span>
                    <span>{msToWallclock12h(current.endMs)}</span>
                  </div>
                </div>
              ) : (
                <div className="rounded-lg border border-dashed border-zinc-700 px-3 py-4 text-center text-sm text-zinc-500">
                  Sin programación activa
                </div>
              )}
            </div>

            {/* Up Next */}
            {nextEntry && (
              <div className="border-b border-zinc-800 px-3 py-3">
                <div className="mb-2 flex items-center gap-2">
                  <Clock className="h-3.5 w-3.5 text-sky-400" />
                  <span className="text-xs font-bold uppercase tracking-wider text-sky-400">A Continuación</span>
                </div>
                <EpgCard entry={nextEntry} variant="next" />
              </div>
            )}

            {/* Future (scrollable) */}
            <div className="flex-1 overflow-hidden">
              <div className="flex items-center justify-between px-3 py-2">
                <span className="text-xs font-bold uppercase tracking-wider text-zinc-500">Más Tarde Hoy</span>
                <span className="text-[10px] text-zinc-600">{futureEntries.length} programas</span>
              </div>
              <div className="h-[calc(100%-2rem)] overflow-y-auto custom-scrollbar px-3 pb-3 space-y-2">
                {futureEntries.length === 0 && (
                  <div className="px-3 py-6 text-center text-sm text-zinc-600">
                    Fin de la programación de hoy.
                  </div>
                )}
                {futureEntries.map((e) => (
                  <EpgCard key={e.slotId} entry={e} variant="default" />
                ))}
                {/* Load tomorrow */}
                <button
                  onClick={onLoadTomorrow}
                  className="group mt-2 flex w-full items-center justify-between rounded-lg border border-zinc-800 bg-zinc-900/60 px-4 py-3 text-left transition-colors hover:border-amber-700/60 hover:bg-zinc-900"
                >
                  <div>
                    <p className="text-sm font-semibold text-zinc-200">Cargar programación del día siguiente</p>
                    <p className="text-xs text-zinc-500">Disponibilidad: {previewDays} día(s) de anticipación</p>
                  </div>
                  <ChevronRight className="h-4 w-4 text-zinc-500 transition-transform group-hover:translate-x-0.5 group-hover:text-amber-400" />
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

function EpgCard({ entry, variant }: { entry: EpgEntry; variant: "active" | "next" | "default" }) {
  const isFiller = entry.isFiller;
  const ring =
    variant === "active"
      ? "border-amber-600/60 bg-amber-950/20 shadow-lg shadow-amber-900/20"
      : variant === "next"
      ? "border-sky-700/50 bg-sky-950/15 shadow-md shadow-sky-900/20"
      : "border-zinc-800 bg-zinc-900/40 hover:border-zinc-700 hover:bg-zinc-900/70";

  // Determine if thumbnailUrl is an image path or an emoji.
  const isImageThumb = entry.thumbnailUrl && (
    entry.thumbnailUrl.startsWith("/api/media/") ||
    entry.thumbnailUrl.startsWith("http") ||
    entry.thumbnailUrl.startsWith("/uploads")
  );

  return (
    <div className={`flex gap-3 rounded-lg border ${ring} p-2.5 transition-colors`}>
      {/* Thumbnail */}
      <div className="relative h-14 w-24 shrink-0 overflow-hidden rounded-md bg-zinc-800 flex items-center justify-center">
        {isImageThumb ? (
          <img
            src={entry.thumbnailUrl!}
            alt={entry.title}
            className="h-full w-full object-cover"
            loading="lazy"
            onError={(e) => {
              (e.currentTarget as HTMLImageElement).style.display = "none";
            }}
          />
        ) : entry.thumbnailUrl ? (
          <span className="text-2xl">{entry.thumbnailUrl}</span>
        ) : (
          <ImageIcon className="h-5 w-5 text-zinc-600" />
        )}
        {isFiller && (
          <span className="absolute bottom-0.5 right-0.5 rounded bg-zinc-950/80 px-1 text-[8px] font-bold uppercase text-zinc-300">
            Planta
          </span>
        )}
        {variant === "active" && (
          <span className="absolute left-1 top-1 rounded bg-red-600 px-1 text-[8px] font-bold uppercase text-white">
            Live
          </span>
        )}
      </div>
      {/* Info */}
      <div className="min-w-0 flex-1">
        <h3 className={`truncate text-sm font-semibold ${variant === "active" ? "text-amber-300" : "text-zinc-100"}`}>
          {entry.title}
        </h3>
        <p className="mt-0.5 font-mono text-xs text-zinc-400">
          {msToWallclock12h(entry.startMs)} — {msToWallclock12h(entry.endMs)}
        </p>
        <p className="mt-0.5 text-[11px] text-zinc-500">
          {msToHMMSS(entry.endMs - entry.startMs)} · {entry.category === "PROGRAM" ? "Programa" : entry.category === "FILLER" ? "Planta" : "Spot"}
        </p>
      </div>
    </div>
  );
}
